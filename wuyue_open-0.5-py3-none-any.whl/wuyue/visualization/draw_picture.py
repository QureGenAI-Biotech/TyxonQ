# -*- coding: utf-8 -*-
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import patches
from ..circuit.circuit import QuantumCircuit
from ..register.classicalregister import ClassicalRegister
from ..register.quantumregister import QuantumRegister
from ..element.gate import *
from ..programe.prog import QuantumProg,QIF,QWHILE,BARRIER
from ..circuit.parameters import Parameters

class Circuit_draw:
    def __init__(self,circuit,unfold = False,address = None):
        self.circuit = circuit
        self.start_state = circuit.start_state # 自定义量子初态绘制
        self.unfold = unfold
        if address:
            self.address = address
        else:
            self.address = "picture.png"
        if not isinstance(self.circuit,(QuantumCircuit,QuantumProg)):
            raise ValueError("The input is not a QuantumCircuit or a QuantumProg")
        self.depth = circuit.depth()
        self.qubit = circuit.qubits
        width = self.search_size()
        # Set fig
        if self.qubit > width:
            fig = plt.figure(figsize=(width + 1, self.qubit + 2))
        else:
            fig = plt.figure(figsize=(width + 1, self.qubit + 2))
        plt.axis("off")
        self.ax = fig.gca()
        # Set font size
        if self.qubit < 15:
            self.fontsize_name = 30-self.qubit-1
            self.fontsize_paras = (30-self.qubit-1)*0.5
            self.fontsize_dagger = (30 - self.qubit-1) * 0.5
        else:
            self.fontsize_name = 15 - (width - 15) // 2
            self.fontsize_paras = (15 - (width - 15) // 2) * 0.5
            self.fontsize_dagger = (15 - (width - 15) // 2) * 0.5
        self.draw()



    def search_size(self):
        if isinstance(self.circuit,QuantumCircuit):
            draw_list = self.circuit.get_tempgates()
        elif isinstance(self.circuit,QuantumProg):
            if self.unfold:
                # self.circuit._QuantumProg__get_tempgates()
                # self.circuit._QuantumProg__unfold_circuit()
                draw_list = np.array(self.circuit.temp_qreg)
            else:
                draw_list = self.circuit._QuantumProg__get_tempgates()
        pos_x = -1
        for i in range(draw_list.shape[1]):
            pos_x += 1
            gate_col = draw_list[:, i]
            U2_tag, U3_tag, Q_tag= 0, 0, 0
            for gate in gate_col:
                if isinstance(gate, U2):
                    U2_tag = 1
                elif isinstance(gate, U3):
                    U3_tag = 1
                elif isinstance(gate, QuantumCircuit):
                    Q_tag = 1
            if Q_tag:
                pos_x+=1.2
            elif U3_tag:
                pos_x+=1.2
            elif U2_tag:
                pos_x+=0.8
        return pos_x+4

    def point(self,x, y):
        cicle = patches.Circle(xy=(x, y),  # position
                               radius=0.15,  # radius
                               fc='cornflowerblue',  # facecolor
                               ec='cornflowerblue',  # edgecolor
                               zorder=6
                               )
        self.ax.add_patch(cicle)

    def line(self,x1, y1, x2, y2):
        self.ax.plot([x1, x2], [y1, y2],
                color='cornflowerblue',
                linewidth=2,
                linestyle='solid',
                zorder=4)

    def draw(self):
        if isinstance(self.circuit,QuantumCircuit):
            draw_list = self.circuit.get_tempgates()
        elif isinstance(self.circuit,QuantumProg):
            if self.unfold:
                draw_list = np.array(self.circuit.temp_qreg)
            else:
                draw_list = self.circuit._QuantumProg__get_tempgates()
        pos_x = -1
        U2_tag = 0
        U3_tag = 0
        true_lens = 0
        false_lens = 0
        while_lens = 0
        # 1118 自定义量子初态绘制
        if type(self.start_state) == type(None):
            state_init = False
        else:
            state_init = True

        for i in range(draw_list.shape[1]):
            # Draw else and end symbol
            if true_lens == 1:
                pos_x += 1
                self.ELSEgate("else", pos_x, self.qubit - 1)
            elif false_lens == 1:
                pos_x += 1
                self.ENDgate("END", pos_x, self.qubit - 1)
            elif while_lens == 1:
                pos_x += 1
                self.ENDgate("END", pos_x, self.qubit - 1)
            pos_x += 1
            if U3_tag:
                pos_x += 0.4
            elif U2_tag:
                pos_x += 0.2
            gate_col = draw_list[:, i]
            U2_tag = 0
            U3_tag = 0
            # calculated length
            for gate in gate_col:
                if isinstance(gate, U2) and U2_tag == 0:
                    pos_x += 0.2
                    U2_tag = 1
                elif isinstance(gate, U3) or isinstance(gate, QuantumCircuit):
                    if U2_tag:
                        pos_x += 0.2
                    else:
                        pos_x += 0.4
                    U3_tag = 1
                    break

            for j in range(len(gate_col)):
                # Draw quantum gates
                if state_init == True:  # 1118 自定义量子初态绘制
                    self.Stateinit(pos_x, self.qubit - 1)
                    state_init = False
                    pos_x += 1

                if isinstance(gate_col[j], Basicgate):
                    if true_lens >= 1:
                        true_lens -= 1

                    if false_lens >= 1 and true_lens == 0:
                        false_lens -= 1

                    if while_lens >= 1:
                        while_lens -= 1

                    if gate_col[j].ctrl:
                        target = gate_col[j].target
                        control = gate_col[j].ctrl
                        pos1 = min(min(target), min(control))
                        pos2 = max(max(target), max(control))
                        # Draw target and control bit elements
                        for k in range(pos1, pos2 + 1):
                            if k in target:
                                if isinstance(gate_col[j], U1):
                                    self.U1gate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], U2):
                                    self.U2gate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], U3):
                                    self.U3gate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], I):
                                    self.Igate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], H):
                                    self.Hgate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], T):
                                    self.Tgate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], X):
                                    self.Xgate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], Y):
                                    self.Ygate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], Z):
                                    self.Zgate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], S):
                                    self.Sgate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], RX):
                                    self.RXgate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], RY):
                                    self.RYgate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], RZ):
                                    self.RZgate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], P):
                                    self.Pgate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], SWAP):
                                    self.SWAPgate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], CX) or isinstance(gate_col[j], CNOT):
                                    self.CXgate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], CZ):
                                    self.CZgate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif isinstance(gate_col[j], CCX) or isinstance(gate_col[j], TOFFOLI):
                                    self.CCXgate(gate_col[j], pos_x, self.qubit - k - 1)

                                elif gate_col[j].name == "NEW":
                                    self.Ugate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif k in control:
                                # Draw control cicle
                                self.point(pos_x, self.qubit - k - 1)
                            # Draw connection lines
                            self.line(pos_x, self.qubit - 1 - pos1, pos_x, self.qubit - 1 - pos2)
                    else:
                        target = gate_col[j].target
                        for k in target:
                            if isinstance(gate_col[j], U1):
                                self.U1gate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], U2):
                                self.U2gate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], U3):
                                self.U3gate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], I):
                                self.Igate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], H):
                                self.Hgate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], T):
                                self.Tgate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], X):
                                self.Xgate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], Y):
                                self.Ygate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], Z):
                                self.Zgate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], S):
                                self.Sgate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], RX):
                                self.RXgate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], RY):
                                self.RYgate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], RZ):
                                self.RZgate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], P):
                                self.Pgate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], SWAP):
                                self.SWAPgate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], CX) or isinstance(gate_col[j], CNOT):
                                self.CXgate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], CZ):
                                self.CZgate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], CCX) or isinstance(gate_col[j], TOFFOLI):
                                self.CCXgate(gate_col[j], pos_x, self.qubit - k - 1)

                            elif isinstance(gate_col[j], MEASURE):
                                self.Measure(gate_col[j], pos_x, self.qubit - k - 1)

                            elif gate_col[j].name == "NEW":
                                self.Ugate(gate_col[j], pos_x, self.qubit - k - 1)
                                break

                        if len(target) > 1:
                            # Draw connection lines
                            self.line(pos_x, self.qubit - min(target) - 1, pos_x, self.qubit - max(target) - 1)

                elif isinstance(gate_col[j], BARRIER):
                    self.Barrier(gate_col[j], pos_x, self.qubit - k - 1)
                # Draw ciruit
                elif isinstance(gate_col[j], QuantumCircuit):
                    self.Circuitgate(gate_col[j], pos_x, self.qubit - gate_col[j].start_pos - 1)
                    control = gate_col[j].controled
                    for k in control:
                        self.point(pos_x, self.qubit - k - 1)
                    if control != []:
                        pos_min = min(min(control), gate_col[j].start_pos)
                        pos_max = max(max(control), gate_col[j].start_pos)
                        # Draw connection lines
                        self.line(pos_x, self.qubit - 1 - pos_min, pos_x, self.qubit - 1 - pos_max)
                # Draw QIF
                elif isinstance(gate_col[j], QIF):
                    if true_lens >= 1:
                        true_lens -= 1

                    if false_lens >= 1 and true_lens == 0:
                        false_lens -= 1

                    if while_lens >= 1:
                        while_lens -= 1
                    self.IFgate(gate_col[j], pos_x, self.qubit - 1)
                    true_lens = gate_col[j].true_lens + 1
                    false_lens = gate_col[j].false_lens + 1
                # Draw QWHILE
                elif isinstance(gate_col[j], QWHILE):
                    if true_lens >= 1:
                        true_lens -= 1

                    if false_lens >= 1 and true_lens == 0:
                        false_lens -= 1

                    if while_lens >= 1:
                        while_lens -= 1
                    self.WHILEgate(gate_col[j], pos_x, self.qubit - 1)
                    while_lens = gate_col[j].while_lens + 1

        # Draw lines for circuit
        for i in range(self.qubit):
            x1 = np.arange(-1, pos_x + 1)
            y1 = np.ones_like(x1) * i
            self.ax.plot(x1, y1, color="black", zorder=3)
            self.ax.text(-1.5, i, "$q%d$" % (self.qubit - i - 1), ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)

        # Set the length of the xy axis
        plt.xlim(-1, pos_x + 1)
        plt.ylim(-1, self.qubit)
        plt.savefig(self.address)
        plt.show()


    def U1gate(self,gate, x, y):
        symbol = "U1"
        # Three digits reserved for parameters
        temp_paras = []
        for paras_gate in gate.paras:
            if not isinstance(paras_gate, Parameters):
                paras_gate = round(paras_gate, 3) if paras_gate > 0 else round(paras_gate, 2)
                temp_paras.append(f"{paras_gate}")
            else:
                if paras_gate.value is None:
                    temp_paras.append(f"{paras_gate.name}")
                else:
                    if paras_gate.value > 0:
                        temp_paras.append(f"{round(paras_gate.value, 3)}")
                    else:
                        temp_paras.append(f"{round(paras_gate.value, 2)}")
        paras = ",".join(temp_paras)
        # paras = [round(i, 3) if i > 0 else round(i, 2) for i in gate.paras]
        # paras = str(paras)[1:-1]

        box = patches.Rectangle(
            xy=(x - 0.5 * 0.70, y - 0.5 * 0.65), width=0.70, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # U1 position
        self.ax.text(x, y + 0.1, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        # U1 parameter position
        self.ax.text(x, y - 0.1, "$%s$" % paras, ha="center", va='center',color="black", fontsize=self.fontsize_paras, zorder=6)
        if gate.dagger:
            self.ax.text(x + 0.3, y + 0.1, "$†$", ha="center", va='bottom', fontsize=self.fontsize_dagger,
                    color="black", zorder=6)

    def U2gate(self,gate, x, y):
        symbol = "U2"
        # Three digits reserved for parameters
        temp_paras = []
        for paras_gate in gate.paras:
            if not isinstance(paras_gate, Parameters):
                paras_gate = round(paras_gate, 3) if paras_gate > 0 else round(paras_gate, 2)
                temp_paras.append(f"{paras_gate}")
            else:
                if paras_gate.value is None:
                    temp_paras.append(f"{paras_gate.name}")
                else:
                    if paras_gate.value > 0:
                        temp_paras.append(f"{round(paras_gate.value, 3)}")
                    else:
                        temp_paras.append(f"{round(paras_gate.value, 2)}")
        paras = ",".join(temp_paras)
        # paras = [round(i, 3) if i > 0 else round(i, 2) for i in gate.paras]
        # paras = str(paras)[1:-1]
        box = patches.Rectangle(
            xy=(x - 0.5 * 1.0, y - 0.5 * 0.65), width=1.0, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # U2 position
        self.ax.text(x, y + 0.1, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        # U2 parameter position
        self.ax.text(x, y - 0.1, "$%s$" % paras, ha="center", va='center',color="black", fontsize=self.fontsize_paras*0.9, zorder=6)
        if gate.dagger:
            self.ax.text(x + 0.3, y + 0.1, "$†$", ha="center", va='bottom', fontsize=self.fontsize_dagger,
                    color="black", zorder=6)

    def U3gate(self,gate, x, y):
        symbol = "U3"
        # Three digits reserved for parameters
        temp_paras = []
        for paras_gate in gate.paras:
            if not isinstance(paras_gate, Parameters):
                paras_gate = round(paras_gate, 3) if paras_gate > 0 else round(paras_gate, 2)
                temp_paras.append(f"{paras_gate}")
            else:
                if paras_gate.value is None:
                    temp_paras.append(f"{paras_gate.name}")
                else:
                    if paras_gate.value > 0:
                        temp_paras.append(f"{round(paras_gate.value, 3)}")
                    else:
                        temp_paras.append(f"{round(paras_gate.value, 2)}")
        paras = ",".join(temp_paras)
        # paras = [round(i, 3) if i>0 else round(i, 2) for i in gate.paras]
        # paras = str(paras)[1:-1]
        box = patches.Rectangle(
            xy=(x - 0.5 * 1.4, y - 0.5 * 0.65), width=1.4, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # U3 position
        self.ax.text(x, y + 0.1, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        # U3 parameter position
        self.ax.text(x, y - 0.1, "$%s$" % paras, ha="center", va='center',color="black", fontsize=self.fontsize_paras*0.8, zorder=6)
        if gate.dagger:
            self.ax.text(x + 0.3, y + 0.1, "$†$", ha="center", va='bottom', fontsize=self.fontsize_dagger,
                    color="black", zorder=6)

    def Igate(self,gate, x, y):
        symbol = "I"
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.65, y - 0.5 * 0.65), width=0.65, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # I position
        self.ax.text(x, y, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)

    def Hgate(self,gate, x, y):
        symbol = "H"
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.65, y - 0.5 * 0.65), width=0.65, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # H position
        self.ax.text(x, y, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)

    def Sgate(self,gate, x, y):
        symbol = "S"
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.65, y - 0.5 * 0.65), width=0.65, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # S position
        self.ax.text(x, y, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        if gate.dagger:
            self.ax.text(x + 0.25, y, "$†$", ha="center", va='bottom', fontsize=self.fontsize_dagger,
                    color="black", zorder=6)

    def Tgate(self,gate, x, y):
        symbol = "T"
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.65, y - 0.5 * 0.65), width=0.65, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # T position
        self.ax.text(x, y, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        if gate.dagger:
            self.ax.text(x + 0.25, y, "$†$", ha="center", va='bottom', fontsize=self.fontsize_dagger,
                    color="black", zorder=6)

    def Xgate(self,gate, x, y):
        symbol = "X"
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.65, y - 0.5 * 0.65), width=0.65, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # X position
        self.ax.text(x, y, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)

    def Ygate(self,gate, x, y):
        symbol = "Y"
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.65, y - 0.5 * 0.65), width=0.65, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # Y position
        self.ax.text(x, y, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        if gate.dagger:
            self.ax.text(x + 0.25, y, "$†$", ha="center", va='bottom', fontsize=self.fontsize_dagger,
                    color="black", zorder=6)

    def Zgate(self,gate, x, y):
        symbol = "Z"
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.65, y - 0.5 * 0.65), width=0.65, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # Z position
        self.ax.text(x, y, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)

    def SWAPgate(self,gate, x, y):
        # SWAP symbol
        symbol = "✕"
        # SWAP position
        self.ax.text(x - 0.05, y - 0.05, "$%s$" % symbol, ha="center", va='center', fontsize=self.fontsize_name * 2,
                color='cornflowerblue', zorder=6)

    def RXgate(self,gate, x, y):
        symbol = "RX"
        # Three digits reserved for parameters
        temp_paras = []
        for paras_gate in gate.paras:
            if not isinstance(paras_gate, Parameters):
                paras_gate = round(paras_gate, 3) if paras_gate > 0 else round(paras_gate, 2)
                temp_paras.append(f"{paras_gate}")
            else:
                if paras_gate.value is None:
                    temp_paras.append(f"{paras_gate.name}")
                else:
                    if paras_gate.value > 0:
                        temp_paras.append(f"{round(paras_gate.value, 3)}")
                    else:
                        temp_paras.append(f"{round(paras_gate.value, 2)}")
        paras = ",".join(temp_paras)
        # paras = [round(i, 3) if i > 0 else round(i, 2) for i in gate.paras]
        # paras = str(paras)[1:-1]
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.70, y - 0.5 * 0.65), width=0.70, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # RX position
        self.ax.text(x, y + 0.1, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        # RX parameter position
        self.ax.text(x, y - 0.1, "$%s$" % paras, ha="center", va='center',color="black", fontsize=self.fontsize_paras, zorder=6)
        if gate.dagger:
            self.ax.text(x + 0.3, y + 0.1, "$†$", ha="center", va='bottom', fontsize=self.fontsize_dagger,
                    color="black", zorder=6)

    def RYgate(self,gate, x, y):
        symbol = "RY"
        # Three digits reserved for parameters
        temp_paras = []
        for paras_gate in gate.paras:
            if not isinstance(paras_gate, Parameters):
                paras_gate = round(paras_gate, 3) if paras_gate > 0 else round(paras_gate, 2)
                temp_paras.append(f"{paras_gate}")
            else:
                if paras_gate.value is None:
                    temp_paras.append(f"{paras_gate.name}")
                else:
                    if paras_gate.value > 0:
                        temp_paras.append(f"{round(paras_gate.value, 3)}")
                    else:
                        temp_paras.append(f"{round(paras_gate.value, 2)}")
        paras = ",".join(temp_paras)
        # paras = [round(i, 3) if i > 0 else round(i, 2) for i in gate.paras]
        # paras = str(paras)[1:-1]
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.70, y - 0.5 * 0.65), width=0.70, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # RY position
        self.ax.text(x, y + 0.1, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        # RY parameter position
        self.ax.text(x, y - 0.1, "$%s$" % paras, ha="center", va='center',color="black", fontsize=self.fontsize_paras, zorder=6)

    def RZgate(self,gate, x, y):
        symbol = "RZ"
        # Three digits reserved for parameters
        temp_paras = []
        for paras_gate in gate.paras:
            if not isinstance(paras_gate, Parameters):
                paras_gate = round(paras_gate, 3) if paras_gate > 0 else round(paras_gate, 2)
                temp_paras.append(f"{paras_gate}")
            else:
                if paras_gate.value is None:
                    temp_paras.append(f"{paras_gate.name}")
                else:
                    if paras_gate.value > 0:
                        temp_paras.append(f"{round(paras_gate.value, 3)}")
                    else:
                        temp_paras.append(f"{round(paras_gate.value, 2)}")
        paras = ",".join(temp_paras)
        # paras = [round(i, 3) if i > 0 else round(i, 2) for i in gate.paras]
        # paras = str(paras)[1:-1]
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.70, y - 0.5 * 0.65), width=0.70, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # RZ position
        self.ax.text(x, y + 0.1, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        # RZ parameter position
        self.ax.text(x, y - 0.1, "$%s$" % paras, ha="center", va='center',color="black", fontsize=self.fontsize_paras, zorder=6)
        if gate.dagger:
            self.ax.text(x + 0.3, y + 0.1, "$†$", ha="center", va='bottom', fontsize=self.fontsize_dagger,
                    color="black", zorder=6)

    def Pgate(self,gate, x, y):
        symbol = "P"
        # Three digits reserved for parameters
        temp_paras = []
        for paras_gate in gate.paras:
            if not isinstance(paras_gate, Parameters):
                paras_gate = round(paras_gate, 3) if paras_gate > 0 else round(paras_gate, 2)
                temp_paras.append(f"{paras_gate}")
            else:
                if paras_gate.value is None:
                    temp_paras.append(f"{paras_gate.name}")
                else:
                    if paras_gate.value > 0:
                        temp_paras.append(f"{round(paras_gate.value, 3)}")
                    else:
                        temp_paras.append(f"{round(paras_gate.value, 2)}")
        paras = ",".join(temp_paras)
        # paras = [round(i, 3) if i > 0 else round(i, 2) for i in gate.paras]
        # paras = str(paras)[1:-1]
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.70, y - 0.5 * 0.65), width=0.70, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # P position
        self.ax.text(x, y + 0.1, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        # P parameter position
        self.ax.text(x, y - 0.1, "$%s$" % paras, ha="center", va='center',color="black", fontsize=self.fontsize_paras, zorder=6)
        if gate.dagger:
            self.ax.text(x + 0.25, y + 0.1, "$†$", ha="center", va='bottom', fontsize=self.fontsize_dagger,
                    color="black", zorder=6)

    def CXgate(self,gate, x, y):
        cicle = patches.Circle(xy=(x, y),  # 圆心坐标
                               radius=0.3,  # 半径
                               fc='cornflowerblue',  # facecolor
                               ec='cornflowerblue',  # 浅蓝色
                               zorder=6
                               )
        self.ax.add_patch(cicle)

        self.ax.plot([x - 0.25, x + 0.25], [y, y],
                color='white',
                linewidth=5,
                linestyle='solid',
                zorder=6)
        self.ax.plot([x, x], [y - 0.25, y + 0.25],
                color='white',
                linewidth=5,
                linestyle='solid',
                zorder=6)

    def CZgate(self,gate, x, y):
        symbol = "CZ"
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.65, y - 0.5 * 0.65), width=0.65, height=0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)

        self.ax.text(x, y, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)

    def CCXgate(self,gate, x, y):
        # CCX position
        # Draw CCX symbol
        cicle = patches.Circle(xy=(x, y),  # 圆心坐标
                               radius=0.3,  # 半径
                               fc='cornflowerblue',  # 浅蓝色
                               ec='cornflowerblue',
                               zorder=6
                               )
        self.ax.add_patch(cicle)
        self.ax.plot([x - 0.25, x + 0.25], [y, y],
                color='white',
                linewidth=5,
                linestyle='solid',
                zorder=6)
        self.ax.plot([x, x], [y - 0.25, y + 0.25],
                color='white',
                linewidth=5,
                linestyle='solid',
                zorder=6)

    def Ugate(self,gate, x, y):
        symbol = gate.symbol
        bits = np.log2(gate.matrix.shape[0])
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.65, y - bits + 1 - 0.5 * 0.65), width=0.65, height=bits - 1 + 0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # U position
        self.ax.text(x, y - (bits - 1) / 2, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        if gate.dagger:
            self.ax.text(x + 0.25, y - (bits - 1) / 2, "$†$", ha="center", va='bottom', fontsize=self.fontsize_dagger,
                    color="black", zorder=6)

    def IFgate(self,gate, x, y):
        symbol = "QIF"
        bits = self.qubit
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.65, y - bits + 1 - 0.5 * 0.65), width=0.65, height=bits - 1 + 0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # IF position
        self.ax.text(x, y - (bits - 1) / 2 + 0.3, "$Q$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        self.ax.text(x, y - (bits - 1) / 2, "$I$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        self.ax.text(x, y - (bits - 1) / 2 - 0.3, "$F$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)

    def ENDgate(self,gate, x, y):
        symbol = "END"
        bits = self.qubit
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.65, y - bits + 1 - 0.5 * 0.65), width=0.65, height=bits - 1 + 0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # END position
        self.ax.text(x, y - (bits - 1) / 2 + 0.3, "$E$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        self.ax.text(x, y - (bits - 1) / 2, "$N$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        self.ax.text(x, y - (bits - 1) / 2 - 0.3, "$D$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)

    def ELSEgate(self,gate, x, y):
        symbol = "ELSE"
        bits = self.qubit
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.65, y - bits + 1 - 0.5 * 0.65), width=0.65, height=bits - 1 + 0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # ELSE position
        self.ax.text(x, y - (bits - 1) / 2 + 0.4, "$E$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        self.ax.text(x, y - (bits - 1) / 2 + 0.1, "$L$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        self.ax.text(x, y - (bits - 1) / 2 - 0.2, "$S$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        self.ax.text(x, y - (bits - 1) / 2 - 0.5, "$E$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)

    def WHILEgate(self,gate, x, y):
        symbol = "QWHILE"
        bits = self.qubit
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.65, y - bits + 1 - 0.5 * 0.65), width=0.65, height=bits - 1 + 0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # QWHILE position
        self.ax.text(x, y - (bits - 1) / 2 + 0.6, "$Q$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        self.ax.text(x, y - (bits - 1) / 2 + 0.3, "$W$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        self.ax.text(x, y - (bits - 1) / 2, "$I$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        self.ax.text(x, y - (bits - 1) / 2 - 0.3, "$L$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        self.ax.text(x, y - (bits - 1) / 2 - 0.6, "$E$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)

    def Circuitgate(self,gate, x, y):
        if len(gate.name) > 8:
            symbol = gate.name[:8]
        else:
            symbol = gate.name
        start = gate.start_pos
        bits = gate.qubits
        box = patches.Rectangle(
            xy=(x - 0.5 * 1.7, y - bits + 1 - 0.5 * 0.65), width=1.7, height=bits - 1 + 0.65,
            fc='cornflowerblue', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # Circuit position
        self.ax.text(x, y - (bits - 1) / 2, "$%s$" % symbol, ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
        if gate.symbol_dagger:
            self.ax.text(x + 0.25, y - (bits - 1) / 2, "$†$", ha="center", va='bottom',color="black", fontsize=self.fontsize_dagger,
                     zorder=6)

    def Measure(self,gate, x, y):
        # MEASURE position
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.70, y - 0.5 * 0.65), width=0.70, height=0.65,
            fc='red', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # MEASURE symbol
        arc = patches.Arc(xy=(x, y - 0.15), width=0.65 * 0.7,
                          height=0.65 * 0.7, theta1=0, theta2=180, fill=False,
                          ec='white', linewidth=2,
                          zorder=6)
        self.ax.add_patch(arc)

        arrow = patches.Arrow(x=x - 0.05, y=y - 0.15, dx=0.15, dy=0.4, width=0.20,
                              fc='white', ec=None, linewidth=1.0, zorder=6)
        self.ax.add_patch(arrow)

    def Barrier(self,gate, x, y):
        # Barrier position
        box = patches.Rectangle(
            xy=(x - 0.5 * 0.30, y - 0.5 * 0.80), width=0.30, height=0.80,
            fc='gray', ec=None, linewidth=1.5, zorder=5)
        self.ax.add_patch(box)
        # Barrier symbol
        y1, y2 = y + 0.4, y - 0.4
        self.ax.plot([x, x], [y1, y2], color='white', linewidth=3.0, linestyle='--', zorder=6)

# ### 1118 自定义量子初态绘制 ###
    def Stateinit(self, x, y):
       symbol = "Init State"
       # print(symbol)
       bits = self.qubit
       box = patches.Rectangle(
           xy=(x - 0.75 * 0.75, y - bits + 1 - 0.5 * 0.65), width=0.9, height=bits - 1 + 0.65,
           fc='palegreen', ec=None, linewidth=1.5, zorder=5)

       self.ax.add_patch(box)
       # Init State position
       self.ax.text(x - 0.35 * 0.33, y - (bits - 1) / 2 + 0.18, "$Init$", ha="center", va='center',color="black", fontsize=self.fontsize_name-2, zorder=6)
       # self.ax.text(x, y - (bits - 1) / 2, "$I$", ha="center", va='center',color="black", fontsize=self.fontsize_name, zorder=6)
       self.ax.text(x - 0.35 * 0.33, y - (bits - 1) / 2 -0.18, "$State$", ha="center", va='center',color="black", fontsize=self.fontsize_name-2, zorder=6)
