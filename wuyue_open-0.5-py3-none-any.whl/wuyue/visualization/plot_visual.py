# -*- coding: utf-8 -*-
import numpy as np
import numpy
import matplotlib.pyplot as plt
from matplotlib import colors, cm
from sympy import symbols, E, cos, sin, solve, re
from ..visualization.draw_picture import Circuit_draw
from ..programe.prog import *

def density_matrix(circuit):
    psi = circuit.state
    dim = psi.shape[0]
    psi_c = psi.conjugate()
    psi_ct = psi_c.T
    matrix = np.outer(psi, psi_ct)

    prob = abs(matrix)
    phase = np.angle(matrix)

    qubit = int(np.log2(dim))
    x = [i for i in range(dim)]
    y = [i for i in range(dim)]

    x_label = []
    y_label = []
    for i in range(dim):
        bin_num = bin(i).replace("0b", "")
        bin_num = (qubit - len(bin_num)) * "0" + bin_num
        x_label.append(bin_num)
        y_label.append(bin_num)

    xx, yy = np.meshgrid(x, y)
    x_faltten, y_faltten = xx.ravel(), yy.ravel()
    bottom = np.zeros_like(x_faltten)
    z_faltten = prob.ravel()
    z_color = phase.ravel()

    cmap = cm.get_cmap('rainbow')
    norm = colors.Normalize(-np.pi, np.pi)
    color = cmap(norm(z_color))

    width = height = 0.5  # 每一个柱子的长和宽
    fig = plt.figure()
    ax = fig.add_subplot(projection='3d')  # 三维坐标轴

    ax.bar3d(x_faltten - 0.25, y_faltten - 0.25, bottom, width, height, z_faltten, shade=True, color=color)  #

    ax.set_xticks(x)
    ax.set_xticklabels(x_label)
    ax.set_yticks(y)
    ax.set_yticklabels(y_label)
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    sc = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    cb = plt.colorbar(sc)
    cb.set_ticks([-np.pi, -np.pi / 2, 0, np.pi / 2, np.pi])
    cb.set_ticklabels(
        (r'$-\pi$', r'$-\pi/2$', r'$0$', r'$\pi/2$', r'$\pi$'))
    plt.savefig("density_matrix.png")
    plt.show()


def bloch_circuit(circuit):
    psi = circuit.state
    psi_c = psi.conjugate()
    psi_ct = psi_c.T
    matrix = np.outer(psi, psi_ct)

    x, y, z = symbols('x y z')
    f1 = 1 / 2 + z / 2 - matrix[0][0]
    f2 = (x - y * 1j) / 2 - matrix[0][1]
    f3 = (x + y * 1j) / 2 - matrix[1][0]
    result = solve([f1, f2, f3], [x, y, z])
    x, y, z = result[x], result[y], result[z]
    x, y, z = round(y, 3), round(-x, 3), round(z, 3)
    xyz_data = np.array([[x, y, z]])

    fig = plt.figure()
    fig_size = (10, 10)
    fig.set_size_inches(fig_size[0], fig_size[1])
    ax = fig.add_subplot(projection='3d')
    ax.set_axis_off()
    ax.set_xlim3d(-0.7, 0.7)
    ax.set_ylim3d(-0.7, 0.7)
    ax.set_zlim3d(-0.6, 0.6)
    opts = {
        "fontsize": 30,
        "color": plt.rcParams["axes.labelcolor"],
        "horizontalalignment": "center",
        "verticalalignment": "center",
    }
    pos_x = [0, -1.4, 0]
    pos_y = [1.2, 0, 0]
    pos_0 = [0, 0, 1.2]
    pos_1 = [0, 0, -1.4]
    ax.text(pos_x[0], pos_x[1], pos_x[2], "$x$", **opts)
    ax.text(pos_y[0], pos_y[1], pos_y[2], "$y$", **opts)
    ax.text(pos_0[0], pos_0[1], pos_0[2], r"$\left|0\right>$", **opts)
    ax.text(pos_1[0], pos_1[1], pos_1[2], r"$\left|1\right>$", **opts)

    # 构建球网格
    u, v = np.mgrid[0:2 * np.pi:20j, 0:np.pi:10j]
    x = np.cos(u) * np.sin(v)
    y = np.sin(u) * np.sin(v)
    z = np.cos(v)
    ax.plot_wireframe(x, y, z, color="gray")

    # 构建球面
    u, v = np.mgrid[0:2 * np.pi:20j, 0:np.pi:10j]
    x = np.cos(u) * np.sin(v)
    y = np.sin(u) * np.sin(v)
    z = np.cos(v)
    ax.plot_surface(x, y, z, color="g", alpha=0.2)

    # XYZ坐标轴
    xyz = np.array([[1, 0, 0], [0, -1, 0], [0, 0, 1]])
    tails = np.zeros(len(xyz))
    ax.quiver(tails, tails, tails, xyz[:, 0], xyz[:, 1], xyz[:, 2],
              length=1.0, normalize=True, color='black', arrow_length_ratio=0.15)

    ax.quiver(tails, tails, tails, xyz_data[0][0], xyz_data[0][1], xyz_data[0][2],
              length=1.0, normalize=True, color='r', arrow_length_ratio=0.15)

    ax.set_title('Bloch sphere', fontdict={'size': 30})
    plt.savefig("bloch_circuit.png")
    # plt.show()


def probaility_plot(prob):
    prob = [float(i) for i in prob]
    qubit = int(np.log2(len(prob)))
    X = []
    Y = []
    for index, value in enumerate(prob):
        if value > 0:
            bin_num = bin(index).replace("0b", "")
            bin_num = (qubit - len(bin_num)) * "0" + bin_num
            X.append(bin_num)
            Y.append(value)

    plt.bar(X, Y, align="center", color="b")
    plt.ylabel("Probabilities")
    plt.savefig("probaility_plot.png")
    # plt.show()


def draw2pic(circuit, unfold=False, address="picture.png"):
    Circuit_draw(circuit, unfold=unfold, address=address)


## Bloch球可视化 ##
try:
    from matplotlib import animation
    import matplotlib.pyplot as plt
    from matplotlib import get_backend
    from mpl_toolkits.mplot3d import Axes3D

    plt.switch_backend('TKAgg')
    HAS_MATPLOTLIB = True
except:
    HAS_MATPLOTLIB = False
    pass
import math
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import re
from mpl_toolkits.mplot3d import Axes3D, proj3d
from matplotlib.patches import FancyArrowPatch
import os
from math import sin, cos, acos, sqrt
from matplotlib import animation
from mpl_toolkits.mplot3d.art3d import Patch3D


class Arrow3D(Patch3D, FancyArrowPatch):  # 在bloch球内画出量子态向量的三维箭头
    """Makes a fancy arrow"""
    __module__ = "mpl_toolkits.mplot3d.art3d"

    def __init__(self, xs, ys, zs, zdir="z", **kwargs):
        FancyArrowPatch.__init__(self, (0, 0), (0, 0), **kwargs)
        self.set_3d_properties(tuple(zip(xs, ys)), zs, zdir)
        self._path2d = None

    def draw(self, renderer):
        xs3d, ys3d, zs3d = zip(*self._segment3d)
        x_s, y_s, _ = proj3d.proj_transform(xs3d, ys3d, zs3d, self.axes.M)
        self._path2d = matplotlib.path.Path(np.column_stack([x_s, y_s]))
        self.set_positions((x_s[0], y_s[0]), (x_s[1], y_s[1]))
        FancyArrowPatch.draw(self, renderer)


import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LinearSegmentedColormap, ListedColormap


class Bloch:
    """bloch球类"""

    def __init__(  # init里面建立了一个三维坐标轴
            # self, fig=None, axes=None, view=None, figsize=None, background=False, font_size=20,
            self, circuit=None, fig=None, axes=None, view=None, figsize=None, background=False, font_size=20,
            cmap=None, sphere_transparency=None, frame_color=None, frame_width=None, font_color=None, fps=20

    ):
        self.circuit = circuit
        self.fps = fps
        self.secs_per_gate = 1
        pauli_matrixls = []  # pauli_matrixls能不能封装一下，不要单独写
        X = np.array([[0., 1.], [1., 0.]], dtype=complex)
        Y = np.array([[0., -1.j], [1.j, 0.]], dtype=complex)
        Z = np.array([[1., 0.], [0., -1.]], dtype=complex)
        pauli_matrixls.append(X)
        pauli_matrixls.append(Y)
        pauli_matrixls.append(Z)
        if circuit is not None:
            # print("circuit", circuit)
            circuit.draw()
            # print("circuit.state",circuit.state)
            self.circuit = circuit
            # print("circuit.state", circuit.state)
            psi = circuit.state  # psi就是量子态的复数向量形式（state）[a+bj,c+dj]
            # psi = np.asarray(state, dtype=complex) # psi就是量子态的复数向量形式（state）
            psi_c = psi.conjugate()  # psi_c返回上述的共轭复数 【共轭复数就是实部相等，虚部互为相反数】
            psi_ct = psi_c.T  # 这psi_ct就是量子态复数向量形式的转置复共轭
            desity_matrix = np.outer(psi, psi_ct)  # 这里求出的matrix是量子态的密度矩阵，即量子态的复数向量 × 其转置复共轭 = 该量子态的密度矩阵

            bloch_data = []
            bloch_state = [np.real(np.trace(np.dot(mat, desity_matrix))) for mat in
                           pauli_matrixls]  # 这里直接写一个泡利矩阵的迭代器# 修改之后的泡利矩阵直接放列表
            bloch_data.append(bloch_state)  # bloch_data=[x,y,z]坐标
            self.bloch_data = bloch_data  # 为了画静态Bloch球展示
            # 用的是泡利矩阵与量子态的密度矩阵的矩阵乘的迹，（迹就是矩阵的对角线和）。泡利z与密度矩阵乘的矩阵的迹是z坐标，泡利x与密度矩阵乘的矩阵的迹是x坐标,泡利y与密度矩阵乘的矩阵的迹是y坐标

            self.frames_per_gate = fps  # 每个门由多少帧图片组成
            self.time_between_frames = (self.secs_per_gate * 1000) / self.fps  # （1*1000/20=50)
            plot_dict = self.bloch_plot_dict()  # 返回门对应的字典。
            simple_gates = ['H', 'X', 'Y', 'Z', 'S', 'SGD', 'T', 'TDG']  # 简单门列表，角度都是固定的，不需要特判
            list_of_circuit_gates = []
            trans = 180. / np.pi
            for gate in circuit.gates:
                if gate.name in simple_gates:
                    list_of_circuit_gates.append(plot_dict[gate.name])
                else:
                    print('gate.name', gate.name)

                    rad = gate.paras[0]  # wuyeu返回的就是弧度制 gate.paras是一个列表[1.57]
                    # theta = np.rad2deg(rad)
                    theta = np.round(rad * trans)
                    # 为了防止pi近似计算引入的转换角度误差，借鉴pyqPanda的做法进行取整。 np.round(layer[0].m_params[0] * trans)))

                    if gate.name == 'RX':  # rx门另外加,因为旋转角度未知，所以要用特判来补充其四元数旋转表达
                        # print('rx-theta',theta) # theta是90,角度值
                        # print('rx-rad',rad)  #rad是1.570796326794896，pi/2弧度制，跟WuYueSDK的circuit.apply_circuit()后的circuit.gates中的paras一致.但Wuyue中H门等简单门是没有paras属性的
                        quaternion = PlotVector.from_axisangle(
                            rad / self.frames_per_gate, [1, 0, 0])
                        list_of_circuit_gates.append(
                            ('RX:' + str(theta), quaternion, '#f39c12'))
                    elif gate.name == 'RY':
                        quaternion = PlotVector.from_axisangle(
                            rad / self.frames_per_gate, [0, 1, 0])
                        list_of_circuit_gates.append(
                            ('RY:' + str(theta), quaternion, '#0c93bf'))
                    elif gate.name == 'RZ':
                        quaternion = PlotVector.from_axisangle(
                            rad / self.frames_per_gate, [0, 0, 1])
                        list_of_circuit_gates.append(
                            ('RZ:' + str(theta), quaternion, '#a06aad'))
                    elif gate.name == 'U1':
                        quaternion = PlotVector.from_axisangle(
                            rad / self.frames_per_gate, [0, 0, 1])
                        list_of_circuit_gates.append(
                            ('U1:' + str(theta), quaternion, '#69a45a'))
            self.list_of_circuit_gates = list_of_circuit_gates

        # 图和轴
        self._ext_fig = False
        if fig is not None:
            self._ext_fig = True
        self.fig = fig
        self._ext_axes = False
        if axes is not None:
            self._ext_fig = True
            self._ext_axes = True
        self.axes = axes
        self.background = background
        self.figsize = figsize if figsize else [5, 5]  #
        # 方位角和仰角角度
        self.view = view if view else [-60, 30]
        # # Blonch球的颜色, default = #FFDDDD
        # self.sphere_color = "#FFDDDD"
        # Bloch球的颜色渐变，default='gist_earth'
        self.cmap = cmap if cmap else 'gist_earth'  #
        # 球体透明度, default = 0.2
        self.sphere_transparency = sphere_transparency if sphere_transparency else 0.2  #
        # 线框颜色, default = 'gray'
        self.frame_color = frame_color if frame_color else "gray"  #
        # 线框宽度, default = 1
        self.frame_width = frame_width if frame_width else 1  #
        # 线框透明度, default = 0.2
        # self.frame_transparency = 0.2
        # x轴标签, default = ['$x$', '']
        self.xlabel = ["$x$", ""]
        # x轴标签的位置, default = [1.2, -1.2]
        self.xlpos = [1.2, -1.2]
        # y轴标签, default = ['$y$', '']
        self.ylabel = ["$y$", ""]
        # y轴标签的位置, default = [1.1, -1.1]
        self.ylpos = [1.2, -1.2]
        # z轴标签 (in LaTex),
        # default = [r'$\left|1\right>$', r'$\left|0\right>$']
        self.zlabel = [r"$\left|0\right>$", r"$\left|1\right>$"]
        # z轴标签的位置, default = [1.2, -1.2]
        self.zlpos = [1.2, -1.2]

        # 字体颜色, default = 'black'
        self.font_color = font_color if font_color else plt.rcParams["axes.labelcolor"]  #
        # 字体大小, default = 20l
        self.font_size = font_size

        # 布洛赫矢量的颜色列表, default = ['b','g','r','y']l
        self.vector_color = ["#dc267f", "#648fff", "#fe6100", "#785ef0", "#ffb000"]
        #: 布洛赫矢量的宽度, default = 5
        self.vector_width = 5
        #: 布洛赫矢量的风格, default = '-|>' (or 'simple')
        # self.vector_style = "-|>"
        self.vector_style = "-|>"
        #: 设置矢量箭头的宽度
        self.vector_mutation = 20

        # 布洛赫点标记的颜色列表, default = ['b','g','r','y']
        self.point_color = ["b", "r", "g", "#CC6600"]
        # 点标记的大小, default = 25
        self.point_size = [25, 32, 35, 45]
        # 点标记的形状, default = ['o','^','d','s']
        self.point_marker = ["o", "s", "d", "^"]

        # 点标记数据
        self.points = []
        # 布洛赫矢量数据
        self.vectors = []
        self.annotations = []
        # 球体保存的次数
        self.savenum = 0
        # 点的样式，'m'表示多色，'s'表示单色
        self.point_style = []
        # 渲染状态
        self._rendered = False

        self.imgtitle = None  # 设置图片标题
        self.imgfilename = None  # 设置图片保存名称

    # 查看bloch球的绘图样式 11.11
    def get_bloch_style(self):
        """
        查看绘图样式
        """
        style_dic = {'图像尺寸': self.figsize, '视图（方位角/仰俯角）': self.view, '颜色渲染': self.cmap,
                     '字体尺寸': self.font_size, '球体透明度': self.sphere_transparency,
                     '线框颜色': self.frame_color, '线框宽度': self.frame_width, '字体颜色': self.font_color,
                     }
        print(style_dic)
        return style_dic

    # 设置绘图样式 1112
    def set_bloch_style(self, figsize=None, view=None, cmap=None, font_size=None, sphere_transparency=None,
                        frame_color=None, frame_width=None, font_color=None):
        """
        设置绘图样式
        """
        self.figsize = figsize if figsize is not None else self.figsize
        self.view = view if view is not None else self.view
        self.cmap = cmap if cmap is not None else self.cmap
        self.font_size = font_size if font_size is not None else self.font_size
        self.sphere_transparency = sphere_transparency if sphere_transparency is not None else self.sphere_transparency
        self.frame_color = frame_color if frame_color is not None else self.frame_color
        self.frame_width = frame_width if frame_width is not None else self.frame_width
        self.font_color = font_color if font_color is not None else self.font_color

    def save_img(self, filename):  # 可视化图像保存
        """
        设置保存图名称，在draw_vector或者draw_trace时候传入
        """
        self.imgfilename = filename

    def set_bloch_title(self, title):  # 设置标题
        """
        设置球标题，在draw_vector或者draw_trace时候传入展示
        """
        self.imgtitle = title
        # print(self.fig)
        # self.fig.suptitle(title)

    def save_gif(self, saveas):  # 可视化动图保存 saveas是保存的路径，‘trace.gif’则保存到当前路径下的trace.gif动图
        self.saveas = saveas

    def draw_vector(self, title=""):  # 1213 画静态向量
        """
        Bloch球静态展示
        """
        if self._rendered:
            self.axes.clear()

        self._rendered = True

        # 绘制bloch球的画布（figure）实例
        if not self._ext_fig:
            self.fig = plt.figure(figsize=self.figsize)  # 建画布

        if not self._ext_axes:
            if tuple(int(x) for x in matplotlib.__version__.split(".")[:-1]) >= (3, 4, 0):
                self.axes = Axes3D(  # 这里对axes进行了初始化
                    self.fig, azim=self.view[0], elev=self.view[1], auto_add_to_figure=False
                )
                self.fig.add_axes(self.axes)  # 只有加上这句才能在绘图区（figure）上show出来
            else:
                self.axes = Axes3D(  # 这里对axes进行了初始化
                    self.fig,
                    azim=self.view[0],
                    elev=self.view[1],
                )

        self.plot_axes()  # 进到这里，画轴 plot_axes 换个名字 画轴/绘图区域
        self.axes.set_axis_off()
        self.axes.set_xlim3d(-0.7, 0.7)
        self.axes.set_ylim3d(-0.7, 0.7)
        self.axes.set_zlim3d(-0.7, 0.7)

        # Force aspect ratio
        # MPL 3.2 or previous do not have set_box_aspect
        if hasattr(self.axes, "set_box_aspect"):
            self.axes.set_box_aspect((1, 1, 1))

        self.axes.grid(False)
        self.plot_sphere_b()  # 画球1：到这里,先画后半部分球，以及垂直于z轴的后半圆和垂直于真实x轴（图中y轴）的上半圆。
        self.add_vectors(datas=self.bloch_data)  # 加入向量坐标
        self.plot_quantum_vectors()  # 画静态量子态只用到这个
        self.plot_sphere_f()  # 画球2：再画前半部分球，以及垂直于z轴的前半圆（赤道）和垂直于真实x轴（图中y轴）的下半圆（赤道）。
        self.plot_axes_labels()  # 画坐标轴：名称及位置
        # self.plot_trajectory_annotations() # 画动态轨迹的时候显示当前轨迹的门注释
        self.axes.set_title(title, fontsize=self.font_size, y=1.08)  # 设置这个坐标轴的标签
        # 设置图片标题
        if self.imgtitle is not None:
            self.fig.suptitle(self.imgtitle, fontsize=self.font_size, y=0.05)
        # 设置图片保存
        if self.imgfilename is not None:
            self.fig.savefig(self.imgfilename)
        # 要不要加plt.show()
        plt.show()

    def draw_trace(self, title=""):  # 1213 画动态轨迹
        """
        Bloch球动态展示
        """
        if len(self.list_of_circuit_gates) == 0:
            raise RuntimeError("Nothing to visualize.")  # 没门
        self.starting_pos = normalize(np.array([0, 0, 1]))  # array [0 0 1]
        if self._rendered:
            self.axes.clear()

        self._rendered = True

        # 绘制bloch球的画布（figure）实例
        if not self._ext_fig:
            self.fig = plt.figure(figsize=self.figsize)  # 建画布

        if not self._ext_axes:
            if tuple(int(x) for x in matplotlib.__version__.split(".")[:-1]) >= (3, 4, 0):
                self.axes = Axes3D(  # 这里对axes进行了初始化
                    self.fig, azim=self.view[0], elev=self.view[1], auto_add_to_figure=False
                )
                self.fig.add_axes(self.axes)  # 只有加上这句才能在绘图区（figure）上show出来
            else:
                self.axes = Axes3D(  # 这里对axes进行了初始化
                    self.fig,
                    azim=self.view[0],
                    elev=self.view[1],
                )

        self.plot_axes()  # 进到这里，画轴 plot_axes 换个名字 画轴/绘图区域
        self.axes.set_axis_off()
        self.axes.set_xlim3d(-0.7, 0.7)
        self.axes.set_ylim3d(-0.7, 0.7)
        self.axes.set_zlim3d(-0.7, 0.7)

        # Force aspect ratio
        # MPL 3.2 or previous do not have set_box_aspect
        if hasattr(self.axes, "set_box_aspect"):
            self.axes.set_box_aspect((1, 1, 1))

        self.axes.grid(False)
        self.plot_sphere_b()  # 画球1：到这里,先画后半部分球，以及垂直于z轴的后半圆和垂直于真实x轴（图中y轴）的上半圆。
        self.plot_sphere_f()  # 画球2：再画前半部分球，以及垂直于z轴的前半圆（赤道）和垂直于真实x轴（图中y轴）的下半圆（赤道）。
        self.plot_axes_labels()  # 画坐标轴：名称及位置
        self.plot_circuit()
        # self.plot_trajectory_pnts() # 画量子态变化轨迹（动态量子态）用到add_points和这个plot_trajectory_pnts，
        # self.plot_trajectory_annotations() # 画动态轨迹的时候显示当前轨迹的门注释
        self.axes.set_title(title, fontsize=self.font_size, y=1.08)  # 设置这个坐标轴的标签
        # plt.show()

    def render(self, title=""):  # 渲染 这是一个主要函数
        """
        在给定的绘图区/画布（figure）和轴上渲染Blonch球体和上面的数据点
        画bloch球的必须项就是：画轴、画球体前半部分、画球体后半部分、轴标签
        """
        print("self._rendered", self._rendered)
        print("self._ext_fig", self._ext_fig)
        print("self._ext_axes", self._ext_axes)
        if self._rendered:
            self.axes.clear()

        self._rendered = True

        self.plot_axes()  # 进到这里，画轴 plot_axes 换个名字 画轴/绘图区域
        self.axes.set_axis_off()
        self.axes.set_xlim3d(-0.7, 0.7)
        self.axes.set_ylim3d(-0.7, 0.7)
        self.axes.set_zlim3d(-0.7, 0.7)

        if hasattr(self.axes, "set_box_aspect"):
            self.axes.set_box_aspect((1, 1, 1))

        self.axes.grid(False)
        self.plot_sphere_b()  # 画球1：到这里,先画后半部分球，以及垂直于z轴的后半圆和垂直于真实x轴（图中y轴）的上半圆。
        self.plot_trajectory_pnts()  # 画量子态变化轨迹（动态量子态）用到add_points和这个plot_trajectory_pnts，
        self.plot_quantum_vectors()  # 画静态量子态只用到这个
        self.plot_sphere_f()  # 画球2：再画前半部分球，以及垂直于z轴的前半圆（赤道）和垂直于真实x轴（图中y轴）的下半圆（赤道）。
        self.plot_axes_labels()  # 画坐标轴：名称及位置
        self.plot_trajectory_annotations()  # 画动态轨迹的时候显示当前轨迹的门注释
        self.axes.set_title(title, fontsize=self.font_size, y=1.08)  # 设置这个坐标轴的标签
        # 设置图片标题
        if self.imgtitle is not None:
            self.fig.suptitle(self.imgtitle, fontsize=self.font_size, y=0.05)

    def make_sphere(self):
        """
        Plots Bloch sphere and data sets.
        """
        self.render()

    def plot_axes(self):  # 1021
        """绘制域/画坐标轴"""
        extent = np.linspace(-1.0, 1.0, 2)  # 起始值-1，终止值1，生成2个数值，所以就是[-1,1]
        self.axes.plot(  # X轴固定写法，axes.plot（x,y,zs=0, zdir="z", label="X", lw=self.frame_width, color=self.frame_color)
            extent, 0 * extent, zs=0, zdir="z", label="X", lw=self.frame_width, color=self.frame_color
        )
        self.axes.plot(  # Y轴固定写法，axes.plot（x,y,zs=0, zdir="z", label="Y", lw=self.frame_width, color=self.frame_color)
            0 * extent, extent, zs=0, zdir="z", label="Y", lw=self.frame_width, color=self.frame_color
        )
        self.axes.plot(  # Z轴固定写法，axes.plot（x,z,zs=0, zdir="y", label="Z", lw=self.frame_width, color=self.frame_color)
            0 * extent, extent, zs=0, zdir="y", label="Z", lw=self.frame_width, color=self.frame_color
        )

    def plot_sphere_b(self):  # 1021
        """画球体的后半部分 """
        u_angle = np.linspace(0, np.pi,
                              25)  # pi拆成25份，u_angle是xoy平面的角度，与x正方向的夹角（但是在这里似乎是与y正方向的夹角），后半部分是（0，pi),前半部分是（-pi,0）
        v_angle = np.linspace(0, np.pi, 25)  # v_angle是z轴正方向的极角
        x_coordinate = np.outer(np.cos(u_angle), np.sin(v_angle))  # cos(u)sin(v)  bloch球的角度化为xyz坐标
        y_coordinate = np.outer(np.sin(u_angle), np.sin(v_angle))  # sin(u)sin(v)
        z_coordinate = np.outer(np.ones(u_angle.shape[0]), np.cos(v_angle))  # cos(v)

        self.axes.plot_surface(  # 球面
            x_coordinate,
            y_coordinate,
            z_coordinate,
            rstride=2,  # 行之间的跨度
            cstride=2,  # 列之间的跨度
            linewidth=0,
            alpha=self.sphere_transparency,  # 透明度transparency
            cmap=self.cmap  # 颜色渐变
        )

        # equator 赤道
        self.axes.plot(
            1.0 * np.cos(u_angle),  # u_angle是xoy平面的角度，与x正方向的夹角（但是在这里似乎是与y正方向的夹角），后半部分是（0，pi),前半部分是（-pi,0）
            1.0 * np.sin(u_angle),
            zs=0,
            zdir="z",  # 这里画的是标准赤道，与z轴垂直的后半圆赤道线。
            lw=self.frame_width,
            color=self.frame_color,
        )
        self.axes.plot(
            1.0 * np.cos(u_angle),
            1.0 * np.sin(u_angle),
            zs=0,
            zdir="x",  # 这里画的是垂直x轴的赤道线（这里的x是图中的y轴，所以是图中垂直于y轴的上半圆赤道线）
            lw=self.frame_width,
            color=self.frame_color,
        )

    def plot_sphere_f(self):  # 1021
        """画球体的前半部分"""
        u_angle = np.linspace(-np.pi, 0,
                              25)  # u_angle是xoy平面的角度，与x正方向的夹角（但是在这里是与y正方向的夹角,因为在对坐标轴打标签时偷偷换了x和y的标签），后半部分是（0，pi),前半部分是（-pi,0）
        v_angle = np.linspace(0, np.pi, 25)
        x_coordinate = np.outer(np.cos(u_angle), np.sin(v_angle))  # cos(u)sin(v)  bloch球的角度化为xyz坐标
        y_coordinate = np.outer(np.sin(u_angle), np.sin(v_angle))  # sin(u)sin(v)
        z_coordinate = np.outer(np.ones(u_angle.shape[0]), np.cos(v_angle))  # cos(v)

        self.axes.plot_surface(  # 画球面
            x_coordinate,
            y_coordinate,
            z_coordinate,
            rstride=2,
            cstride=2,
            # color=self.sphere_color,
            linewidth=0,
            alpha=self.sphere_transparency,
            # cmap='gist_gray'
            cmap=self.cmap
        )
        # 赤道
        self.axes.plot(  # u_angle = np.linspace(-np.pi, 0, 25)
            1.0 * np.cos(u_angle),  # x:+
            1.0 * np.sin(u_angle),  # y:-
            zs=0,
            zdir="z",  # 真正的赤道线，垂直于z轴的前半圆
            lw=self.frame_width,
            color=self.frame_color,
        )
        self.axes.plot(
            1.0 * np.cos(u_angle),  # x:+
            1.0 * np.sin(u_angle),  # y:-
            zs=0,
            zdir="x",  # 垂直于x轴的下半圆（图中的y）
            lw=self.frame_width,
            color=self.frame_color,
        )

    def plot_axes_labels(self):  # 其实就是在这里把x,y轴标签换了。为了展示起来更好看。
        """坐标轴标签"""
        opts = {
            "fontsize": self.font_size,
            "color": self.font_color,
            "horizontalalignment": "center",
            "verticalalignment": "center",
        }
        self.axes.text(0, -self.xlpos[0], 0, self.xlabel[0], **opts)  # Axes3D.text(x,y,z,string,**opts)
        self.axes.text(0, -self.xlpos[1], 0, self.xlabel[1], **opts)

        self.axes.text(self.ylpos[0], 0, 0, self.ylabel[0], **opts)
        self.axes.text(self.ylpos[1], 0, 0, self.ylabel[1], **opts)

        self.axes.text(0, 0, self.zlpos[0], self.zlabel[0], **opts)
        self.axes.text(0, 0, self.zlpos[1], self.zlabel[1], **opts)

        for item in self.axes.xaxis.get_ticklines() + self.axes.xaxis.get_ticklabels():
            item.set_visible(False)
        for item in self.axes.yaxis.get_ticklines() + self.axes.yaxis.get_ticklabels():
            item.set_visible(False)
        for item in self.axes.zaxis.get_ticklines() + self.axes.zaxis.get_ticklabels():
            item.set_visible(False)

    def plot_trajectory_pnts(self):  # 画轨迹点
        """画轨迹点"""
        # -X and Y data are switched for plotting purposes
        for k, point in enumerate(self.points):
            num = len(point[0])
            dist = [
                np.sqrt(point[0][j] ** 2 + point[1][j] ** 2 + point[2][j] ** 2) for j in range(num)
            ]

            if len(dist) != 0:  # 1206
                if any(abs(dist - dist[0]) / dist[0] > 1e-12):

                    zipped = list(zip(dist, range(num)))
                    zipped.sort()  # sort rates from lowest to highest
                    dist, indperm = zip(*zipped)
                    indperm = np.array(indperm)
                else:
                    indperm = np.arange(num)
                if self.point_style[k] == "s":
                    self.axes.scatter(
                        np.real(point[1][indperm]),
                        -np.real(point[0][indperm]),
                        np.real(point[2][indperm]),
                        s=self.point_size[np.mod(k, len(self.point_size))],
                        alpha=1,
                        edgecolor=None,
                        zdir="z",
                        color=self.point_color[np.mod(k, len(self.point_color))],
                        marker=self.point_marker[np.mod(k, len(self.point_marker))],
                    )

                elif self.point_style[k] == "m":
                    pnt_colors = np.array(self.point_color * math.ceil(num / len(self.point_color)))

                    pnt_colors = pnt_colors[0:num]
                    pnt_colors = list(pnt_colors[indperm])
                    marker = self.point_marker[np.mod(k, len(self.point_marker))]
                    pnt_size = self.point_size[np.mod(k, len(self.point_size))]
                    self.axes.scatter(
                        np.real(point[1][indperm]),
                        -np.real(point[0][indperm]),
                        np.real(point[2][indperm]),
                        s=pnt_size,
                        alpha=1,
                        edgecolor=None,
                        zdir="z",
                        color=pnt_colors,
                        marker=marker,
                    )

                elif self.point_style[k] == "l":
                    color = self.point_color[np.mod(k, len(self.point_color))]
                    self.axes.plot(
                        np.real(point[1]),
                        -np.real(point[0]),
                        np.real(point[2]),
                        alpha=0.75,
                        zdir="z",
                        color=color,
                    )
            else:
                return

    def add_vectors(self, datas):
        """添加向量列表.
        """
        # datas = self.bloch_data
        if isinstance(datas[0], (list, np.ndarray)):
            for vec in datas:
                self.vectors.append(vec)
        else:
            self.vectors.append(datas)

    def plot_quantum_vectors(self):  # 1021
        """Plot vector"""
        # -X and Y data are switched for plotting purposes
        for k, vector in enumerate(self.vectors):

            xs3d = vector[1] * np.array([0, 1])
            ys3d = -vector[0] * np.array([0, 1])
            zs3d = vector[2] * np.array([0, 1])

            color = self.vector_color[np.mod(k, len(self.vector_color))]

            if self.vector_style == "":
                # simple line style
                self.axes.plot(
                    xs3d, ys3d, zs3d, zs=0, zdir="z", label="Z", lw=self.vector_width, color=color
                )
            else:
                # decorated style, with arrow heads
                arr = Arrow3D(
                    xs3d,
                    ys3d,
                    zs3d,
                    mutation_scale=self.vector_mutation,
                    lw=self.vector_width,
                    arrowstyle=self.vector_style,
                    color=color,
                )

                self.axes.add_artist(arr)

    def clear(self):  # 1028
        """Resets Bloch sphere data sets to empty."""
        self.points = []
        self.vectors = []
        self.point_style = []
        self.annotations = []

    def plot_circuit(self):

        plot_parms = PlotParams()
        plot_parms.new_vec = self.starting_pos  # starting_pos=【0 0 1】

        def plot_flash(
                i):  # 画动画,这里的i是什么：是animation.FuncAnimation中frames参数传递过来的元素，也就是frames=range(20*len(list_of_circuit_gates)+1),总帧数的迭代器
            self.clear()

            gate_counter = (i - 1) // self.frames_per_gate  # 整除 （i-1）//20，确定是第几个门
            print('gate_counter', gate_counter)
            if gate_counter != plot_parms.last_gate:  # last_gate=-2 当i>=-20 或者 i<=-40，结果都不是-2，只有i<=-21且i>=-39,（i-1）//20的结果才是-2
                plot_parms.pnts.append([[], [], []])
                plot_parms.colors.append(self.list_of_circuit_gates[gate_counter][2])

            if i == 0:  # 第一帧
                self.add_vectors(datas=plot_parms.new_vec)
                plot_parms.pnts[0][0].append(plot_parms.new_vec[0])
                plot_parms.pnts[0][1].append(plot_parms.new_vec[1])
                plot_parms.pnts[0][2].append(plot_parms.new_vec[2])
                plot_parms.colors[0] = 'r'
                self.make_sphere()
                return self.axes
            plot_parms.new_vec = self.list_of_circuit_gates[gate_counter][1] * \
                                 plot_parms.new_vec

            # print('gate_counter+1',gate_counter+1) # 每个门的20个点(xyz)存在列表里 ###1030没加进去
            plot_parms.pnts[gate_counter + 1][0].append(plot_parms.new_vec[0])
            plot_parms.pnts[gate_counter + 1][1].append(plot_parms.new_vec[1])
            plot_parms.pnts[gate_counter + 1][2].append(plot_parms.new_vec[2])

            self.add_vectors(plot_parms.new_vec)  # 把1/20角度的新向量添加到列表中准备画出来
            for point_set in plot_parms.pnts:
                self.add_points([point_set[0], point_set[1], point_set[2]])  # 把点显示在球面上

            self.vector_color = [self.list_of_circuit_gates[gate_counter][2]]  # 向量颜色，每个门对应一种颜色
            self.point_color = plot_parms.colors  # 点的颜色，每个门对应一种颜色
            self.point_marker = 'o'  # 圆点

            annotation_text = self.list_of_circuit_gates[gate_counter][0]  # "x","y","z","h","s","v"等门的名称
            annotationvector = [1.4, -0.35, 1.5]  # 添加注释的位置
            # print('annotation_text',annotation_text)
            self.add_annotation(annotationvector,
                                annotation_text,
                                color=self.list_of_circuit_gates[gate_counter][2],
                                fontsize=25,
                                horizontalalignment='left')
            self.render()

            plot_parms.last_gate = gate_counter  # 门计数
            return self.axes

        def init():
            self.vector_color = ['r']
            return self.axes

        # animation.FuncAnimation()是matplotlib生成逐帧动画的常用类，它的工作原理就是按照一定时间间隔不断调用参数func对应的函数生成动画。
        ani = animation.FuncAnimation(self.fig, plot_flash,  # func=plot_flash 每一帧都需要调用的函数。可调用对象。必备参数。l
                                      range(self.frames_per_gate *
                                            len(self.list_of_circuit_gates) + 1),
                                      # frames=range(20*len(list_of_circuit_gates)+1),总帧数
                                      init_func=init,
                                      # 用于初始化帧的函数，在生成第1帧之前，会调用一次该函数。可调用对象。可选参数。如果不提供改参数， 将使用frames参数中的第一个元素的绘制结果。该参数的签名要求为def init_func() -> iterable_of_artists，除了参数，其余要求与func 参数类似。
                                      blit=False,  # 是否采用按叠放次序（zorder）优化绘图模式。布尔值。默认值为False。
                                      repeat=False,  # 当repeat 为True时生效。即动画重复执行的间隔毫秒数。当整数。默认值为0。
                                      interval=self.time_between_frames)  # 帧之间的间隔毫秒数。整数。time_between_frames = (secs_per_gate * 1000) / fps # （1*1000/20=50)
        if self.saveas:
            ani.save(self.saveas, fps=20)
        else:
            plt.show()
            plt.close(self.fig)
        # plt.show()
        # plt.close(self.fig)
        return None

    def add_points(self, points, meth="s"):  # 1028
        if not isinstance(points[0], (list, np.ndarray)):
            points = [[points[0]], [points[1]], [points[2]]]
        points = np.array(points)
        if meth == "s":
            if len(points[0]) == 1:
                pnts = np.array([[points[0][0]], [points[1][0]], [points[2][0]]])
                pnts = np.append(pnts, points, axis=1)
            else:
                pnts = points
            self.points.append(pnts)
            self.point_style.append("s")
        elif meth == "l":
            self.points.append(points)
            self.point_style.append("l")
        else:
            self.points.append(points)
            self.point_style.append("m")

    def add_annotation(self, state_or_vector, text, **kwargs):
        if isinstance(state_or_vector, (list, np.ndarray, tuple)) and len(state_or_vector) == 3:
            vec = state_or_vector
        else:
            raise Exception("Position needs to be specified by a qubit " + "state or a 3D vector.")
        self.annotations.append({"position": vec, "text": text, "opts": kwargs})

    def plot_trajectory_annotations(self):
        for annotation in self.annotations:
            vec = annotation["position"]
            opts = {
                "fontsize": self.font_size,
                "color": self.font_color,
                "horizontalalignment": "center",
                "verticalalignment": "center",
            }
            opts.update(annotation["opts"])
            self.axes.text(vec[1], -vec[0], vec[2], annotation["text"], **opts)

    def bloch_plot_dict(self):  # frames_per_gate是fps
        bloch_dict = dict()
        bloch_dict['X'] = ('X', PlotVector.from_axisangle(  # from_axisangle(theta=pi/fps,v=[1,0,0])返回[w,x,y,z]
            np.pi / self.frames_per_gate, [1, 0, 0]), '#1a8bbc')
        bloch_dict['Y'] = ('Y', PlotVector.from_axisangle(
            np.pi / self.frames_per_gate, [0, 1, 0]), '#c02ecc')
        bloch_dict['Z'] = ('Z', PlotVector.from_axisangle(
            np.pi / self.frames_per_gate, [0, 0, 1]), '#db7734')
        bloch_dict['S'] = (
            'S',
            PlotVector.from_axisangle(np.pi / 2 / self.frames_per_gate,  # 这里的第一个变量是把这个门作用引入的角度拆分成20（frames_per_gate）帧走完
                                      [0, 0, 1]), '#9b59b6')
        bloch_dict['SDG'] = ('SDG', PlotVector.from_axisangle(-np.pi / 2 / self.frames_per_gate, [0, 0, 1]),
                             '#8e44ad')
        bloch_dict['H'] = ('H', PlotVector.from_axisangle(np.pi / self.frames_per_gate, normalize([1, 0, 1])),
                           '#a96386')
        bloch_dict['T'] = ('T', PlotVector.from_axisangle(np.pi / 4 / self.frames_per_gate, [0, 0, 1]),
                           '#e74c3c')
        bloch_dict['TDG'] = ('TDG', PlotVector.from_axisangle(-np.pi / 4 / self.frames_per_gate, [0, 0, 1]),
                             '#c0392b')
        return bloch_dict


def normalize(v, tolerance=0.00001):
    mag2 = sum(n * n for n in v)  # x的话v=[1,0,0],mag2=1
    if abs(mag2 - 1.0) > tolerance:
        mag = sqrt(mag2)
        v = tuple(n / mag for n in v)
    return np.array(v)  # 把list[1,0,0]转换为数组[1 0 0]


class PlotVector:

    def __init__(self):
        self._val = None

    @staticmethod
    def from_axisangle(theta, v):
        v = normalize(v)  # [1,0,0] -> [1 0 0]

        new_quaternion = PlotVector()
        new_quaternion._axisangle_to_q(theta, v)
        return new_quaternion

    # @staticmethod
    def from_value(value):
        new_quaternion = PlotVector()
        new_quaternion._val = value
        return new_quaternion

    #
    def _axisangle_to_q(self, theta, v):  # 轴角表示转换为四元数旋转表示，四元数旋转与原向量左乘即可得到旋转后的新向量
        x = v[0]  # 1
        y = v[1]  # 0
        z = v[2]  # 0

        w = cos(theta / 2.)
        x = x * sin(theta / 2.)
        y = y * sin(theta / 2.)
        z = z * sin(theta / 2.)

        self._val = np.array([w, x, y, z])

    #
    def __mul__(self, b):  # 魔术方法不显示调用。当PlotVector的实例与另一个向量相乘*的时候，会调用这个方法

        if isinstance(b, PlotVector):
            return self._multiply_with_quaternion(b)
        elif isinstance(b, (list, tuple, np.ndarray)):
            if len(b) != 3:
                raise RuntimeError(
                    "Input vector has invalid length {0}".format(len(b)))
            return self._multiply_with_vector(b)
        else:
            raise RuntimeError(
                "Multiplication with unknown type {0}".format(type(b)))

    def _multiply_with_quaternion(self, q_2):
        w_1, x_1, y_1, z_1 = self._val
        w_2, x_2, y_2, z_2 = q_2._val
        w = w_1 * w_2 - x_1 * x_2 - y_1 * y_2 - z_1 * z_2
        x = w_1 * x_2 + x_1 * w_2 + y_1 * z_2 - z_1 * y_2
        y = w_1 * y_2 + y_1 * w_2 + z_1 * x_2 - x_1 * z_2
        z = w_1 * z_2 + z_1 * w_2 + x_1 * y_2 - y_1 * x_2

        result = PlotVector.from_value(np.array((w, x, y, z)))
        return result

    #
    def _multiply_with_vector(self, v):
        q_2 = PlotVector.from_value(np.append((0.0), v))
        return (self * q_2 * self.get_conjugate())._val[1:]

    #
    def get_conjugate(self):
        w, x, y, z = self._val
        result = PlotVector.from_value(np.array((w, -x, -y, -z)))
        return result


class PlotParams:
    def __init__(self):
        self.new_vec = []
        self.last_gate = -2
        self.colors = []
        self.pnts = []
