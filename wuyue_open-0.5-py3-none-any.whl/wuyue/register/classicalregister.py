# -*- coding: utf-8 -*-
import itertools
from .Bit import Bit
import random
class ClassicalRegister:
    """
    A Classical Register for Storing Quantum Circuit Calculation Results
    Args:
        count (int): The number of bits in a quantum register
        name (str): The name of the quantum register

    Raises:
        TypeError: if `count` is not positive integer.
        ValueError: if `name` is not string.

    Examples:
        from wuyue.register.classicalregister import ClassicalRegister
        qubit = ClassicalRegister(4)
        print(qubit._name)
        cbit0
        print(qubit.bit)
        [Bit(0, 'cbit0'), Bit(1, 'cbit0'), Bit(2, 'cbit0'), Bit(3, 'cbit0')]
    """
    instances_counter = itertools.count()
    def __init__(self,count,name=None):
        self._name = "cbit"
        if count > 0 and isinstance(count,int):
            self._bits = count
        else:
            raise ValueError("The number of register bits needs to be a positive integer")
        if name is None:
            self._name = "%s%i" % (self._name, next(self.instances_counter))
        else:
            try:
                self._name = str(name)
            except Exception:
                raise ValueError(
                    "The circuit name should be castable to a string ")

        self.bit = [Bit(self._name, i) for i in range(count)]

        self._hash = hash((type(self), self._name, self._bits,random.randint(0,1000)))
        self._repr = "%s(%d, '%s')" % (self.__class__.__qualname__, self._bits, self._name)

    def __repr__(self):
        """Return the official string representing the register."""
        return self._repr

    def __getitem__(self, item):
        """Return the specified classical bit by index"""
        if isinstance(item,int):
            return  self.bit[item]
        item = list(item)
        if max(item) > len(self):
            raise ValueError("register index out of range")
        return [self.bit[i] for i in item]

    def __len__(self):
        """Return register size."""
        return len(self.bit)

    def __iter__(self):
        """Return an iterable object"""
        for idx in range(self._bits):
            yield self.bit[idx]

    def __eq__(self, other):
        """Comparing with other classical registers"""
        try:
            return self._repr == other._repr and self._hash == other._hash and self is other
        except AttributeError:
            return False
