# -*- coding: utf-8 -*-
import itertools
from .Bit import Bit
import random
class QuantumRegister:
    """
    Quantum register for storing quantum gates.
    Args:
        count (int): The number of bits in a quantum register
        name (str): The name of the quantum register

    Raises:
        TypeError: if `count` is not positive integer.
        ValueError: if `name` is not string.

    Examples:
        from register.quantumregister import QuantumRegister
        qubit = QuantumRegister(4)
        print(qubit._name)
        qubit0
        print(qubit.bit)
        [Bit(0, 'qubit0'), Bit(1, 'qubit0'), Bit(2, 'qubit0'), Bit(3, 'qubit0')]
    """
    instances_counter = itertools.count()
    def __init__(self,count,name=None):
        self._name = "qubit"
        if count > 0 and isinstance(count,int):
            self._bits = count
        else:
            raise TypeError("The number of register bits needs to be a positive integer")
        if name is None:
            self._name = "%s%i" % (self._name, next(self.instances_counter))
        else:
            try:
                self._name = str(name)
            except Exception:
                raise ValueError(
                    "The circuit name should be castable to a string ")

        self.bit = [Bit(self._name, i) for i in range(count)]

        self._hash = hash((type(self), self._name, self._bits,random.randint(0,1000)))
        self._repr = "%s(%d, '%s')" % (self.__class__.__qualname__, self._bits, self._name)

    def __repr__(self):
        """Return the official string representing the register."""
        return self._repr

    def __getitem__(self, item):
        """Returns the specified qubit by index"""
        if isinstance(item,int):
            return  self.bit[item]
        item = list(item)
        if max(item) > len(self):
            raise ValueError("register index out of range")
        return [self.bit[i] for i in item]

    def __len__(self):
        """Return register size."""
        return len(self.bit)

    def __iter__(self):
        """Return an iterable object"""
        for idx in range(self._bits):
            yield self.bit[idx]

    def __eq__(self, other):
        """Comparing with other quantum registers"""
        try:
            return self._repr == other._repr and self._hash == other._hash and self._name == other._name
        except AttributeError:
            return False

