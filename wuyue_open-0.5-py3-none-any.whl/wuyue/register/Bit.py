# -*- coding: utf-8 -*-
# from ..element import Basicgate
import time

class Bit(list):
    """Implement a generic bit."""
    def __init__(self, name, number):
        list.__init__([])
        self.name = name
        self.number = number
        # Ensure that different registers are not equal
        self._hash = hash((time.time(),self.name,self.number))
        self._repr = "%s(%d, '%s')" % (self.__class__.__qualname__, self.number, self.name)
        self.labem_map = []

    def __repr__(self):
        return self._repr

    def append(self,gate):
        """Verify if the target bit is in the register position"""
        super().append(gate)

    def __add__(self, iterable):
        """circuit and circuit Addition operator."""
        self.extend(iterable)
        return self

    def __eq__(self, other):
        """Comparing with other Bits"""
        try:
            return self._repr == other._repr and self._hash == other._hash
        except AttributeError:
            return False
