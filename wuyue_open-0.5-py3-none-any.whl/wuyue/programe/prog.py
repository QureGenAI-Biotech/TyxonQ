# -*- coding: utf-8 -*-
import numpy as np
from ..element.gate import *
from ..element.noise import *
from ..element.decompose import resolve
from ..circuit.circuit import QuantumCircuit
from ..circuit.circuit import BARRIER,Readout_Noise,RESET
from ..circuit.parameters import Parameters,ParameterVector
from typing import Union,Tuple
from collections.abc import Iterable
import copy
import re
from ..register.classicalregister import ClassicalRegister
from ..register.quantumregister import QuantumRegister
from ..register.Bit import Bit
import itertools
class QuantumProg(object):
    """
    The quantum programe module.
     quantum program contains multiple Quantum circuit or registers, which contain one
    or more quantum gates and can be simulated and calculated in a quantum simulator.
    Build different quantum programs by combining different Quantum circuit or quantum gates.

    Args:
        qreg (QuantumRegister): A Quantum register for storing quantum gates
        creg (ClassicalRegister): A Classical Register for storing quantum computing results
        name (str) : A Quantum programe' name

    Raises:
        TypeError: If 'qreg' is not a QuantumRegister.
        TypeError: If 'creg' is not a ClassicalRegister.

    Examples:
        from wuyue.programe import QuantumProg
        from wuyue.register.classicalregister import ClassicalRegister
        from wuyue.register.quantumregister import QuantumRegister
        qubit = QuantumRegister(2)
        cbit = ClassicalRegister(2)
        q = QuantumProg(qubit, cbit)
        print(q.qreg)
        QuantumRegister(2, 'qubit0')
        print(q.creg)
        ClassicalRegister(2, 'cbit0')
        print(q.name)
        Programe0
    """
    instances_counter = itertools.count()
    def __init__(self, qreg: QuantumRegister , creg:ClassicalRegister,name = None):
        if isinstance(qreg,QuantumRegister):
            self.qreg = qreg
            self.qubits = len(self.qreg)
        else:
            raise TypeError("Quantum register must be of the QuantumRegister class")
        if isinstance(creg,ClassicalRegister):
            self.creg = creg
            for i in self.creg:
                i.append(0)
            self.cbits = len(self.creg)
        else:
            raise TypeError("Classical register must be of the ClassicalRegister class")

        self._gates = []
        self.gate_list =[CNOT, TOFFOLI, MEASURE, H,
                          X, Y, Z, T, S, RX, RY, RZ, P, CX, CZ, CCX, SWAP,U1,U2,U3,IsingZZ]
        self.noise_list = [BitFlip, PhaseFlip, PauliChannel, Depolarizing, AmplitudeDamping,
                           GeneralizedAmplitudeDamping,
                           PhaseDamping, TwoQubitDepolarizing, TwoQubitDephasing, ]
        self._end = False
        self.readout_noise = [[] for i in range(self.qubits)]
        self.readout_tag = False
        self.true = []
        self.false = []
        self.wlist = []
        self._start_state = None
        self.state = None
        self.label_map = [[] for i in range(len(self.qreg))]
        self.used_bits = []
        self.symbol_dagger = False
        self._use_parameters = []
        if name:
            self.name = name
        else:
            self.name = "Programe" + str(next(self.instances_counter))
        # change
        self.batch_size = None

    def __str__(self):
        """Return a string representation of the object."""
        self._repr = "%s(%s,%s)" % (self.__class__.__qualname__, str(self.qreg),str(self.creg))
        return self._repr

    def __repr__(self):
        return self.__str__()

    def cbit_set(self,index,value):
        """Set the value of a classic register"""
        self.creg[index][0] = value

    def all_add(self,operate,*args,**kwargs):
        """
        Apply quantum gates to all bits of quantum programe, only supports single bit gates.

        Args:
            gate (Basicgate): The quantum gate you want to apply
            paras (list): Parameters of quantum gates
            dagger (bool): Whether to perform Hermitian conjugation on quantum

        Raises:
            TypeError: If 'quantum gate' is not a single bit gates.

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumProg(qubit,cbit)
            q.all_add(H)
            q.all_add(X)
            q.draw()
            q0   ―――――――H――――――――――――――X―――――――

            q1   ―――――――H――――――――――――――X―――――――

            c    ――――――――――――――――――――――――――――――
            """
        if operate == MEASURE:
            for i in range(self.qubits):
                self.add(operate,target=self.qreg[i],cbit=self.creg[i])
        elif operate == BARRIER:
            for i in range(self.qubits):
                self.add(operate,target=self.qreg[i])
        #change
        elif operate == RESET:
            for i in range(self.qubits):
                self.add(operate,target=self.qreg[i])
        elif operate in [H,X,Y,Z,S,T,]:
            for i in range(self.qubits):
                self.add(operate, target=self.qreg[i],*args,**kwargs)
        elif operate in [RX,RY,RZ,P,U1,U2,U3]:
            for i in range(self.qubits):
                self.add(operate,target=self.qreg[i],*args,**kwargs)
        elif operate in self.noise_list and operate not in [TwoQubitDepolarizing,TwoQubitDephasing]:
            for i in range(self.qubits):
                self.add(operate, self.qreg[i],*args,**kwargs)
        else:
            raise TypeError("all_add only support one bit gate")

    def _bit_to_list(self,target,substring):
        if isinstance(target,Bit):
            target = [target]
        for i in target:
            if isinstance(i, int):
                continue
            if not isinstance(i, Bit):
                raise TypeError("Please use the correct register for the position of the operater")
            else:
                if i.name != substring:
                    raise TypeError("Please use the correct register for the position of the operater")
                tar_tag = re.findall('\d+', re.sub(substring, "", str(target)))
                target = [int(i) for i in tar_tag]
        return target

    def add(self, operate:Union[Basicgate, KrausOperation], target:Union[list, Bit], *args, **kwargs) -> object:
        """
        Adding Quantum Gates to Quantum Programe.

        Args:
            gate (Basicgate): The quantum gate you want to apply
            target (Bit): The Target position of quantum register to be applied
            control (Bit): The control position of quantum register to be applied
            paras (list): Parameters of quantum gates
            dagger (bool): Whether to perform Hermitian conjugation on quantum

        Raises:
            TypeError: If the target bits of quantum gates are of type other than Bit.
            TypeError: If the control bits of quantum gates are of type other than Bit.

        Returns：
            QuantumCircuit, The quantum programe with this quantum gate added.

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumProg(qubit,cbit)
            q.add(H,qubit[0]).add(H,qubit[1]).add(X,qubit[0]).add(X,qubit[1])
            q.draw()
            q0   ―――――――H――――――――――――――X―――――――

            q1   ―――――――H――――――――――――――X―――――――

            c    ――――――――――――――――――――――――――――――
                """
        if not isinstance(target, list):
            raise TypeError("The target bit can be of type list")
        substring = self.qreg._name
        target = self._bit_to_list(target, substring)

        if issubclass(operate,(Basicgate,BARRIER,RESET)):
            if operate == MEASURE:
                self._add_measure(target, *args, **kwargs)
            elif operate == BARRIER:
                self.qreg[target[0]].append(operate(target=target[0]))
            elif operate == RESET:
                self.qreg[target[0]].append(operate(target=target[0]))
            else:
                self._add_gate(operate, target, *args, **kwargs)
        elif issubclass(operate,KrausOperation):
            self._add_noise(operate, target, *args, **kwargs)
        elif issubclass(operate, Readout_Noise):
            noise = args[0](target, args[1])
            readout_noise = Readout_Noise(target=target,noise=noise)
            self.readout_tag = True
            self.readout_noise[target[0]].append(readout_noise.noise)
        else:
            raise TypeError("circuit need a current operate class")
        return self

    def _add_noise(self, nosie:KrausOperation, target:Union[list,QuantumRegister], *args, **kwargs):
        """Add a nosie operated to the circuit"""
        if len(set(target)) != len(target):
            raise ValueError("Target cannot have duplicate values")
        if issubclass(nosie, KrausOperation):
            _noise = nosie(target, *args, **kwargs)
            self.__insert_noise(_noise, target, qreg=None)


    def __insert_noise(self, noise, target, qreg=None):
        if qreg is None:
            qreg = self.qreg
        if len(target) > 1:
            pos1 = min(target)
            pos2 = max(target)
            qreg[pos1].append(noise)
            for i in range(pos1 + 1, pos2 + 1):
                qreg[i].append("ctrl")
            maxlayer = max([len(qreg[j]) for j in range(pos1, pos2 + 1)])
            for k in range(pos1, pos2 + 1):
                layeri = len(qreg[k])
                pos = layeri - 1
                if layeri != maxlayer:
                    for i in range(abs(layeri - maxlayer)):
                        qreg[k].insert(pos, None)
        else:
            qreg[target[0]].append(noise)

    def _add_measure(self, target, cbit:Union[ClassicalRegister,list], qreg=None):
        substring = self.creg._name
        cbit = self._bit_to_list(cbit,substring)
        if qreg is None:
            qreg = self.qreg

        if not self._end:
            maxdepth = max([len(qreg[i]) for i in range(self.qubits)])
            for gates in qreg:
                gates.extend([None] * (maxdepth - len(gates)))
            self._end = True

        if self.readout_tag and qreg == self.qreg:
            for idx,val in enumerate(self.readout_noise):
                if idx == target[0] and val != []:
                    qreg[target[0]].append(val[0])
                elif idx == target[0]:
                    qreg[target[0]].append(None)

        if len(target) > self.cbits:
            raise ValueError("index of cbit out of creg")
        elif len(cbit) == len(target):
            for i in range(len(target)):
                qreg[target[i]].append(MEASURE(target=[target[i]], cbit=[cbit[i]]))
        else:
            raise ValueError("The number of quantum register positions and classical register positions of the measurement gate is different")

    def _add_gate(self,gate,target,control: Union[list,QuantumRegister,None] = None, paras:Union[list,None]=None, dagger=False, qreg=None):
        """Adding Quantum Gates to Quantum Registers"""
        if qreg is None:
            qreg = self.qreg
        if control is not None:
            substring = self.qreg._name
            control = self._bit_to_list(control, substring)
            target_control = target + control
            if len(target_control) != len(set(target_control)):
                raise ValueError("There cannot be duplicate values in target and control")
        else:
            if len(target) != len(set(target)):
                raise ValueError("Target cannot have duplicate values")

        if paras is not None:
            try:
                iter(paras)
            except TypeError:
                paras = [paras]

        if self._end:
            self._end = False
            maxdepth = max([len(qreg[i]) for i in range(self.qubits)])
            for gatelist in qreg:
                gatelist.extend([None] * (maxdepth - len(gatelist)))
        if gate not in self.gate_list or gate == SWAP or gate == IsingZZ:
            self.__insert_qubit(gate, target, control, paras, dagger, qreg = qreg)
        else:
            if len(target) > 1:
                raise ValueError("The add function can only operate on one quantum gate")
            elif len(target) == 1:
                self.__insert_qubit(gate, target, control, paras, dagger, qreg = qreg)

    def mul_add(self,operate:Union[Basicgate, KrausOperation], target:Union[list, Bit], *args, **kwargs):
        """
        Apply quantum gates to multi bits of quantum circuits

        Args:
            gate (Basicgate): The quantum gate you want to apply
            target (list(Bit)): The Target position of quantum register to be applied
            control (list(Bit)): The control position of quantum register to be applied
            paras (list): Parameters of quantum gates
            dagger (bool): Whether to perform Hermitian conjugation on quantum
            bits (int): The number of bits for user quantum gates

        Raises:
            TypeError: If the target bits of quantum gates are of type other than Bit.
            TypeError: If the control bits of quantum gates are of type other than Bit.
            ValueError: If the number of bits in a custom quantum gate exceeds 3 bits.
            ValueError: The proportion of the number of quantum gate control bits to the number of target bits is inconsistent
            TypeError: If 'quantum gate' is not a reasonable quantum gate.

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(3)
            cbit = ClassicalRegister(3)
            q = QuantumProg(qubit,cbit)
            q.mul_add(H,qubit[0,1,2])
            q.mul_add(CNOT,qubit[1,2],qubit[0,1])
            q.draw()
            q0   ―――――――H――――――――――――――●――――――――――――――――――――――
                                       ┃
            q1   ―――――――H―――――――――――――CNOT――――――――――――●―――――――
                                                      ┃
            q2   ―――――――H――――――――――――――――――――――――――――CNOT―――――

            c    ―――――――――――――――――――――――――――――――――――――――――――――
                """
        # if not isinstance(target,list):
        #     raise TypeError("Please use the correct register index for the target bit")
        # else:
        #     for i in target:
        #         if isinstance(i, int):
        #             continue
        #         if not isinstance(i, Bit):
        #             raise TypeError("Please use the correct register index for the target bit")
        # if control is not None:
        #     if isinstance(control, Bit):
        #         raise TypeError("Please use the correct register index for the control bit")
        #     else:
        #         for i in control:
        #             if isinstance(i, int):
        #                 continue
        #             if not isinstance(i, Bit):
        #                 raise TypeError("Please use the correct register index for the control bit")

        if not isinstance(target,list):
            raise TypeError("The target bit can be of type list")
        substring = self.qreg._name
        target = self._bit_to_list(target,substring)

        if issubclass(operate, KrausOperation):
            if operate == TwoQubitDepolarizing or operate == TwoQubitDephasing:
                for index,value in enumerate(target):
                    if index/2 == 0:
                        self._add_noise(operate, target[index:index+2], *args, **kwargs)
            else:
                for i in target:
                    self._add_noise(operate, [i], *args, **kwargs)
            return self

        elif operate == MEASURE:
            self._add_measure(target, *args, **kwargs)
            return self

        elif operate == BARRIER:
            for i in target:
                self.qreg[i].append(BARRIER(target=i))
            return self

        elif operate == RESET:
            for i in target:
                self.qreg[i].append(RESET(target=i))
            return self

        elif issubclass(operate,Basicgate):
            self._mul_add_gate(operate, target, *args, **kwargs)
            return self
        else:
            raise TypeError("circuit need a current operate class")

    def _mul_add_gate(self, gate, target, control: Union[list,QuantumRegister,None] = None, paras:Union[list,None]=None, dagger=False):
        if control is not None:
            substring = self.qreg._name
            control = self._bit_to_list(control, substring)

        # if not isinstance(paras, list) and paras is not None:
        #     paras = [paras]

        if gate == SWAP or gate == IsingZZ:
            gate_qubit = 2
        elif issubclass(gate, Basicgate) and gate not in self.gate_list:
            raise TypeError("The add function cannot support Newgate")
        else:
            gate_qubit = 1

        if control:
            multiple = len(control) / len(target)
            for index,value in enumerate(target):
                if index % gate_qubit == 0:
                    _target = target[index: index + gate_qubit]
                    _control = control[int(index*multiple):int((index+gate_qubit)*multiple)]
                    self._add_gate(gate,target=_target,control=_control,paras=paras, dagger=dagger)

        else:
            if gate_qubit == 1:
                for i in target:
                    self._add_gate(gate, target=[i], paras=paras, dagger=dagger)
                return self
            else:
                for index,value in enumerate(target):
                    if index % gate_qubit == 0:
                        self._add_gate(gate, target=target[index: index + gate_qubit], paras=paras, dagger=dagger)

    def __insert_qubit(self, gate, target, control, paras, dagger,qreg):
        """Inserting quantum registers according to single bit and multi bit quantum gate classification"""
        if len(target) > 1 or (len(target) == 1 and control):
            if control:
                pos1 = min(min(control), min(target))
                pos2 = max(max(control), max(target))
            else:
                pos1 = min(target)
                pos2 = max(target)
            self.__insert(pos1, pos2, gate, target, control, paras, dagger,qreg)
            for i in range(pos1 + 1, pos2 + 1):
                qreg[i].append("ctrl")
            maxlayer = max([len(qreg[j]) for j in range(pos1, pos2 + 1)])
            for k in range(pos1, pos2 + 1):
                layeri = len(qreg[k])
                pos = layeri - 1
                if layeri != maxlayer:
                    for i in range(abs(layeri - maxlayer)):
                        qreg[k].insert(pos, None)
        elif len(target) == 1 and not control:
            self.__insert(max(target), max(target), gate, target, control, paras, dagger,qreg)

    def __insert(self, pos1, pos2, gate, target, control, paras, dagger,qreg):
        """Inserting quantum gates into quantum registers"""
        if paras is not None:
            for para in paras:
                if isinstance(para,Parameters) and para not in self._use_parameters:
                    self._use_parameters.append(para)
        for pos in range(pos1,pos2+1):
            if pos not in self.used_bits:
                self.used_bits.append(pos)
        if paras is not None:
            insert_gate = gate(target=target, ctrl=control, paras=paras, dagger=dagger)
            if insert_gate.batch_size != None:
                try:
                    self.set_batch(batch_size=insert_gate.batch_size)
                except ValueError:
                    raise ValueError(f"{insert_gate.name} batch_size is inconsistent with the previously batch_size")
            qreg[pos1].append(insert_gate)
            # qreg[pos1].append(gate(target=target, ctrl=control, paras=paras, dagger=dagger))
        else:
            qreg[pos1].append(gate(target=target, ctrl=control, dagger=dagger))

    @property
    def gates(self):
        return self._gates

    def dagger(self):
        """Obtaining Conjugate transpose of Quantum programe
        Raises:
            TypeError: If 'quantum gate' is measure gate.

        Returns:
            circuit (Quantumcircuit): Conjugate transpose of Quantum circuit

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumProg(qubit,cbit)
            q.add(H,qubit[0])
            q.add(RX,qubit[0],paras=[pi/2])
            q.add(Y,qubit[1])
            q.add(CNOT,qubit[1],qubit[0])
            q.draw()
            q0   ―――――――H――――――――――RX(1.571)――――――――――●―――――――
                                                      ┃
            q1   ―――――――Y――――――――――――――――――――――――――――CNOT―――――

            c    ―――――――――――――――――――――――――――――――――――――――――――――
            q.dagger()
            q.draw()
            q0   ―――――――●――――――――――RX†(1.571)―――――――――H―――――――
                        ┃
            q1   ――――――CNOT――――――――――――Y――――――――――――――――――――――

            c    ―――――――――――――――――――――――――――――――――――――――――――――
        """
        self.symbol_dagger = False if self.symbol_dagger else True
        use_bit = []
        for i in range(self.qubits):
            if len(self.qreg[i]) != 0:
                use_bit.append(i)
        maxdepth = max([len(self.qreg[i]) for i in use_bit])
        for i in use_bit:
            self.qreg[i].extend([None] * (maxdepth - len(self.qreg[i])))

        for i in range(self.qubits):
            # overturn
            self.qreg[i].reverse()
            # dagger
            for j in self.qreg[i]:
                if isinstance(j, MEASURE):
                    raise TypeError("Dagger does not support measure gate")
                elif isinstance(j, Basicgate):
                    j._dagger()
                elif isinstance(j, QuantumCircuit):
                    j.dagger()
        return self

    def __unfold_circuit(self):
        """Expanding quantum circuits into quantum gates"""
        self.temp_qreg = [[] for i in range(self.qubits)]

        for gate in self.temp_gates:
            if isinstance(gate, Parasgate):
                if isinstance(gate,IsingZZ):
                    self._add_gate(IsingZZ, gate.target, gate.ctrl, gate.paras,
                                   gate.dagger, self.temp_qreg)
                else:
                    self._add_gate(eval(gate.name), gate.target, gate.ctrl, gate.paras,
                                    gate.dagger, self.temp_qreg)
            elif isinstance(gate, Noparasgate) and not isinstance(gate, MEASURE):
                self._add_gate(eval(gate.name), gate.target, gate.ctrl, None,
                                gate.dagger, self.temp_qreg)
            elif isinstance(gate, Basicgate) and not isinstance(gate, MEASURE):
                temp_matrix = gate.old_matrix
                gate1 = usergate(gate.symbol,temp_matrix)
                self._add_gate(gate1, gate.target, gate.ctrl, None,
                                gate.dagger, self.temp_qreg)
            elif isinstance(gate, MEASURE):
                self._add_measure(gate.target, gate.cbit,self.temp_qreg)
            elif isinstance(gate, BARRIER):
                self.temp_qreg[gate.target[0]].append(BARRIER(target=gate.target))
            elif isinstance(gate, RESET):
                self.temp_qreg[gate.target[0]].append(RESET(target=gate.target))
            elif isinstance(gate,KrausOperation):
                self.__insert_noise(gate, gate.targets, self.temp_qreg)
            elif isinstance(gate,QIF):
                maxdepth = max([len(self.temp_qreg[i]) for i in range(self.qubits)])
                for i in self.temp_qreg:
                    i.extend([None] * (maxdepth - len(i)))
                self.temp_qreg[0].append(QIF(gate.condition, gate.true_lens, gate.false_lens))
                maxdepth = max([len(self.temp_qreg[i]) for i in range(self.qubits)])
                for i in self.temp_qreg:
                    i.extend([None] * (maxdepth - len(i)))

            elif isinstance(gate, QWHILE):
                maxdepth = max([len(self.temp_qreg[i]) for i in range(self.qubits)])
                for i in self.temp_qreg:
                    i.extend([None] * (maxdepth - len(i)))
                self.temp_qreg[0].append(QWHILE(gate.condition, gate.while_lens, gate.count,gate.count_expression))
                maxdepth = max([len(self.temp_qreg[i]) for i in range(self.qubits)])
                for i in self.temp_qreg:
                    i.extend([None] * (maxdepth - len(i)))
            elif gate == "end;" or gate == "else:":
                maxdepth = max([len(self.temp_qreg[i]) for i in range(self.qubits)])
                for i in self.temp_qreg:
                    i.extend([None] * (maxdepth - len(i)))

        maxdepth = max([len(self.temp_qreg[i]) for i in range(self.qubits)])
        for i in self.temp_qreg:
            i.extend([None] * (maxdepth - len(i)))
        return self.temp_qreg

    def __complete_circuit(self):
        """Aligning quantum gates in quantum programe"""
        maxdepth = max([len(self.qreg[i]) for i in range(self.qubits)])
        for i in self.qreg:
            i.extend([None] * (maxdepth - len(i)))

    def set_batch(self, batch_size):
        if not isinstance(batch_size, int) or batch_size <= 0:
            raise ValueError("batch_size must be a positive integer")

        if self.batch_size is None:
            self.batch_size = batch_size
        else:
            if self.batch_size != batch_size:
                raise ValueError("batch_size is inconsistent with the previously batch_size")

    def apply_circuit(self):
        """Import the quantum gates of the Quantum circuit into the list in turn
         Raises:
            TypeError: If 'quantum gate' is not a reasonable quantum gate.

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(3)
            cbit = ClassicalRegister(3)
            q = QuantumProg(qubit,cbit)
            q.mul_add(H,qubit[0,1,2])
            q.mul_add(CNOT,qubit[1,2],qubit[0,1])
            print(q.gates)
            []
            q.apply_circuit()
            print(q.gates)
            [H, H, H, CNOT, CNOT]
        """
        self.__complete_circuit()
        self.__get_tempgates()
        self.__unfold_circuit()
        conver = np.asarray(self.temp_qreg)
        self._gates = []
        for i in range(conver.shape[1]):
            gate_col = conver[:, i]
            for gate in gate_col:
                if isinstance(gate, Basicgate) or isinstance(gate, QIF) or isinstance(gate, QWHILE) or isinstance(gate, KrausOperation) or isinstance(gate,(BARRIER,RESET)):
                    self._gates.append(gate)
                elif gate==None or gate=="ctrl":
                    continue
                else:
                    raise TypeError(
                        f"Gates needs {type(self.gates).__name__} was provided."
                    )


    def __get_tempgates(self):
        """Import the quantum gates of the Quantum circuit into the temp_gates list in turn"""
        self.temp_gates = []
        true_count,false_count,while_count=0,0,0

        temp_qreg = copy.deepcopy(self.qreg)
        maxdepth = max([len(temp_qreg[i]) for i in range(self.qubits)])
        for i in temp_qreg:
            i.extend([None] * (maxdepth - len(i)))
        conver = np.array(temp_qreg)

        for i in range(conver.shape[1]):
            gate_col = conver[:, i]
            for gate in gate_col:
                if isinstance(gate, Basicgate) :
                    self.temp_gates.append(gate)
                    true_count -= 1
                    while_count -= 1
                    if true_count == 0:
                        self.temp_gates.append("end;")
                    elif true_count == false_count:
                        self.temp_gates.append("else:")
                    if while_count == 0:
                        self.temp_gates.append("end;")
                elif isinstance(gate,(BARRIER,RESET)):
                    self.temp_gates.append(gate)
                elif isinstance(gate,KrausOperation):
                    self.temp_gates.append(gate)
                elif isinstance(gate, QuantumCircuit):
                    gate.get_tempgates()
                    for j in gate.temp_gates:
                        self.temp_gates.append(j)
                elif isinstance(gate, QIF):
                    false_count = gate.false_lens
                    true_count = gate.true_lens+false_count
                    self.temp_gates.append(gate)
                elif isinstance(gate, QWHILE):
                    while_count = gate.while_lens
                    self.temp_gates.append(gate)
        return conver

    def draw(self):
        """Quantum programe display

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(3)
            cbit = ClassicalRegister(3)
            q = QuantumProg(qubit,cbit)
            q.mul_add(H,qubit[0,1,2])
            q.mul_add(CNOT,qubit[1,2],qubit[0,1])
            q.draw()
            q0   ―――――――H――――――――――――――●――――――――――――――――――――――
                                       ┃
            q1   ―――――――H―――――――――――――CNOT――――――――――――●―――――――
                                                      ┃
            q2   ―――――――H――――――――――――――――――――――――――――CNOT―――――

            c    ―――――――――――――――――――――――――――――――――――――――――――――
        """
        self.__get_tempgates()
        self.__unfold_circuit()
        columns = list(zip(*self.temp_qreg))  # 结果为元组构成的列表
        draw_list = [list(col) for col in columns]  # 转换为列表
        # draw_list = np.array(self.temp_qreg)
        # print(draw_list)
        # 构建线路字符画字符串数组和辅助字符串组
        draw_str = [[] for i in range(self.qubits)]
        sup_str = [[] for i in range(self.qubits)]
        for j in range(len(self.qreg)):
            draw_str[j].append(("q%d"%j).ljust(5, " "))
            sup_str[j].append("     ")
        num = 0
        while_lens=-1
        true_lens=-2
        false_lens=-1
        for i in range(len(draw_list)):
            gate_col = draw_list[i]
            measure = 0
            U3_tag,U2_tag = 0,0
            for temp_gate in gate_col:
                if isinstance(temp_gate,U2):
                    U2_tag = 1
                elif isinstance(temp_gate,U3):
                    U3_tag = 1
                    break
            if U3_tag == 1:
                length = 25
            elif U2_tag ==1 :
                length =20
            else:
                length=15
            if while_lens==0 or true_lens==0:
                for k in range(len(gate_col)):
                    draw_str[k].append("┊end┊")
                    sup_str[k].append("┊   ┊")
                true_lens -=1
            elif true_lens==false_lens:
                for k in range(len(gate_col)):
                    draw_str[k].append("┊else┊")
                    sup_str[k].append("┊    ┊")
            for j in range(len(gate_col)):
                if isinstance(gate_col[j], Basicgate):
                    while_lens -= 1
                    true_lens -= 1
                    if isinstance(gate_col[j], Parasgate):
                        temp_paras = []
                        if gate_col[j].batch_size is None:
                            for paras_gate in gate_col[j].paras:
                                if not isinstance(paras_gate, Parameters):
                                    if isinstance(paras_gate, autograd.numpy.numpy_boxes.ArrayBox):
                                        temp_paras.append("%.3f" % paras_gate._value)
                                    else:
                                        temp_paras.append("%.3f" % paras_gate)
                                else:
                                    if paras_gate.value is None:
                                        temp_paras.append(f"{paras_gate.name}")
                                    else:
                                        temp_paras.append(f"{paras_gate.value:.3f}")
                        else:
                            temp_paras.append("batch")

                        symbol = gate_col[j].symbol + "(" + ",".join(temp_paras) + ")"
                    else:
                        symbol = gate_col[j].symbol
                    if gate_col[j].ctrl:
                        target = gate_col[j].target
                        control = gate_col[j].ctrl
                        pos1 = min(min(target), min(control))
                        pos2 = max(max(target), max(control))
                        for k in range(pos1,pos2+1):
                            if k in target:
                                draw_str[k].append(symbol.center(length, "-"))
                            elif k in control:
                                draw_str[k].append("●".center(length, "-"))
                            else:
                                draw_str[k].append("┃".center(length, "-"))

                            if k<pos2:
                                sup_str[k].append("┃".center(length, " "))
                            else:
                                sup_str[k].append(" ".center(length, " "))
                        num = pos2-pos1
                    else:
                        target = gate_col[j].target
                        if symbol == "(X)":
                            pos1 = min(target)
                            pos2 = max(target)
                            for k in range(pos1, pos2+1):
                                if k in target:
                                    draw_str[k].append("(X)".center(length, "-"))
                                else:
                                    draw_str[k].append("┃".center(length, "-"))
                                if k<pos2:
                                    sup_str[k].append("┃".center(length, " "))
                                else:
                                    sup_str[k].append(" ".center(length, " "))
                            num = pos2-pos1
                        elif gate_col[j].symbol == "IZZ":
                            pos1 = min(target)
                            pos2 = max(target)
                            for k in range(pos1, pos2 + 1):
                                if k in target:
                                    draw_str[k].append(symbol.center(length, "-"))
                                else:
                                    draw_str[k].append("┃".center(length, "-"))
                                if k < pos2:
                                    sup_str[k].append("┃".center(length, " "))
                                else:
                                    sup_str[k].append(" ".center(length, " "))
                            num = pos2 - pos1
                        elif gate_col[j].name == "NEW":
                            pos1 = min(target)
                            pos2 = max(target)
                            lens = len(gate_col[j].symbol)
                            for k in range(pos1, pos2 + 1):
                                if k in target:
                                    draw_str[k].append(("┃%s┃" % (gate_col[j].symbol)).center(length, "-"))
                                else:
                                    draw_str[k].append(("┃%s┃" % (" " * lens)).center(length, "-"))
                                if k < pos2:
                                    sup_str[k].append(("┃%s┃" % (" " * lens)).center(length, " "))
                                else:
                                    sup_str[k].append(" ".center(length, " "))
                            num = pos2-pos1
                        elif symbol=="MEASURE":
                            c = gate_col[j].cbit[0]
                            symbol = symbol + "[%d]"%c
                            draw_str[j].append(symbol.center(15, "-"))
                            sup_str[j].append("║".center(15, " "))
                            measure = 1
                        else:
                            draw_str[j].append(symbol.center(length, "-"))
                            sup_str[j].append(" ".center(length, " "))

                elif isinstance(gate_col[j],KrausOperation):
                    if isinstance(gate_col[j],(AmplitudeDamping,GeneralizedAmplitudeDamping,PhaseDamping)):
                        if isinstance(gate_col[j],GeneralizedAmplitudeDamping):
                            paras = [gate_col[j].gamma,gate_col[j].probability]
                            symbol = gate_col[j].symbol + "(" + ",".join(
                                ["%.1f" % i for i in paras]) + ")"
                        else:
                            symbol = gate_col[j].symbol + f"({gate_col[j].gamma})"
                    elif isinstance(gate_col[j], (PauliChannel,ResetNoise)):
                        symbol = gate_col[j].symbol + "(" + ",".join(["%.1f" % i for i in gate_col[j].probability]) + ")"
                    else:
                        symbol = gate_col[j].symbol + f"({gate_col[j].probability})"
                    if isinstance(gate_col[j],(TwoQubitDepolarizing,TwoQubitDephasing)):  # 两比特
                        target = gate_col[j].targets
                        pos1 = min(target)
                        pos2 = max(target)
                        for k in range(pos1, pos2 + 1):
                            if k in target:
                                draw_str[k].append(symbol.center(length, "-"))
                            else:
                                draw_str[k].append("┃".center(length, "-"))
                            if k < pos2:
                                sup_str[k].append("┃".center(length, " "))
                            else:
                                sup_str[k].append(" ".center(length, " "))
                        num = pos2 - pos1
                    else:
                        draw_str[j].append(symbol.center(length, "-"))
                        sup_str[j].append(" ".center(length, " "))

                elif isinstance(gate_col[j],BARRIER):
                    draw_str[j].append("BARRIER".center(length, "-"))
                    sup_str[j].append(" ".center(length, " "))

                elif isinstance(gate_col[j],RESET):
                    draw_str[j].append(r'|0>'.center(length, "-"))
                    sup_str[j].append(" ".center(length, " "))

                elif isinstance(gate_col[j], QWHILE):
                    while_lens = gate_col[j].while_lens

                    for k in range(len(gate_col)):
                        draw_str[k].append("┊while┊")
                        sup_str[k].append("┊     ┊")
                    break
                elif isinstance(gate_col[j], QIF):
                    false_lens = gate_col[j].false_lens
                    true_lens = gate_col[j].true_lens + false_lens
                    for k in range(len(gate_col)):
                        draw_str[k].append("┊if┊".center(length, "-"))
                        sup_str[k].append("┊  ┊".center(length, " "))
                    break
                else:
                    if num==0:
                        if measure:
                            draw_str[j].append("║".center(length, "-"))
                            sup_str[j].append("║".center(length, " "))
                        else:
                            draw_str[j].append("-".center(length, "-"))
                            sup_str[j].append(" ".center(length, " "))
                    else:
                        num-=1
        output = ""

        for i in range(len(draw_str)):
            lens = 0
            for j in draw_str[i]:
                lens+=len(j)
                output += j
            output += "\n"
            for k in sup_str[i]:
                output += k
            output += "\n"
        if self.creg:
            output  += "c    "
            output += "-"*(lens-5)
        print(output)
        return output

    def qif(self,condition):
        """
        Determine whether to execute quantum gates in quantum circuits
        based on the numerical value of classical registers

        Args:
            condition (str): Condition judgment for if operation

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumProg(qubit, cbit)
            q.cbit_set(0,1)
            q.trueif(H, qubit[0])
            q.trueif(H, qubit[1])
            q.falseif(X, qubit[0])
            q.falseif(X, qubit[1])
            q.qif(cbit[0] == 1)
            q.draw()
            q0   ――――――┊if┊――――――――――――H―――――――┊else┊―――――――X―――――――
                       ┊  ┊                    ┊    ┊
            q1   ――――――┊if┊――――――――――――H―――――――┊else┊―――――――X―――――――
                       ┊  ┊                    ┊    ┊
            c    ―――――――――――――――――――――――――――――――――――――――――――――――――――
                """
        self.__complete_circuit()

        self.qreg[0].append(QIF(condition,len(self.true),len(self.false)))
        self.__complete_circuit()

        self.__circuit_insert(self.true)
        self.__complete_circuit()

        self.__circuit_insert(self.false)
        self.__complete_circuit()
        # Clear quantum gates in the if_list
        self.false.clear()
        self.true.clear()

    def __circuit_insert(self,circuit):
        """Insert lines from the list into the quantum program"""
        for operate in circuit:
            # , gate.target, gate.ctrl, None,gate.dagger,
            if isinstance(operate,Parasgate):
                self.add(eval(operate.name),operate.target,operate.ctrl, operate.paras, operate.dagger)
            elif isinstance(operate,MEASURE):
                self.add(eval(operate.name), operate.target, operate.cbit)
            elif isinstance(operate,Noparasgate):
                self.add(eval(operate.name), operate.target, operate.ctrl, dagger = operate.dagger)
            elif isinstance(operate,(PhaseDamping, AmplitudeDamping)):
                self.add(eval(operate.name), operate.target, operate.gamma)
            elif isinstance(operate,GeneralizedAmplitudeDamping):
                self.add(eval(operate.name), operate.target, operate.gamma, operate.probability)
            elif isinstance(operate,KrausOperation):
                self.add(eval(operate.name), operate.target, operate.probability)

    # def trueif(self, gate, target, control=None, paras=None, dagger=False):
    def trueif(self, operate, target, *args, ** kwargs):

        """
        Quantum gates executed when the if operation is judged to be true

        Args:
            gate (Basicgate): The quantum gate you want to apply
            target (list(Bit)): The Target position of quantum register to be applied
            control (list(Bit)): The control position of quantum register to be applied
            paras (list): Parameters of quantum gates
            dagger (bool): Whether to perform Hermitian conjugation on quantum

        Raises:
            TypeError: If the target bits of quantum gates are of type other than Bit.
            TypeError: If the control bits of quantum gates are of type other than Bit.
            ValueError: If the number of bits in a custom quantum gate exceeds 3 bits.
            ValueError: The proportion of the number of quantum gate control bits to the number of target bits is inconsistent
            TypeError: If 'quantum gate' is not a reasonable quantum gate.

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumProg(qubit, cbit)
            q.cbit_set(0, 1)
            q.trueif(H, qubit[0])
            q.trueif(H, qubit[1])
            print(q.true)
            [[<class 'element.gate.H'>, Bit(0, 'qubit0'), None, None, False], [<class 'element.gate.H'>, Bit(1, 'qubit0'), None, None, False]]
        """
        target = self._bit_to_list(target, self.qreg._name)
        args = list(args)
        for index,value in enumerate(args):
            # if isinstance(value,Bit) or (isinstance(value,list) and isinstance(value[0],Bit)):
            if isinstance(value, (Bit, list)):
                if operate == MEASURE:
                    value = self._bit_to_list(value, self.creg._name)
                    del args[index]
                    kwargs["cbit"] = value
                else:
                    value = self._bit_to_list(value,self.qreg._name)
                    del args[index]
                    kwargs["ctrl"] = value
        args = tuple(args)

        for key, value in kwargs.items():
            if key == "ctrl":
                value = self._bit_to_list(value,self.qreg._name)
                kwargs[key] = value
            elif key == "cbit":
                value = self._bit_to_list(value,self.qreg._name)
                kwargs[key] = value
            elif key == "paras" and not isinstance(value,list):
                kwargs[key] = [value]
        if issubclass(operate, Noparasgate):
            if "paras" in kwargs.keys():
                del kwargs["paras"]
            _operate = operate(target=target, *args, **kwargs)
        else:
            _operate = operate(target=target, *args, **kwargs)
        # _operate = operate(target=target, *args, **kwargs)
        self.true.append(_operate)

    def falseif(self, operate, target, *args, ** kwargs):

        """
        Quantum gates executed when the if operation is judged to be false

        Args:
            gate (Basicgate): The quantum gate you want to apply
            target (list(Bit)): The Target position of quantum register to be applied
            control (list(Bit)): The control position of quantum register to be applied
            paras (list): Parameters of quantum gates
            dagger (bool): Whether to perform Hermitian conjugation on quantum

        Raises:
            TypeError: If the target bits of quantum gates are of type other than Bit.
            TypeError: If the control bits of quantum gates are of type other than Bit.
            ValueError: If the number of bits in a custom quantum gate exceeds 3 bits.
            ValueError: The proportion of the number of quantum gate control bits to the number of target bits is inconsistent
            TypeError: If 'quantum gate' is not a reasonable quantum gate.

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumProg(qubit, cbit)
            q.cbit_set(0, 1)
            q.falseif(X, qubit[0])
            q.falseif(X, qubit[1])
            print(q.false)
            [[<class 'element.gate.X'>, Bit(0, 'qubit0'), None, None, False], [<class 'element.gate.X'>, Bit(1, 'qubit0'), None, None, False]]
        """
        target = self._bit_to_list(target, self.qreg._name)
        args = list(args)
        for index,value in enumerate(args):
            if isinstance(value,Bit) or (isinstance(value,list) and isinstance(value[0],Bit)):
                if operate == MEASURE:
                    value = self._bit_to_list(value, self.creg._name)
                    del args[index]
                    kwargs["cbit"] = value
                else:
                    value = self._bit_to_list(value,self.qreg._name)
                    del args[index]
                    kwargs["ctrl"] = value
        args = tuple(args)

        for key, value in kwargs.items():
            if key == "ctrl":
                value = self._bit_to_list(value,self.qreg._name)
                kwargs[key] = value
            elif key == "cbit":
                value = self._bit_to_list(value,self.qreg._name)
                kwargs[key] = value
            elif key == "paras" and not isinstance(value,list):
                kwargs[key] = [value]
        _operate = operate(target=target, *args, **kwargs)
        self.false.append(_operate)

    def addwhile(self, operate, target, *args, ** kwargs):
        """
        Quantum gates executed when the while operation is judged to be true

        Args:
            gate (Basicgate): The quantum gate you want to apply
            target (list(Bit)): The Target position of quantum register to be applied
            control (list(Bit)): The control position of quantum register to be applied
            paras (list): Parameters of quantum gates
            dagger (bool): Whether to perform Hermitian conjugation on quantum

        Raises:
            TypeError: If the target bits of quantum gates are of type other than Bit.
            TypeError: If the control bits of quantum gates are of type other than Bit.
            ValueError: If the number of bits in a custom quantum gate exceeds 3 bits.
            ValueError: The proportion of the number of quantum gate control bits to the number of target bits is inconsistent
            TypeError: If 'quantum gate' is not a reasonable quantum gate.

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumProg(qubit, cbit)
            q.cbit_set(0,1)
            q.addwhile(H,qubit[0])
            q.addwhile(X,qubit[1])
            print(q.wlist)
            [[<class 'element.gate.H'>, Bit(0, 'qubit0'), None, None, False], [<class 'element.gate.X'>, Bit(1, 'qubit0'), None, None, False]]
        """
        target = self._bit_to_list(target, self.qreg._name)
        args = list(args)
        for index,value in enumerate(args):
            # if isinstance(value,Bit) or (isinstance(value,list) and isinstance(value[0],Bit)):
            if isinstance(value, (Bit,list)):
                if operate == MEASURE:
                    value = self._bit_to_list(value, self.creg._name)
                    del args[index]
                    kwargs["cbit"] = value
                else:
                    value = self._bit_to_list(value,self.qreg._name)
                    del args[index]
                    kwargs["ctrl"] = value
        args = tuple(args)

        for key, value in kwargs.items():
            if key == "ctrl":
                value = self._bit_to_list(value,self.qreg._name)
                kwargs[key] = value
            elif key == "cbit":
                value = self._bit_to_list(value,self.qreg._name)
                kwargs[key] = value
            elif key == "paras" and not isinstance(value,list):
                kwargs[key] = [value]
        if issubclass(operate,Noparasgate):
            if "paras" in kwargs.keys():
                del kwargs["paras"]
            _operate = operate(target=target, *args, **kwargs)
        else:
            _operate = operate(target=target, *args, **kwargs)
        self.wlist.append(_operate)

    def qwhile(self,condition, count, count_expression):
        """
        Determine whether to loop quantum gates in quantum circuits
        based on the values of classical registers

        Args:
            condition (str): Condition judgment for if operation
            count(Bit): Classic bit for calculating the number of execution cycles
            count_expression(Bit):Classic bit for calculating the number of expression

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            from wuyue.backend.backend import *
            from wuyue.visualization.plot_visual import Circuit_draw
            # 构建量子寄存器
            qubit = QuantumRegister(4)
            cbit = ClassicalRegister(5)
            # 构建量子程序
            q = QuantumProg(qubit, cbit)
            # 设置经典寄存器数值
            q.cbit_set(0, 1)
            # 添加量子门至while的循环体内
            q.addwhile(H, qubit[0])
            q.addwhile(H, qubit[1])
            q.addwhile(H, qubit[2])
            q.addwhile(H, qubit[3])
            q.addwhile(CNOT, qubit[1],qubit[0])
            q.addwhile(CNOT, qubit[2],qubit[1])
            q.addwhile(CNOT, qubit[3],qubit[2])
            q.addwhile(MEASURE, qubit[0],cbit[0])
            # 设置while判断
            q.qwhile("c[0] == 1", 4, "c[4]+1")
            # 量子线路绘制
            q.draw()
            q0   ┊while┊―――――――H――――――――――――――●――――――――――――――――――――――――――――――――――――――――MEASURE[0]――
                 ┊     ┊                      ┃                                            ║
            q1   ┊while┊―――――――H―――――――――――――CNOT――――――――――――●―――――――――――――――――――――――――――――║―――――――
                 ┊     ┊                                     ┃                             ║
            q2   ┊while┊―――――――H――――――――――――――――――――――――――――CNOT――――――――――――●――――――――――――――║―――――――
                 ┊     ┊                                                    ┃              ║
            q3   ┊while┊―――――――H―――――――――――――――――――――――――――――――――――――――――――CNOT――――――――――――║―――――――
                 ┊     ┊                                                                   ║
            c    ――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――
        """
        # count = self.__extract([count])
        count = [count]
        self.__complete_circuit()
        self.qreg[0].append(QWHILE(condition, len(self.wlist), count[0],count_expression))
        self.__complete_circuit()
        self.__circuit_insert(self.wlist)
        self.__complete_circuit()
        # Clear quantum gates in the wlist
        self.wlist.clear()

    def __check_qasm(self, qasm: str):

        """Check whether the Pseudocode passed in by the quantum compiler is correct"""
        # 提取并验证 OPENQASM 2.0 基本语法
        #  定义OPENQASM 2.0基本语法正则化表达式模式

        pattern_openqasm = r'^OPENQASM 2.0;$'
        pattern_include = r'^include "qelib1.inc";$'
        pattern_qreg = r'^qreg q\[\d+\];$'
        pattern_creg = r'^creg c\[\d+\];$'

        #  定义其他门正则化表达式模式
        #  ^抓取开头,$抓取结尾,*重复多次

        pattern_paras = r'^(ry|rz|rx|p|rydg|rzdg|rxdg|pdg)\([0-9pi+\-*/.]+\)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_u1paras = r'^(u1dg|u1)\([0-9pi+\-*/.]+\)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_u2paras = r'^(u2dg|u2)\([0-9pi+\-*/.]+\,[0-9pi+\-*/.]+\)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_u3paras = r'^(u3dg|u3)\([0-9pi+\-*/.]+\,[0-9pi+\-*/.]+\,[0-9pi+\-*/.]+\)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_one = r'^(h|t|s|x|y|z|barrier|reset|tdg|sdg|hdg|xdg|ydg|zdg)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_two = r'^(cx|cnot|cz|swap|cxdg|cnotdg|czdg|swapdg|izz|izzdg)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_three = r'^(ccx|toffoli|ccxdg|toffolidg)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_control = r'^(cnotrol)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_dagger = r'^(dagger|enddagger|endcnotrol);$'
        pattern_measure = r'^(measure)\s+q\[\d+\]\s*->\s*c\[\d+\];$'

        input_split = qasm.split("\n")
        # 改为从第四行开始校验其他门
        # input_split = lines[4:]

        # Validate the initial lines
        if not re.match(pattern_openqasm, input_split[0]):
            raise ValueError("The first line must be 'OPENQASM 2.0;'")
        if not re.match(pattern_include, input_split[1]):
            raise ValueError("The second line must be 'include \"qelib1.inc\";'")
        if not re.match(pattern_qreg, input_split[2]):
            raise ValueError("The third line must be 'qreg q[n];'")
        if not re.match(pattern_creg, input_split[3]):
            raise ValueError("The fourth line must be 'creg c[n];'")

        dagger_tage = 0
        control_tag = 0

        # 改为从第四行开始校验其他门
        for gate in input_split[4:]:

            if re.match(pattern_paras, gate) or re.match(pattern_one, gate) \
                    or re.match(pattern_two, gate) or re.match(pattern_u1paras, gate) \
                    or re.match(pattern_u2paras, gate) or re.match(pattern_u3paras, gate) \
                    or re.match(pattern_three, gate) or re.match(pattern_control, gate) \
                    or re.match(pattern_dagger, gate) or re.match(pattern_measure, gate):
                pass

            elif re.match(pattern_control, gate):
                gate_name, bits = gate.split(" ")
                if gate_name == "CONTROL" and control_tag == 0:
                    control_tag = 1
                elif gate_name == "CONTROL" and control_tag == 1:
                    raise ValueError("After CONTROL, it should be ENDCONTROL")

            else:
                raise ValueError("The input format is incorrect")

        if dagger_tage != 0 or control_tag != 0:
            raise ValueError("DAGGER and ENDDAGGER/CONTROL and ENDCONTROL need to match")

    def from_qasm(self, qasm: str):
        """Constructing Quantum circuit from quantum QASM code
        Raises:
            TypeError: If 'quantum gate' is not a reasonable quantum gate.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            qasm_code = ""OPENQASM 2.0;
            include "qelib1.inc";
            qreg q[2];
            creg c[2];
            h q[0];
            h q[1];
            cx q[1],q[0];""
            q.from_qasm(qasm_code)
            q.draw()
            q0   ―――――――H――――――――――――――CX――――――
                                       ┃
            q1   ―――――――H――――――――――――――●―――――――

            c    ――――――――――――――――――――――――――――――
            """
        if "\r" in qasm:
            qasm = qasm.replace("\r","")
        self.__check_qasm(qasm)
        input_split = qasm.split("\n")

        if not (input_split[0] == "OPENQASM 2.0;" and input_split[1] == 'include "qelib1.inc";'):
            raise ValueError("Incorrect prefix for QASM")
        qubits = re.findall("\d+", input_split[2])
        cbits = re.findall("\d+", input_split[3])
        if int(qubits[0]) > self.qubits or int(cbits[0]) > self.cbits:
            raise ValueError("QASM' bits is greater than the circuit' bits")

        input_split = input_split[4:]
        for gate in input_split:
            self._qasm_add_gate(gate)

    def from_qasm3(self, qasm: str):
        if "\r" in qasm:
            qasm = qasm.replace("\r","")
        # self.__check_qasm(qasm)
        input_split = qasm.split("\n")

        if not (input_split[0] == "OPENQASM 3.0;" and input_split[1] == 'include "stdgates.inc";'):
            raise ValueError("Incorrect prefix for QASM")
        qubits = re.findall("\d+", input_split[2])
        cbits = re.findall("\d+", input_split[3])
        if int(qubits[0]) > self.qubits or int(cbits[0]) > self.cbits:
            raise ValueError("QASM' bits is greater than the circuit' bits")
        while_tag = False
        if_tag = False
        for gate in input_split[4:]:
            if gate.startswith("while"):
                while_tag = True
                # while_gate = []
                gate_split = gate.split(" ")
                condition = gate_split[1].strip(")").strip("(")
                # 此处的condition后面的与qiskit逻辑不符合，可能出现问题
                while_run = f'self.qwhile("{condition}", {int(cbits[0])-1}, "c[{int(cbits[0])-1}]+1")'
            elif gate.startswith("if"):
                if_tag = True
                gate_split = gate.split(" ")
                condition = gate_split[1].strip(")").strip("(")
                if_run = f'self.qif("{condition}==1")'
            elif gate.startswith("}"):
                if while_tag:
                    while_tag = False
                    eval(while_run)
                elif if_tag:
                    if_tag = False
                    eval(if_run)
            elif while_tag:
                self._qasm_add_gate(gate, while_tag=True)
            elif if_tag:
                self._qasm_add_gate(gate, if_tag=True)
            else:
                self._qasm_add_gate(gate)


    def _qasm_add_gate(self,gate,while_tag=False,if_tag=False):
        # ctrl_tag = False
        if gate == "":
            return None
        gate_split = gate.split(" ")
        # paras
        if "(" in gate_split[0]:
            command, paras = gate_split[0].split("(")
            paras = paras.strip(")")
            paras = eval(paras, {"pi": np.pi})
            if isinstance(paras, tuple):
                paras = list(paras)
            else:
                paras = [paras]
        else:
            paras = None
            command = gate_split[0]

        if command[0] == "c" and command != "ccx" and command != "cx" and command != "cnot":
            command = command[1:]
            ctrl_tag = True

        dagger_dg = 'dg'
        if command.find(dagger_dg) != -1:
            command = command.strip(dagger_dg)
            dagger_flag = True
        else:
            dagger_flag = False

        command = eval(command.upper())

        if command == MEASURE:
            m_qubit = re.findall("\d+", gate_split[1])
            m_qubit = [int(i) for i in m_qubit]
            m_cbit = re.findall("\d+", gate_split[3])
            m_cbit = [int(i) for i in m_cbit]
            if while_tag:
                self.addwhile(MEASURE, m_qubit, m_cbit)
            elif if_tag:
                self.trueif(MEASURE, m_qubit, m_cbit)
            else:
                self.add(MEASURE, m_qubit, m_cbit)

        elif command == BARRIER:
            target = re.findall("\d+", gate_split[1])
            target = [int(i) for i in target]
            if while_tag:
                self.addwhile(BARRIER, target)
            elif if_tag:
                self.trueif(BARRIER, target)
            else:
                self.add(BARRIER, target)

        elif command == RESET:
            target = re.findall("\d+", gate_split[1])
            target = [int(i) for i in target]
            if while_tag:
                self.addwhile(RESET, target)
            elif if_tag:
                self.trueif(RESET, target)
            else:
                self.add(RESET, target)

        elif command == SWAP:
            target = re.findall("\d+", gate_split[1])
            target = [int(i) for i in target]

            if len(target) > 2:
                control = target[:-2]
                target = target[-2:]
                if while_tag:
                    self.addwhile(SWAP, target, control)
                elif if_tag:
                    self.trueif(SWAP, target, control)
                else:
                    self.add(SWAP, target, control)
            else:
                if while_tag:
                    self.addwhile(SWAP, target)
                elif if_tag:
                    self.trueif(SWAP, target)
                else:
                    self.add(SWAP, target)

        elif command == IsingZZ:
            target = re.findall("\d+", gate_split[1])
            target = [int(i) for i in target]

            if len(target) > 2:
                control = target[:-2]
                target = target[-2:]
                if while_tag:
                    self.addwhile(IsingZZ, target, control, paras=paras,dagger=dagger_flag)
                elif if_tag:
                    self.trueif(IsingZZ, target, control, paras=paras,dagger=dagger_flag)
                else:
                    self.add(IsingZZ, target, control, paras=paras,dagger=dagger_flag)
            else:
                if while_tag:
                    self.addwhile(IsingZZ, target, paras=paras,dagger=dagger_flag)
                elif if_tag:
                    self.trueif(IsingZZ, target, paras=paras,dagger=dagger_flag)
                else:
                    self.add(IsingZZ, target, paras=paras,dagger=dagger_flag)

        else:
            target = re.findall("\d+", gate_split[1])
            target = [int(i) for i in target]
            if len(target) > 1:
                control = target[:-1]
                target = [target[-1]]
                if while_tag:
                    self.addwhile(command, target, ctrl=control, paras=paras, dagger=dagger_flag)
                elif if_tag:
                    self.trueif(command, target, ctrl=control, paras=paras, dagger=dagger_flag)
                else:
                    self.add(command, target, control, paras=paras, dagger=dagger_flag)

            else:
                if while_tag:
                    self.addwhile(command, target, paras=paras, dagger=dagger_flag)
                elif if_tag:
                    self.trueif(command, target, paras=paras, dagger=dagger_flag)
                else:
                    self.add(command, target, paras=paras, dagger=dagger_flag)


    def get_gate_seq(self):
        self.gate_seq = []
        conver = self.__get_tempgates()
        for i in range(conver.shape[1]):
            gate_col = conver[:, i]
            self.gate_seq.append([])
            for j in range(len(gate_col)):
                if isinstance(gate_col[j], Basicgate):
                    self.gate_seq[i].append(gate_col[j])
        return self.gate_seq

    def QASM(self, addr=None, decompose=False):
        """Convert Quantum circuit into quantum QASM code

        Args:
            addr (str): Quantum QASM code storage address

        Raises:
            TypeError: If the address is not a string
            ValueError: If the address does not endwith '.txt'

        returns:
            result (str): Quantum QASM code

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            q.all_add(H)
            q.add(CX,qubit[0],qubit[1])
            print(q.QASM())
            'OPENQASM 2.0;
            include "qelib1.inc";
            qreg q[2];
            creg c[2];
            h q[0];
            h q[1];
            cx q[1],q[0];'
        """

        self.__get_tempgates()

        # QASM prefix
        result = ""
        result += "OPENQASM 2.0\n"
        result += 'include "qelib1.inc"\n'
        result += f"qreg q[{str(self.qubits)}]\n"
        result += f"creg c[{str(self.cbits)}]\n"

        # Print door information in sequence
        for gate in self.temp_gates:
            if isinstance(gate, BARRIER):
                symbol = "barrier q[%s]" % gate.target[0]
                symbol += "\n"
                result += symbol
                continue
            # if isinstance(gate, RESET):
            #     raise ValueError("QASM can not support reset")
            elif isinstance(gate, RESET):
                symbol = r'reset' + " q[%s]" % gate.target[0]
                symbol += "\n"
                result += symbol
                continue

            elif gate.name == "MEASURE":
                str1 = "measure" + " q[%d] -> c[%d]\n" % (gate.target[0], gate.cbit[0])
                result += str1
                continue

            if decompose:
                if isinstance(gate, Basicgate):
                    symbol = resolve(gate)
                    result += symbol
                    continue

            if gate.name == "NEW":
                raise ValueError(
                    "QASM does not support usergate,if usergate can be decomposed, please set parameter decompose to true")

            if gate.dagger == True:
                # 含参门U1门、U2门、U3门、RX门、RY门、RZ门、P门输出
                if isinstance(gate, Parasgate):
                    if gate.name == "U1" or gate.name == "U2" or gate.name == "U3":
                        symbol = gate.name.lower() + "dg" + "(" + ",".join(
                            ["%.3f" % i for i in gate.paras]) + ")" + " q[%s]" % gate.target[0]

                    else:
                        # to_pseudecode中为" q[%s]" % gate.target[0]，不然后面replace  q[%s]会留下逗号
                        symbol = gate.name.lower() + "dg" + "(" + ",".join(
                            ["%.3f" % i for i in gate.paras]) + ")" + " q[%s]" % gate.target[0]

                # 不含参门H门、X门、Y门、Z门、T门、S门、CX门、CZ门、CCX门、SWAP门输出
                else:
                    symbol = gate.name.lower() + "dg" + " q[%s]" % gate.target[0]

                if gate.ctrl:
                    # pos = gate.ctrl + gate.target
                    if symbol[0] != "C" and symbol != "TOFFOLI":
                        output = ",".join(["q[%s]" % i for i in gate.ctrl])
                        output = symbol.replace(" q[%s]" % gate.target[0], "") + " " + output

                        if gate.name == "SWAP":
                            output += " q[%s],q[%s]" % (gate.target[0], gate.target[1]) + '\n'
                        elif gate.name == "IZZ":
                            output += ",q[%s]" % (gate.target[1]) + '\n'
                        else:
                            output += ",q[%s]" % gate.target[0] + '\n'

                        result += output

                else:
                    if gate.name == "SWAP":
                        symbol = gate.name.lower() + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
                        result += symbol + '\n'
                    elif gate.name == "IZZ":
                        symbol += ",q[%s]" % (gate.target[1])
                        result += symbol + '\n'
                    else:
                        # str1 = symbol + " q[%s]" % gate.target[0]
                        str1 = symbol.lower()
                        result += (str1 + "\n")

            else:

                if isinstance(gate, Parasgate):
                    if gate.batch_size == None:
                        symbol = gate.name.lower() + "(" + ",".join(
                            ["%.3f" % i._value if isinstance(i, autograd.numpy.numpy_boxes.ArrayBox) else "%.3f" % i for
                             i in gate.paras]) + ")" + " q[%s]" % gate.target[0]
                    else:
                        # 多batchsize的情况理应产出不了QASM
                        raise ValueError(f"{gate.name} batch_size is not None")
                        # 多batchsize的情况可以输出QASM
                        # symbol = gate.name.lower() + "(" + ",".join(
                        #     ["batch"]) + ")" + " q[%s]" % gate.target[0]

                else:
                    symbol = gate.name.lower() + " q[%s]" % gate.target[0]

                if gate.ctrl:
                    # if len(gate.ctrl) > 1 and gate.symbol != "CCX" and gate.symbol != "TOFFOLI":
                    #     raise ValueError("QASM does not support 3 bits gate,except for ccx/toffoli")
                    pos = gate.ctrl + gate.target
                    if symbol[0] != "C" and symbol != "TOFFOLI":
                        # symbol = "C"+symbol

                        # 有几个控制位都能进行控制
                        output = ",".join(["q[%s]" % i for i in gate.ctrl])
                        output = symbol.replace(" q[%s]" % gate.target[0], "") + " " + output

                        if gate.name == "SWAP":
                            output += " q[%s],q[%s]" % (gate.target[0], gate.target[1]) + '\n'
                        elif gate.name == "IZZ":
                            output += ",q[%s]" % (gate.target[1])+ '\n'
                        else:
                            output += ",q[%s]" % gate.target[0] + '\n'

                        result += output

                    else:
                        result += gate.symbol + " " + ",".join(["q[%s]" % i for i in pos]) + "\n"

                else:
                    if gate.name == "SWAP":
                        symbol = gate.name.lower() + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
                        result += symbol + '\n'
                    elif gate.name == "IZZ":
                        symbol += ",q[%s]" % (gate.target[1])
                        result += symbol + '\n'
                    else:
                        # str1 = symbol + " q[%s]" % gate.target[0]
                        str1 = symbol.lower()
                        result += (str1 + "\n")

        # 分割每行输出
        lines = result.splitlines()
        # 添加尾缀
        result_list = [line + ';' for line in lines]

        result = '\n'.join(result_list)

        # The final output is judged, and the logic layer is the same level as the beginning
        if result.endswith("\n"):
            result = result.rstrip("\n")

        if addr is not None:
            if not isinstance(addr, str):
                raise TypeError("Address needs to be a string")
            if not addr.endswith(".txt"):
                raise ValueError("Address needs to end with'.txt'")
            # write file
            with open(addr, "w") as f:
                f.write(result)
        return result

    def QIR(self):
        """Convert Quantum circuit into quantum QIR code

        Args:
            addr (str): Quantum QIR code storage address

        Raises:
            TypeError: If the address is not a string
            ValueError: If the address does not endwith '.txt'

        returns:
            result (str): Quantum QIR code

        Examples:
            from wuyue.circuit import QuantumCircuit
            from register.classicalregister import ClassicalRegister
            from register.quantumregister import QuantumRegister
            from element.gate import *
            qubit = QuantumRegister(3)
            cbit = ClassicalRegister(3)
            q = QuantumCircuit(qubit, cbit)
            q.add(RX,qubit[0],qubit[1],paras=[np.pi/2])
            q.add(H, qubit[0], qubit[1])
            q.mul_add(CNOT, qubit[1, 2], qubit[0, 1])
            q.add(H, qubit[0]).add(H, qubit[1]).add(X, qubit[0]).add(X, qubit[1])
            q.add(CCX, qubit[0], qubit[1,2])
            q.add(SWAP, qubit[0,1],qubit[2])
            q.all_add(MEASURE)
            #q.draw()
            print(q.QIR())
            CONTROL q[1]
            RX q[0],(1.571)
            ENDCONTROL
            CONTROL q[1]
            H q[0]
            ENDCONTROL
            CNOT q[0],q[1]
            CNOT q[1],q[2]
            CCX q[1],q[2],q[0]
            CONTROL q[2]
            SWAP q[0],q[1]
            ENDCONTROL
            MEASURE q[0],c[0]
            MEASURE q[1],c[1]
            MEASURE q[2],c[2]
        """

        # QIR prefix
        self.__get_tempgates()

        result = ""
        for gate in self.temp_gates:
            if isinstance(gate,(QIF,QWHILE)):
                raise ValueError("QASM does not support QIF or QWHILE")

            if isinstance(gate,BARRIER):
                symbol = "BARRIER q[%s]"%gate.target[0]
                symbol += "\n"
                result += symbol
                continue

            if isinstance(gate,RESET):
                symbol = "RESET q[%s]"%gate.target[0]
                symbol += "\n"
                result += symbol
                continue

            if gate.name == "MEASURE":
                str1 = "MEASURE" + " q[%d],c[%d]\n" % (gate.target[0], gate.cbit[0])
                result += str1
                continue

            if gate.dagger == True:
                result += 'DAGGER\n'

            if gate.name == "NEW":
                raise ValueError("QIR does not support usergate")

            # 含参门输出
            if isinstance(gate,Parasgate):
                if gate.name == "U1" or gate.name == "U2" or gate.name == "U3":
                    raise ValueError(
                        f"QIR does not support {gate.name}")
                symbol = gate.name.upper()+ " q[%s]," % gate.target[0] + "(" + ",".join(["%.3f"%i for i in gate.paras]) + ")"

            # 不含参门输出
            else:
                symbol = gate.name.upper()+ " q[%s]" % gate.target[0]

            if gate.ctrl:
                pos = gate.ctrl + gate.target

                # print(pos)
                if symbol[0]!="C" and gate.symbol != "TOFFOLI":
                    output = 'CONTROL'+ " " + ",".join(["q[%s]"%i for i in gate.ctrl]) + "\n"
                    if gate.name == "SWAP":
                        symbol = gate.name + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
                    elif gate.name == "IZZ":
                        symbol = (gate.name + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
                                  + "(" + ",".join(["%.3f"%i for i in gate.paras]) + ")")
                    output += symbol + '\n'
                    result += output
                    result += 'ENDCONTROL\n'
                else:
                    result += gate.symbol +" " + ",".join(["q[%s]" % i for i in pos]) + "\n"

            else:
                if gate.name == "SWAP":
                    symbol = gate.name + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
                    result += symbol + '\n'
                elif gate.name == "IZZ":
                    symbol = (gate.name + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
                              + "(" + ",".join(["%.3f" % i for i in gate.paras]) + ")")
                    result += symbol + '\n'
                else:
                    result += (symbol+"\n")

            #单独与前gate.dagger进行判断
            if gate.dagger == True:
                result += 'ENDDAGGER\n'

        # The final output is judged, and the logic layer is the same level as the beginning
        if result.endswith("\n"):
            result = result.rstrip("\n")
        return result

    def to_pseudecode(self):
        """Convert Quantum circuit into quantum pseude code

        Args:
            addr (str): Quantum pseude code storage address

        Raises:
            TypeError: If the address is not a string
            ValueError: If the address does not endwith '.txt'

        returns:
            result (str): Quantum pseude code

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(3)
            cbit = ClassicalRegister(3)
            q = QuantumCircuit(qubit, cbit)
            q.add(P, qubit[0], qubit[1,2],paras=[np.pi/2],dagger=True)
            q.add(RX, qubit[0], qubit[1,2],paras=[np.pi/2],dagger=True)
            q.add(RY, qubit[0], qubit[1,2],paras=[np.pi/2],dagger=True)
            q.add(H, qubit[0], qubit[1,2])
            q.mul_add(CNOT, qubit[1,2], qubit[0,1])
            q.add(H, qubit[0]).add(H, qubit[1]).add(X, qubit[0]).add(X, qubit[1])
            q.add(CCX, qubit[0], qubit[1,2])
            q.add(TOFFOLI, qubit[0], qubit[1,2])
            q.add(SWAP, qubit[0,1],qubit[2])
            q.all_add(MEASURE)
            print(q.to_pseudecode())
            DAGGER
            P(1.571) q[1],q[2],q[0]
            ENDDAGGER
            DAGGER
            RX(1.571) q[1],q[2],q[0]
            ENDDAGGER
            DAGGER
            RY(1.571) q[1],q[2],q[0]
            ENDDAGGER
            H q[1],q[2],q[0]
            CNOT q[0],q[1]
            H q[0]
            CNOT q[1],q[2]
            X q[0]
            H q[1]
            X q[1]
            CCX q[1],q[2],q[0]
            CCX q[1],q[2],q[0]
            SWAP q[2],q[0],q[1]
            MEASURE q[0],c[0]
            MEASURE q[1],c[1]
            MEASURE q[2],c[2]
        """
        # pseudecode prefix
        self.__get_tempgates()
        result = ""
        # Print door information in sequence
        for gate in self.temp_gates:
            if isinstance(gate, BARRIER):
                symbol = "BARRIER q[%s]" % gate.target[0]
                symbol += "\n"
                result += symbol
                continue

            if isinstance(gate, RESET):
                symbol = "RESET q[%s]" % gate.target[0]
                symbol += "\n"
                result += symbol
                continue

            if gate.name == "MEASURE":
                str1 = "MEASURE" + " q[%d],c[%d]\n" % (gate.target[0], gate.cbit[0])
                result += str1
                continue

            if gate.name == "TOFFOLI":
                str1 = 'CCX' + " " + ",".join(["q[%s]" % i for i in gate.ctrl]) + \
                          ",q[%s]" % (gate.target[0]) + "\n"
                result += str1
                continue

            if gate.dagger == True:
                result += 'DAGGER\n'

            if gate.name == "NEW":
                raise ValueError("QASM does not support usergate")

            # 含参门输出
            if isinstance(gate, Parasgate):
                if gate.name == "U1" or gate.name == "U2" or gate.name == "U3":
                    raise ValueError(
                        f"QIR does not support {gate.name}")
                symbol = gate.name.upper() + "(" + ",".join(["%.3f" % i for i in gate.paras]) + ")" \
                         + " q[%s]" % gate.target[0]

            else:
                symbol = gate.name.upper() + " q[%s]" % gate.target[0]

            if gate.ctrl:
                pos = gate.ctrl + gate.target
                if symbol[0] != "C":
                    output =  ",".join(["q[%s]" % i for i in gate.ctrl])
                    output =  symbol.replace(" q[%s]" % gate.target[0], "") + " " + output
                    if gate.name == "SWAP":
                        output += ",q[%s],q[%s]" % (gate.target[0], gate.target[1]) + '\n'
                    elif gate.name == "IZZ":
                        output += (",q[%s],q[%s]" % (gate.target[0], gate.target[1])
                                   + "(" + ",".join(["%.3f" % i for i in gate.paras]) + ")" + '\n')
                    else:
                        output += ",q[%s]" % gate.target[0] + '\n'
                    result += output

                else:
                    result += gate.symbol + " " + ",".join(["q[%s]" % i for i in pos]) + "\n"
            else:
                if gate.name == "SWAP":
                    symbol = gate.name + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
                    result += symbol + '\n'
                elif gate.name == "IZZ":
                    symbol = (gate.name + ",q[%s],q[%s]" % (gate.target[0], gate.target[1])
                              + "(" + ",".join(["%.3f" % i for i in gate.paras]) + ")")
                    result += symbol + '\n'
                else:
                    str1 = symbol
                    result += (str1+"\n")

            # 单独与前gate.dagger进行判断
            if gate.dagger == True:
                result += 'ENDDAGGER\n'

        # The final output is judged, and the logic layer is the same level as the beginning
        if result.endswith("\n"):
            result = result.rstrip("\n")

        return result

    def __multikron(self, parameter: list):
        """Calculate the direct product of multiple matrices"""
        matrix = parameter[0]
        for i in parameter[1:]:
            matrix = np.kron(matrix, i)
        return matrix

    def __enlarge_two(self, ctrl, target, matrix):
        """Unitary matrix representation of 2-bit quantum gates"""
        I = np.array([[1, 0], [0, 1]], dtype=complex)
        m0 = np.array([[1, 0], [0, 0]], dtype=complex)
        m1 = np.array([[0, 0], [0, 1]], dtype=complex)
        # 理解：m0和m1为ctrl位置，I和matrix为target位置
        if ctrl > target:
            # target和ctrl相邻   U = [1,0;0,0]⊗I + [0,0;0,1]⊗matrix
            # target和ctrl不相邻 U = [1,0;0,0](⊗I⊗I...)⊗I + [0,0;0,1](⊗I⊗I...)⊗matrix
            length = ctrl - target
            for i in range(length - 1):
                m0 = np.kron(m0, I)
                m1 = np.kron(m1, I)
            matrix = np.kron(m0, I) + np.kron(m1, matrix)
        else:
            # target和ctrl相邻   U = I⊗[1,0;0,0] + matrix⊗[0,0;0,1]
            # target和ctrl不相邻 U = I(⊗I⊗I...)⊗[1,0;0,0] + matrix(⊗I⊗I...)⊗[0,0;0,1]
            length = target - ctrl
            # matrix = np.kron(I,m0) + np.kron(matrix,m1)
            I1 = I
            matrix1 = matrix
            for i in range(length - 1):
                I1 = np.kron(I1, I)
                matrix1 = np.kron(matrix1, I)
            matrix = np.kron(I1, m0) + np.kron(matrix1, m1)
        return matrix

    def __enlarge_three(self, ctrl, target, matrix):
        """Unitary matrix representation of 3 bit quantum gates"""
        I = np.array([[1, 0], [0, 1]], dtype=complex)
        m0 = np.array([[1, 0], [0, 0]], dtype=complex)
        m1 = np.array([[0, 0], [0, 1]], dtype=complex)
        ctrl.sort()
        # target = target[0]
        # 理解：m0和m1为ctrl位置，I和matrix为target位置
        # 可优化 将三种情况汇聚成一种 四个列表汇聚成一个
        if ctrl[0] > target:
            # ctrl * ctrl * target   U = [1,0;0,0]⊗[1,0;0,0]⊗I + [1,0;0,0]⊗[0,0;0,1]⊗I + [0,0;0,1]⊗[1,0;0,0]⊗I + [0,0;0,1]⊗[0,0;0,1]⊗matrix
            # ctrl (*I..) * ctrl (*I..) * target U = [1,0;0,0](⊗I⊗I...)⊗[1,0;0,0](⊗I⊗I...)⊗I.....
            list1, list2, list3, list4 = [m0, m0, I], [m0, m1, I], [m1, m0, I], [m1, m1, matrix]
            length1 = ctrl[0] - target
            length2 = ctrl[1] - ctrl[0]
            for i in range(length2 - 1):
                list1.insert(1, I)
                list2.insert(1, I)
                list3.insert(1, I)
                list4.insert(1, I)
            for i in range(length1 - 1):
                list1.insert(-1, I)
                list2.insert(-1, I)
                list3.insert(-1, I)
                list4.insert(-1, I)
            matrix = self.__multikron(list1) + self.__multikron(list2) + self.__multikron(list3) + self.__multikron(list4)
        elif ctrl[1] < target:
            # target * ctrl * ctrl U = I⊗[1,0;0,0]⊗[1,0;0,0] + I⊗[1,0;0,0]⊗[0,0;0,1] + I⊗[0,0;0,1]⊗[1,0;0,0] + matrix⊗[0,0;0,1]⊗[0,0;0,1]
            # target * ctrl (*I..) * ctrl (*I..) U = I⊗[1,0;0,0](⊗I⊗I...)⊗[1,0;0,0](⊗I⊗I...).....(同上)
            list1, list2, list3, list4 = [I, m0, m0], [I, m0, m1], [I, m1, m0], [matrix, m1, m1]
            length1 = target - ctrl[1]
            length2 = ctrl[1] - ctrl[0]
            for i in range(length1 - 1):
                list1.insert(1, I)
                list2.insert(1, I)
                list3.insert(1, I)
                list4.insert(1, I)
            for i in range(length2 - 1):
                list1.insert(-1, I)
                list2.insert(-1, I)
                list3.insert(-1, I)
                list4.insert(-1, I)
            matrix = self.__multikron(list1) + self.__multikron(list2) + self.__multikron(list3) + self.__multikron(list4)
        else:
            # ctrl * target * ctrl                 U = [1,0;0,0]⊗I⊗[1,0;0,0] + [1,0;0,0]⊗I⊗[0,0;0,1] + [0,0;0,1]⊗I⊗[1,0;0,0] + [0,0;0,1]⊗matrix⊗[0,0;0,1]
            # ctrl (*I..) * target * ctrl (*I..)  U = I⊗[1,0;0,0](⊗I⊗I...)⊗[1,0;0,0](⊗I⊗I...).....(同上)
            list1, list2, list3, list4 = [m0, I, m0], [m0, I, m1], [m1, I, m0], [m1, matrix, m1]
            length1 = target - ctrl[0]
            length2 = ctrl[1] - target
            for i in range(length1 - 1):
                list1.insert(1, I)
                list2.insert(1, I)
                list3.insert(1, I)
                list4.insert(1, I)
            for i in range(length2 - 1):
                list1.insert(-1, I)
                list2.insert(-1, I)
                list3.insert(-1, I)
                list4.insert(-1, I)
            matrix = self.__multikron(list1) + self.__multikron(list2) + self.__multikron(list3) + self.__multikron(list4)
        return matrix

    def get_matrix(self):
        """Unitary matrix expression for computing Quantum circuit
        Raises:
            TypeError: If 'Quantum circuit' have QIF or QWHILE
            TypeError: If 'Quantum circuit' have measurement gate
            ValueError: If 'Quantum circuit' is greater than 3 bits

        returns:
            matrix (numpy.array): Unitary matrix

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumProg(qubit, cbit)
            q.mul_add(H, qubit[0, 1])
            q.add(CNOT, qubit[1], qubit[0])
            q.add(X, qubit[0]).add(X, qubit[1])
            print(q.get_matrix())
            [[ 0.5+0.j -0.5+0.j  0.5+0.j -0.5+0.j]
             [ 0.5+0.j  0.5+0.j -0.5+0.j -0.5+0.j]
             [ 0.5+0.j -0.5+0.j -0.5+0.j  0.5+0.j]
             [ 0.5+0.j  0.5+0.j  0.5+0.j  0.5+0.j]]
                """
        # 1、Calculate the matrix for each quantum gate
        # 2、Calculate the matrix for each column cmatrix（A、B、C...）
        # 3、Calculate the total matrix of the programe matrix（C*B*A）
        self.__get_tempgates()
        self.__unfold_circuit()
        draw_list = np.array(self.temp_qreg)
        # 不支持含有if和while的操作
        for gate in self.temp_gates:
            if gate.name == "QIF" or gate.name == "QWHILE":
                raise TypeError("can not support QIF or QWHILE operation")
            elif gate.name == "MEASURE":
                raise TypeError("can not support Measure operation")
        # print(draw_list)
        matrix = 0
        for i in range(draw_list.shape[1]):
            gate_col = draw_list[:, i]
            cmatrix = 0
            # 计算每列矩阵
            for qgate in gate_col[::-1]:
                # 1、basicgate:matrix
                # 2、ctrl:skip
                # 3、None:I
                if isinstance(qgate, Basicgate):
                    # If it is a single bit basic gate, directly obtain the gate matrix
                    if qgate.matrix.shape[0] == 2:
                        qmatrix = qgate.matrix
                    # SWAP＝CNOT　CNOT　CNOT
                    elif isinstance(qgate, SWAP):
                        qmatrix = np.array([[0., 1.], [1., 0.]], dtype=complex)
                        ctrl = copy.deepcopy(qgate.ctrl)
                        # SWAP with control，matrix expansion uses enlarge_three
                        if ctrl:
                            if len(qgate.ctrl) > 1:
                                raise ValueError("can not support >3 bits gate")
                            target = qgate.target[0]
                            ctrl.append(qgate.target[1])
                            qmatrix1 = self.__enlarge_three(ctrl, target, qmatrix)
                            target = qgate.target[1]
                            ctrl[-1]=qgate.target[0]
                            qmatrix2 = self.__enlarge_three(ctrl, target,qmatrix)
                            target = qgate.target[0]
                            ctrl[-1] = qgate.target[1]
                            qmatrix3 = self.__enlarge_three(ctrl, target, qmatrix)
                            qmatrix = np.dot(np.dot(qmatrix1, qmatrix2), qmatrix3)
                        # If SWAP has controlled bits, matrix expansion uses enlarge_two
                        else:
                            target = qgate.target[0]
                            ctrl = qgate.target[1]
                            qmatrix1 = self.__enlarge_two(ctrl, target, qmatrix)
                            qmatrix2 = self.__enlarge_two(target, ctrl, qmatrix)
                            qmatrix3 = self.__enlarge_two(ctrl, target, qmatrix)
                            qmatrix = np.dot(np.dot(qmatrix1, qmatrix2), qmatrix3)
                    elif isinstance(qgate,IsingZZ):
                        if qgate.ctrl:
                            if len(qgate.ctrl) > 1:
                                raise ValueError("can not support >3 bits gate")
                            target = qgate.target[0]
                            ctrl = qgate.ctrl[0]
                            qmatrix = qgate.old_matrix
                            qmatrix = self.__enlarge_two(ctrl,target,qmatrix)
                        else:
                            qmatrix = qgate.matrix
                    elif qgate.matrix.shape[0] == 8:
                        target = qgate.target[0]
                        ctrl = qgate.ctrl
                        qmatrix = qgate.old_matrix
                        qmatrix = self.__enlarge_three(ctrl, target, qmatrix)
                    elif qgate.matrix.shape[0] == 4:
                        target = qgate.target[0]
                        ctrl = qgate.ctrl[0]
                        qmatrix = qgate.old_matrix
                        qmatrix = self.__enlarge_two(ctrl, target, qmatrix)
                    else:
                        raise ValueError("can not support >3 bits gate")
                elif qgate is None:
                    qmatrix = np.array([[1, 0], [0, 1]], dtype=complex)
                elif qgate == "ctrl":
                    continue
                # The multiplication of matrices within each column is a direct product
                if isinstance(cmatrix, int):
                    cmatrix = qmatrix
                else:
                    cmatrix = np.kron(cmatrix, qmatrix)
            # Multiplying columns is a product
            if isinstance(matrix, int):
                matrix = cmatrix
            else:
                matrix = np.dot(cmatrix, matrix)
            # Keep nine decimal places to avoid calculating numbers close to 0
            matrix = np.around(matrix, 9)
        return matrix


    def set_state(self,state):
        """Set the initial quantum state of the quantum program"""
        self._start_state = np.array(state,dtype=complex)
        if self.start_state.ndim > 2:
            raise ValueError("The set_state array dimension cannot be greater than 2")
        if self.start_state.ndim == 2 and 2 ** self.qubits != len(self.start_state[0]):
            raise ValueError("The set_state dimension is inconsistent with qubits")
        if self.start_state.ndim == 1 and 2 ** self.qubits != len(self.start_state):
            raise ValueError("The set_state dimension is inconsistent with qubits")
        # 设置batch_size只有两类入口，一个是设置状态向量，一个是从含参数的电路门
        if self.start_state.ndim == 2:
            self.set_batch(self.start_state.shape[0])


    def depth(self):
        """Calculate the depth of quantum programe

        returns:
            maxdepth (int): depth of quantum programe

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumProg(qubit, cbit)
            q.mul_add(H, qubit[0, 1])
            q.add(CNOT, qubit[1], qubit[0])
            print(q.depth())
            2
        """
        self.__get_tempgates()
        self.__unfold_circuit()
        maxdepth = max([len(self.temp_qreg[i]) for i in range(self.qubits)])
        # if not isinstance(self.temp_gates[-1],MEASURE):
        #     maxdepth = max([len(self.temp_qreg[i]) for i in range(self.qubits)])
        # else:
        #     maxdepth = max([len(self.temp_qreg[i]) for i in range(self.qubits)]) - 1
        return maxdepth

    def extent(self,circuit,pos=0):
        """Insert a new Quantum circuit behind the Quantum circuit
            Add all quantum gates in the quantum circuit to the quantum program
        Args:
            circuit (Basicgate): The quantum circuit you want to apply
            pos (int):The starting position for adding quantum circuits

        Raises:
            TypeError: If 'circuit' is not a Quantumcircuit.

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(3)
            cbit = ClassicalRegister(3)
            qp = QuantumProg(qubit, cbit)
            qp.add(H, qubit[0]).add(H, qubit[1])
            qp.add(X, qubit[0]).add(X, qubit[1])
            qubit1 = QuantumRegister(2)
            cbit1 = ClassicalRegister(2)
            qc = QuantumCircuit(qubit1, cbit1)
            qc.add(CNOT, qubit1[1], qubit1[0])
            qc.add(H, qubit1[0]).add(X, qubit1[1])
            qp.extent(qc, 1)
            qp.draw()
            q0   ―――――――H――――――――――――――X―――――――――――――――――――――――――――――――――――――

            q1   ―――――――H――――――――――――――X――――――――――――――●――――――――――――――H―――――――
                                                      ┃
            q2   ――――――――――――――――――――――――――――――――――――CNOT――――――――――――X―――――――

            c    ――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――
        """

        if not isinstance(circuit, QuantumCircuit):
            raise TypeError("The input circuit is not a class circuit")
        circuit_copy = copy.deepcopy(circuit)
        end = pos + circuit_copy.qubits

        if self._end:
            self._end = False
            maxdepth = max([len(self.qreg[i]) for i in range(self.qubits)])
            for gatelist in self.qreg:
                gatelist.extend([None] * (maxdepth - len(gatelist)))

        maxdepth = max([len(self.qreg[i]) for i in range(pos,end)])
        for i in range(pos,end):
            self.qreg[i].extend([None] * (maxdepth - len(self.qreg[i])))
        if pos:
            for iters in circuit_copy.qreg:
                for i in iters:
                    if isinstance(i,Basicgate):
                        i.target = [j + pos for j in i.target]
                        if i.ctrl:
                            i.ctrl = [j + pos for j in i.ctrl]
                    elif isinstance(i,KrausOperation):
                        i._target = [j + pos for j in i.targets]

        for i in range(pos,end):
            self.qreg[i].extend(circuit_copy.qreg[i-pos])

        if circuit_copy.use_parameter!=None:
            for para in circuit_copy.use_parameter.values():
                if para not in self._use_parameters:
                    self._use_parameters.append(para)

    def insert_circuit(self,circuit,pos=None):
        """Adding New Quantum circuit to Quantum Programs

        Args:
            circuit (Basicgate): The quantum circuit you want to apply

        Raises:
            TypeError: If 'circuit' is not a Quantumcircuit.
            ValueError:If the number of bits used in the circuit plus the number of bits
                        used in the program exceeds the number of bits in the program

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(4)
            cbit = ClassicalRegister(4)
            qp = QuantumProg(qubit, cbit)
            qp.add(H, qubit[0]).add(H, qubit[1])
            qp.add(X, qubit[0]).add(X, qubit[1])
            qubit1 = QuantumRegister(2)
            cbit1 = ClassicalRegister(2)
            qc = QuantumCircuit(qubit1, cbit1)
            qc.add(CNOT, qubit1[1], qubit1[0])
            qc.add(H, qubit1[0]).add(X, qubit1[1])
            qp.insert_circuit(qc,pos=2)
            qp.draw()
            q0   ―――――――H――――――――――――――X―――――――

            q1   ―――――――H――――――――――――――X―――――――

            q2   ―――――――●――――――――――――――H―――――――
                        ┃
            q3   ――――――CNOT――――――――――――X―――――――

            c    ――――――――――――――――――――――――――――――
        """
        if not isinstance(circuit, QuantumCircuit):
            raise ValueError("The input circuit is not a class circuit")

        circuit_copy = copy.deepcopy(circuit)

        if pos is not None:
            if not isinstance(pos, (int, Bit)):
                raise ValueError("The initial index position must be either int or Bit")
            if isinstance(pos,int):
                index_number = pos
            elif isinstance(pos, Bit):
                if pos.name != self.qreg._name:
                    raise TypeError("Please use the correct register index for the target bit")
                index_number = int(re.findall('\d+', re.sub(self.qreg._name, "", str(pos)))[0])
        else:
            index_number = 0

        for iters in circuit_copy.qreg:
            for i in iters:
                if isinstance(i, Basicgate):
                    i.target = [j + index_number for j in i.target]
                    if i.ctrl:
                        i.ctrl = [j + index_number for j in i.ctrl]
                elif isinstance(i,KrausOperation):
                    i._target = [j + index_number for j in i.targets]
        circuit_copy.start_pos = index_number
        if self._end:
            self._end = False
            maxdepth = max([len(self.qreg[i]) for i in range(self.qubits)])
            for gatelist in self.qreg:
                gatelist.extend([None] * (maxdepth - len(gatelist)))

        for i in range(index_number, index_number + circuit_copy.qubits):
            self.used_bits.append(i)
            if i == index_number:
                maxdepth = max([len(circuit_copy.qreg[j]) for j in range(circuit_copy.qubits)])
                for j in circuit_copy.qreg:
                    j.extend([None] * (maxdepth - len(j)))
                maxdepth = max([len(self.qreg[j]) for j in range(index_number,index_number + circuit_copy.qubits)])
                for j in range(index_number,index_number + circuit_copy.qubits):
                    self.qreg[j].extend([None] * (maxdepth - len(self.qreg[j])))
                self.qreg[i].append(circuit_copy)
            else:
                self.qreg[i].append("ctrl")

        if circuit_copy.use_parameter!=None:
            for para in circuit_copy.use_parameter.values():
                if para not in self._use_parameters:
                    self._use_parameters.append(para)


    @property
    def start_state(self):
        label = False
        for qreg in self.qreg:
            if len(qreg) == 0:
                continue
            if isinstance(qreg[0], QuantumCircuit):
                if isinstance(qreg[0].start_state,np.ndarray) and qreg[0].controled==[]:
                    label = True
                    break
        if isinstance(self._start_state, np.ndarray):
            if label:
                raise ValueError("Circuit and prog cannot initiate quantum states simultaneously")
            else:
                return self._start_state
        elif self._start_state==None:
            if label:
                return self._cal_state()
            else:
                return None

    def _cal_state(self):
        for i in range(self.qubits):
            if len(self.qreg[i]) == 0:
                temp_state = [0] * 2
                temp_state[0] = 1
                if i == 0:
                    init_s = np.array(temp_state, dtype=complex)
                else:
                    init_s = np.kron(init_s, np.array(temp_state, dtype=complex))
                continue
            if isinstance(self.qreg[i][0], QuantumCircuit):
                if isinstance(self.qreg[i][0].start_state, np.ndarray):
                    temp_state = self.qreg[i][0].start_state
                elif self.qreg[i][0].start_state is None:
                    temp_state = [0] * 2 ** self.qreg[i][0].qubits
                    temp_state[0] = 1
                if i == 0:
                    init_s = np.array(temp_state, dtype=complex)
                else:
                    init_s = np.kron(init_s, np.array(temp_state, dtype=complex))
            elif isinstance(self.qreg[i][0], Basicgate):
                if self.qreg[i][0].control:
                    index = self.qreg[i][0].control + self.qreg[i][0].target
                    qubit = max(index) - min(index) + 1
                else:
                    index = [] + self.qreg[i][0].target
                    qubit = max(index) - min(index) + 1
                temp_state = [0] * 2 ** qubit
                temp_state[0] = 1
                if i == 0:
                    init_s = np.array(temp_state, dtype=complex)
                else:
                    init_s = np.kron(init_s, np.array(temp_state, dtype=complex))
            elif isinstance(self.qreg[i][0], (BARRIER,RESET)) or self.qreg[i][0] is None:
                temp_state = [0] * 2
                temp_state[0] = 1
                if i == 0:
                    init_s = np.array(temp_state, dtype=complex)
                else:
                    init_s = np.kron(init_s, np.array(temp_state, dtype=complex))
        return init_s


    def control(self,tar_circuit,ctrl_circuit,pos=None):
        """Adding Controlled Quantum Circuits to Quantum Programs

        Args:
            tar_circuit(QuantumCircuit): Controlled quantum circuit
            ctrl_circuit(QuantumCircuit,Bit): Quantum circuit control bit
            tar_pos(Bit):The starting position of the target line

        Raises:
            TypeError: If 'tar_circuit' is not a Quantumcircuit.
            TypeError: If 'ctrl_circuit' is not a Quantumcircuit or Bit.
            ValueError:If 'ctrl_circuit' has not been used in a quantum program

        Examples:
            from wuyue.programe import QuantumProg
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(4)
            cbit = ClassicalRegister(4)
            qp = QuantumProg(qubit, cbit)
            qp.add(H,qubit[0]).add(H,qubit[1])
            qp.add(X,qubit[0]).add(X,qubit[1])
            qubit1 = QuantumRegister(2)
            cbit1 = ClassicalRegister(2)
            qc = QuantumCircuit(qubit1, cbit1)
            qc.add(CNOT,qubit1[1],qubit1[0])
            qc.add(H,qubit1[0]).add(X,qubit1[1])
            qp.control(qc,qubit[0,1],pos=2)
            qp.draw()
            q0   ―――――――H――――――――――――――X――――――――――――――●――――――――――――――●――――――――――――――●―――――――
                                                      ┃              ┃              ┃
            q1   ―――――――H――――――――――――――X――――――――――――――●――――――――――――――●――――――――――――――●―――――――
                                                      ┃              ┃              ┃
            q2   ―――――――――――――――――――――――――――――――――――――●――――――――――――――H――――――――――――――┃―――――――
                                                      ┃                             ┃
            q3   ――――――――――――――――――――――――――――――――――――CNOT―――――――――――――――――――――――――――X―――――――

            c    ―――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――
        """
        new_circuit = copy.deepcopy(tar_circuit)

        if not isinstance(tar_circuit, QuantumCircuit):
            raise ValueError("The input circuit is not a class circuit")
        control = self._bit_to_list(ctrl_circuit,self.qreg._name)

        if pos!=None:
            if isinstance(pos,int):
                pos = [pos]
            else:
                pos = self._bit_to_list(pos,self.qreg._name)

            if len(new_circuit.qreg) + pos[0] > self.qubits:
                raise ValueError("Index exceeds the number of bits in this quantum circuit")

            for i in control:
                if i >= pos[0] and i <= len(new_circuit.qreg) + pos[0] - 1:
                    raise ValueError("The target position", [pos[0] + j for j in range(new_circuit.qubits)],
                                     " and control position", control, " cannot be the same")
            if pos[0]+new_circuit.qubits > self.qubits:
                raise ValueError("Control bit and target bit exceed qubits")
        else:
            # 如何判断目标位的默认位置
            if new_circuit.qubits > min(control):
                raise ValueError("The control bit and target bit act in the same position")
            else:
                pos = [0]

        index_number = pos[0]
        for gate_list in new_circuit.qreg:
            for gate in gate_list:
                if isinstance(gate, Basicgate):
                    gate.target =[i+index_number for i in gate.target]
                    if gate.ctrl:
                        ctrl = [i + index_number for i in gate.ctrl]
                        ctrl.extend(control)
                        gate.ctrl = ctrl
                    else:
                        ctrl = control
                        gate.ctrl = ctrl
                    gate.expand_matrix()

        new_circuit.start_pos = index_number
        pos1 = min(min(control), index_number)
        pos2 = max(max(control), index_number + new_circuit.qubits)
        self.qreg[pos1].append(new_circuit)
        for i in range(pos1 + 1, pos2):
            self.qreg[i].append("ctrl")
        maxlayer = max([len(self.qreg[j]) for j in range(pos1, pos2)])
        for k in range(pos1, pos2):
            layeri = len(self.qreg[k])
            pos = layeri - 1
            if layeri != maxlayer:
                for i in range(abs(layeri - maxlayer)):
                    self.qreg[k].insert(pos, None)
        new_circuit.controled = control

        if new_circuit.use_parameter is not None:
            for para in new_circuit.use_parameter.values():
                if para not in self._use_parameters:
                    self._use_parameters.append(para)

    @property
    def use_parameter(self):
        # paras_name = [i.name for i in self._use_parameters]
        paras = {}
        if self._use_parameters == []:
            return None
        for i in self._use_parameters:
            paras[i.name] = i
        return paras

    def bind_parameters(self, key_value:dict, inplace=False):
        if inplace:
            circuit = self
        else:
            circuit = copy.deepcopy(self)
        for key,value in key_value.items():
            if isinstance(key,Parameters):
                name = key.name
            elif isinstance(key,ParameterVector):
                if isinstance(value,(list,np.ndarray)) and len(value)==len(key):
                    for index,paras in enumerate(key):
                        name = paras.name
                        if name in self.use_parameter.keys():
                            circuit.use_parameter[name].set_data(value[index])
                        else:
                            raise ValueError(f"Cannot bind parameters {name} not present in the circuit.")
                    continue
                else:
                    raise ValueError("The value of the dictionary needs to be a list or numpy array, "
                                     "and its number should be equal to the number of parameters")
            elif isinstance(key, str):
                name = key
            else:
                raise TypeError("The keys of the dictionary need to be related to the parameters")
            if name in self.use_parameter.keys():
                circuit.use_parameter[name].set_data(value)
            else:
                raise ValueError(f"Cannot bind parameters {name} not present in the circuit.")
            # circuit._use_parameters[0].set_data(value)
        return circuit

class QIF:
    """QIF class"""
    def __init__(self,condition,true_lens,false_lens):
        self.name = "QIF"
        self.condition = condition
        self.true_lens = true_lens
        self.false_lens = false_lens
    def __repr__(self):
        return f"{self.__class__.__name__}"

class QWHILE:
    """QWHILE class"""
    def __init__(self,condition,while_lens,count,count_expression):
        self.name = "QWHILE"
        self.condition = condition
        self.while_lens = while_lens
        self.count = count
        self.count_expression = count_expression
    def __repr__(self):
        return f"{self.__class__.__name__}"


