# -*- coding: utf-8 -*-
import autograd.numpy as np
from abc import ABC, abstractmethod
from typing import Optional, Union

class KrausOperation(ABC):
    def __init__(self,target,probability):
        self._target = target
        self._probability = probability

    @property
    @abstractmethod
    def kraus(self):
        pass

    @property
    def targets(self):
        return self._target

    @property
    def probability(self):
        return self._probability

    def __eq__(self, other):
        if len(self.kraus) == len(other.kraus) and self.kraus[0].shape == other.kraus[0].shape:
            return self.targets == other.targets and np.allclose(self.kraus, other.kraus)
        else:
            return False

    def __repr__(self):
        return f"{self.__class__.__name__}"


class BitFlip(KrausOperation):
    def __init__(self,target,probability:Union[int, list]):
        super().__init__(target=target,probability=probability)
        self.symbol = "BF"
        self.name = "BitFlip"
        if len(target) != 1:
            raise ValueError("BitFlip only applies to one qubit")
        if isinstance(probability,list):
            if len(probability)!=1:
                raise ValueError("If probability is a list, only one float parameter is required")
            else:
                self._probability = probability[0]
        if self._probability >= 1 or self._probability <= 0 :
            raise ValueError("probabilities cannot be greater than 1 and less than 0")

    @property
    def kraus(self):
        k0 = np.sqrt(1 - self._probability) * np.array([[1, 0], [0, 1]],dtype=complex)
        k1 = np.sqrt(self._probability) * np.array([[0, 1], [1, 0]],dtype=complex)
        return [k0, k1]

    @property
    def targets(self):
        return self._target

    @property
    def probability(self):
        return self._probability


class PhaseFlip(KrausOperation):
    def __init__(self, target:list, probability:Union[int, list]):
        super().__init__(target=target, probability=probability)
        self.symbol = "PF"
        self.name = "PhaseFlip"
        if len(target) != 1:
            raise ValueError("PhaseFlip only applies to one qubit")
        if isinstance(probability,list):
            if len(probability)!=1:
                raise ValueError("If probability is a list, only one float parameter is required")
            else:
                self._probability = probability[0]
        if self._probability >= 1 or self._probability <= 0 :
            raise ValueError("probabilities cannot be greater than 1 and less than 0")

    @property
    def kraus(self):
        k0 = np.sqrt(1 - self._probability) * np.array([[1.0, 0.0], [0.0, 1.0]],dtype=complex)
        k1 = np.sqrt(self._probability) * np.array([[1.0, 0.0], [0.0, -1.0]],dtype=complex)
        return [k0, k1]

    @property
    def targets(self):
        return self._target

    @property
    def probability(self):
        return self._probability

class PauliChannel(KrausOperation):
    def __init__(self, target:list, probability:list):
        super().__init__(target=target, probability=probability)
        self.symbol = "PC"
        self.name = "PauliChannel"
        if len(target) != 1:
            raise ValueError("PauliChannel only applies to one qubit")
        if len(self._probability) != 3:
            raise ValueError("Paulichannel requires three parameters: Px, Py, and Pz")
        else:
            for prob in probability:
                if prob <= 0 or prob >=1:
                    raise ValueError("probabilities cannot be greater than 1 or less than 0")
            if sum(probability) >= 1:
                raise ValueError("The sum of probabilities cannot be greater than 1")

    @property
    def kraus(self):
        self._probX, self._probY, self._probZ = self._probability[0],self._probability[1],self._probability[2]
        K0 = np.sqrt(1 - self._probX - self._probY - self._probZ) * np.array(
            [[1.0, 0.0], [0.0, 1.0]],dtype=complex
        )
        K1 = np.sqrt(self._probX) * np.array([[0.0, 1.0], [1.0, 0.0]],dtype=complex)
        K2 = np.sqrt(self._probY) * np.array([[0.0, -1.0j], [1.0j, 0.0]],dtype=complex)
        K3 = np.sqrt(self._probZ) * np.array([[1.0, 0.0], [0.0, -1.0]],dtype=complex)
        return [K0, K1, K2, K3]

    @property
    def targets(self):
        return self._target

    @property
    def probability(self):
        return self._probability

class Depolarizing(KrausOperation):
    def __init__(self, target:list, probability:Union[int, list]):
        super().__init__(target=target, probability=probability)
        self.symbol = "Depo"
        self.name = "Depolarizing"
        if len(target) != 1:
            raise ValueError("Depolarizing only applies to one qubit")
        if isinstance(probability,list):
            if len(probability)!=1:
                raise ValueError("If probability is a list, only one float parameter is required")
            else:
                self._probability = probability[0]
        if self._probability >= 1 or self._probability <= 0 :
            raise ValueError("probabilities cannot be greater than 1 and less than 0")

    @property
    def kraus(self):
        K0 = np.sqrt(1 - self._probability) * np.array([[1.0, 0.0], [0.0, 1.0]], dtype=complex)
        K1 = np.sqrt(self._probability / 3) * np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex)
        K2 = (
            np.sqrt(self._probability / 3) * 1j * np.array([[0.0, -1.0], [1.0, 0.0]], dtype=complex)
        )
        K3 = np.sqrt(self._probability / 3) * np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex)
        return [K0, K1, K2, K3]


    @property
    def targets(self):
        return self._target

    @property
    def probability(self):
        return self._probability

class AmplitudeDamping(KrausOperation):
    def __init__(self, target:list, gamma:Union[int, list]):
        super().__init__(target=target, probability=None)
        self.symbol = "AD"
        self.name = "AmplitudeDamping"
        if len(target) != 1:
            raise ValueError("AmplitudeDamping only applies to one qubit")
        self._gamma = gamma
        if isinstance(gamma,list):
            if len(gamma)!=1:
                raise ValueError("If gamma is a list, only one float parameter is required")
            else:
                self._gamma = gamma[0]
        if self._gamma >= 1 or self._gamma <= 0 :
            raise ValueError("gamma cannot be greater than 1 or less than 0")

    @property
    def kraus(self):
        K0 = np.array([[1.0, 0.0], [0.0, np.sqrt(1 - self._gamma)]], dtype=complex)
        K1 = np.array([[0.0, np.sqrt(self._gamma)], [0.0, 0.0]], dtype=complex)
        return [K0, K1]

    @property
    def targets(self):
        return self._target

    @property
    def gamma(self):
        return self._gamma

class GeneralizedAmplitudeDamping(KrausOperation):
    def __init__(self, target:list, gamma:Union[int, list], probability:Union[int, list]):
        super().__init__(target=target, probability=probability)
        self.symbol = "GAD"
        self.name = "GeneralizedAmplitudeDamping"
        if len(target) != 1:
            raise ValueError("GeneralizedAmplitudeDamping only applies to one qubit")
        self._gamma = gamma
        if isinstance(gamma,list):
            if len(gamma)!=1:
                raise ValueError("If gamma is a list, only one float parameter is required")
            else:
                self._gamma = gamma[0]
        if self._gamma >= 1 or self._gamma <= 0 :
            raise ValueError("gamma cannot be greater than 1 or less than 0")

        if isinstance(probability,list):
            if len(probability)!=1:
                raise ValueError("If probability is a list, only one float parameter is required")
            else:
                self._probability = probability[0]
        if self._probability >= 1 or self._probability <= 0 :
            raise ValueError("probabilities cannot be greater than 1 or less than 0")

    @property
    def kraus(self):
        K0 = np.sqrt(self._probability) * np.array(
            [[1.0, 0.0], [0.0, np.sqrt(1 - self._gamma)]], dtype=complex
        )
        K1 = np.sqrt(self._probability) * np.array(
            [[0.0, np.sqrt(self._gamma)], [0.0, 0.0]], dtype=complex
        )
        K2 = np.sqrt(1 - self._probability) * np.array(
            [[np.sqrt(1 - self._gamma), 0.0], [0.0, 1.0]],dtype=complex
        )
        K3 = np.sqrt(1 - self._probability) * np.array([[0.0, 0.0], [np.sqrt(self._gamma), 0.0]],dtype=complex)
        return [K0, K1, K2, K3]

    @property
    def targets(self):
        return self._target

    @property
    def gamma(self):
        return self._gamma

    @property
    def probability(self):
        return self._probability

class PhaseDamping(KrausOperation):
    def __init__(self, target:list, gamma:Union[int, list]):
        super().__init__(target=target, probability=None)
        self.symbol = "PD"
        self.name = "PhaseDamping"
        if len(target) != 1:
            raise ValueError("PhaseDamping only applies to one qubit")
        self._gamma = gamma
        if isinstance(gamma,list):
            if len(gamma)!=1:
                raise ValueError("If gamma is a list, only one float parameter is required")
            else:
                self._gamma = gamma[0]
        if self._gamma >= 1 or self._gamma <= 0 :
            raise ValueError("gamma cannot be greater than 1 or less than 0")

    @property
    def kraus(self):
        K0 = np.array([[1.0, 0.0], [0.0, np.sqrt(1 - self._gamma)]], dtype=complex)
        K1 = np.array([[0.0, 0.0], [0.0, np.sqrt(self._gamma)]], dtype=complex)
        return [K0, K1]

    @property
    def targets(self):
        return self._target

    @property
    def gamma(self):
        return self._gamma

class ResetNoise(KrausOperation):
    def __init__(self, target, probability):
        super().__init__(target=target, probability=probability)
        self.symbol = "Reset"
        self.name = "ResetNoise"
        if len(target) != 1:
            raise ValueError("ResetNoise only applies to one qubit")
        if len(self._probability) != 2:
            raise ValueError("ResetNoise requires three parameters: P0 and P1")
        else:
            for prob in probability:
                if prob <= 0 or prob >= 1:
                    raise ValueError("probabilities cannot be greater than 1 or less than 0")
            if sum(probability) >= 1:
                raise ValueError("The sum of probabilities is greater than 1")

    @property
    def kraus(self):
        p0,p1 = self._probability[0], self._probability[1]
        K0 = np.sqrt(1 - p0 - p1) * np.array([[1.0, 0.0], [0.0, 1.0]], dtype=complex)
        K1 = np.sqrt(p0) * np.array([[1.0, 0.0], [0.0, 0.0]], dtype=complex)
        K2 = np.sqrt(p0) * np.array([[0.0, 1.0], [0.0, 0.0]], dtype=complex)
        K3 = np.sqrt(p1) * np.array([[0.0, 0.0], [1.0, 0.0]], dtype=complex)
        K4 = np.sqrt(p1) * np.array([[0.0, 0.0], [0.0, 1.0]], dtype=complex)

        K_list = [K0, K1, K2, K3, K4]
        return K_list


    @property
    def targets(self):
        return self._target

    @property
    def probability(self):
        return self._probability


class TwoQubitDepolarizing(KrausOperation):
    def __init__(self, target:list, probability:Union[int, list]):
        super().__init__(target=target, probability=probability)
        self.symbol = "Depo"
        self.name = "TwoQubitDepolarizing"
        if len(target) != 2:
            raise ValueError("TwoQubitDepolarizing only applies to two qubit")
        if isinstance(probability,list):
            if len(probability)!=1:
                raise ValueError("If probability is a list, only one float parameter is required")
            else:
                self._probability = probability[0]
        # 15/16
        if self._probability > 0.9375 or self._probability < 0 :
            raise ValueError("probabilities cannot be greater than 0.9375 and less than 0")

    @property
    def kraus(self):
        SI = np.array([[1.0, 0.0], [0.0, 1.0]], dtype=complex)
        SX = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex)
        SY = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=complex)
        SZ = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex)

        K_list_single = [SI, SX, SY, SZ]
        K_list = [np.kron(i, j) for i in K_list_single for j in K_list_single]

        K_list[0] *= np.sqrt(1 - self._probability)

        K_list[1:] = [np.sqrt(self._probability / 15) * i for i in K_list[1:]]

        return K_list


    @property
    def targets(self):
        return self._target

    @property
    def probability(self):
        return self._probability

class TwoQubitDephasing(KrausOperation):
    def __init__(self, target:list, probability:Union[int, list]):
        super().__init__(target=target, probability=probability)
        self.symbol = "Deph"
        self.name = "TwoQubitDephasing"
        if len(target) != 2:
            raise ValueError("TwoQubitDephasing only applies to two qubit")
        if isinstance(probability,list):
            if len(probability)!=1:
                raise ValueError("If probability is a list, only one float parameter is required")
            else:
                self._probability = probability[0]
        # 15/16
        if self._probability > 0.75 or self._probability <= 0 :
            raise ValueError("probabilities cannot be greater than 0.75 and less than 0")

    @property
    def kraus(self):
        SI = np.array([[1.0, 0.0], [0.0, 1.0]], dtype=complex)
        SZ = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex)
        K0 = np.sqrt(1 - self._probability) * np.kron(SI, SI)
        K1 = np.sqrt(self._probability / 3) * np.kron(SI, SZ)
        K2 = np.sqrt(self._probability / 3) * np.kron(SZ, SI)
        K3 = np.sqrt(self._probability / 3) * np.kron(SZ, SZ)

        return [K0, K1, K2, K3]


    @property
    def targets(self):
        return self._target

    @property
    def probability(self):
        return self._probability


if __name__ == '__main__':
    noise1 = TwoQubitDepolarizing([0,1],0.01)
    for index,value in enumerate(noise1.kraus):
        print(index,value)

    noise2 = Depolarizing([0],0.01)
    K_list = [np.kron(i, j) for i in noise2.kraus for j in noise2.kraus]
    for index,value in enumerate(K_list):
        print(index,value)
