# -*- coding: utf-8 -*-
import autograd.numpy as np
import autograd
from collections.abc import Iterable
pi = np.pi
def _rx(theta=np.pi/2):
    """Matrix of Rx gate """
    return np.array([[np.cos(0.5 * theta), -1.j * np.sin(0.5 * theta)],
                     [-1.j * np.sin(0.5 * theta), np.cos(0.5 * theta)]], dtype=complex)

def _ry(theta=np.pi/2):
    """Matrix of Ry gate """
    return np.array([[np.cos(0.5 * theta), - np.sin(0.5 * theta)],
                     [np.sin(0.5 * theta), np.cos(0.5 * theta)]], dtype=complex)

def _rz(theta=np.pi/2):
    """Matrix of Rz gate """
    return np.array([[np.exp(-0.5j * theta), 0.],[0., np.exp(0.5j * theta)]], dtype=complex)

def _p(theta=np.pi/2):
    """Matrix of P gate """
    return np.array([[1, 0],[0, np.exp(1.j*theta)]] ,dtype=complex)



def _u1matrix(_lambda=0.):
    """Matrix of U1 gate """
    return np.array([[1, 0], [0, np.exp(1j * _lambda)]], dtype=complex)

def _u2matrix(_phi=0., _lambda=0.):
    """Matrix of U2 gate """
    return 1 / np.sqrt(2)*np.array([[1., -np.exp(1.j * _lambda)],
                     [np.exp(1.j * _phi), np.exp((_phi + _lambda) * 1.j)]], dtype=complex)


def _u3matrix(_theta=0., _phi=0., _lambda=0.):
    """Matrix of U3 gate """
    return np.array([[np.cos(0.5 * _theta), -np.exp(_lambda * 1.j) * np.sin(0.5 * _theta)],
                     [np.exp(_phi * 1.j) * np.sin(0.5 * _theta),
                      np.exp((_phi + _lambda) * 1.j) * np.cos(0.5 * _theta)]], dtype=complex)


def _isingZZ(theta=np.pi / 2):
    """Matrix of IsingZZ gate"""
    return np.array([[np.exp(-0.5j * theta) * (1 + 0j), 0, 0, 0],
                        [0, np.exp(0.5j * theta) * (1 + 0j), 0, 0],
                        [0, 0, np.exp(0.5j * theta) * (1 + 0j),0],
                        [0, 0, 0, np.exp(-0.5j * theta) * (1 + 0j)]], dtype=complex)
class Basicgate:
    """Basic quantum gates for universal quantum gates"""
    def __init__(self,name,target,symbol=None,ctrl=None,dagger=False):
        self.name = name
        self.ctrl = ctrl
        self.target = target
        self._matrix = np.array([[1,0],[0,1]],dtype=complex)
        self.dagger = dagger
        self.old_matrix = np.array([[1,0],[0,1]],dtype=complex)
        # Check if the control bit and target bit of the quantum gate are duplicated
        self.batch_size = None
        if self.ctrl:
            if set(self.target) & set(self.ctrl):
                raise ValueError("Obj_qubit and ctrl_qubit cannot have same qubits.")
        if symbol:
            self.symbol = symbol
        else:
            self.symbol = self.name.upper()


    def expand_matrix(self):
        """Matrix changes when quantum gates are controlled"""
        if len(self.ctrl) >=1:
            number = len(self._matrix)
            lens = 2 ** (len(self.ctrl) + 1) // number
            if lens not in [0,1]:
                conver_matrix = np.zeros((lens,lens))
                conver_matrix[lens-1,lens-1] = 1
                self._matrix = np.kron(conver_matrix, self._matrix)
                for i in range(len(self._matrix) - number):
                    for j in range(len(self._matrix) - number):
                        if i == j:
                            self._matrix[i, j] = 1

    def _dagger(self):
        """Matrix and symbol changes during quantum gate dagger"""
        if self.dagger:
            self.dagger = False
            self.symbol = self.name.upper()
        else:
            self.dagger = True
            self.symbol += "†"
        self._matrix = self._matrix.conjugate()
        self._matrix = self._matrix.T
        self.old_matrix = self.old_matrix.conjugate()
        self.old_matrix = self.old_matrix.T

    @property
    def matrix(self):
        if self.ctrl:
            self.expand_matrix()
        return self._matrix

    def __str__(self):
        """Return the official string representing the quantum gate."""
        properties_names = ['target','ctrl', 'matrix']
        properties_values = [getattr(self, x) for x in properties_names]
        return "%s:\n%s" % (self.__class__.__name__, '\n'.join(
            [f"{x} = {repr(properties_values[i])}" for i, x in enumerate(properties_names)]))

    def __repr__(self):
        return f"{self.__class__.__name__}"


class Noparasgate(Basicgate):
    """Basic quantum gates without parameters"""
    def __init__(self,name,target,symbol=None,ctrl=None,dagger=False):
        super().__init__(name=name,symbol=symbol,ctrl=ctrl,target=target,dagger=dagger)

class Parasgate(Basicgate):
    """Basic quantum gates with parameters"""
    def __init__(self, name, paras, target, symbol=None,ctrl=None, dagger=False):
        # todo
        # 修改中，记得改回来
        # if not isinstance(paras, list):
        # if not isinstance(paras,list) and not isinstance(paras,np.ndarray):
        #     raise TypeError("The parameter must consist of multiple elements in the list")
        super().__init__(name=name, symbol=symbol, ctrl=ctrl, target=target, dagger=dagger)
        self.paras = paras
        self.our_parameters = []
        for i in self.paras:
            from ..circuit.parameters import Parameters
            if isinstance(i, Parameters):
                self.our_parameters.append(i.name)
    def update_paras(self,key_value:dict):
        for key,value in key_value.items():
            if key not in self.our_parameters:
                raise ValueError(f"Cannot bind parameters {key} not present in the circuit.")
            else:
                self.paras[self.our_parameters.index(key)].set_data(value)


class U1(Parasgate):
    """U1 GATE

    [[1,  0],
    [0, exp(iθ)]]
    """
    def __init__(self, paras, target, ctrl=None, dagger=False):
        super().__init__(name="U1",symbol="U1", paras=paras,ctrl=ctrl, target=target, dagger=dagger)

        self.dagger = dagger
        if dagger:
            self.symbol+="†"
        # self.ctrl = ctrl
        # self.paras = paras
        # todo
        if isinstance(self.paras,autograd.numpy.numpy_boxes.ArrayBox):
            # x = self.paras.shape
            if self.paras.size != 1 :
                self.batch_size = self.paras.size
            else:
                self.paras = [self.paras]
        else:
            if len(self.paras) != 1:
                self.batch_size = len(self.paras)
                for para in self.paras:
                    if isinstance(para, Iterable):
                        raise ValueError("The number of parameters for U1 should be 1")
            else:
                if isinstance(paras[0], Iterable):
                    raise ValueError("The number of parameters for U1 should be 1")

    def set_matrix(self,para):
        self._matrix = _u1matrix(para[0])
        self.old_matrix = _u1matrix(para[0])
        return self._matrix

    @property
    def matrix(self):
        from ..circuit.parameters import Parameters
        paras = [i.value if isinstance(i,Parameters) else i for i in self.paras]
        # if isinstance(self.paras, autograd.numpy.numpy_boxes.ArrayBox):
        #     if self.batch_size is None:
        #         paras = [self.paras]
        self.set_matrix(paras)
        if self.dagger:
            self.symbol = self.symbol if self.symbol[-1] == "†" else self.symbol+"†"
            self._matrix = self._matrix.conjugate()
            self.old_matrix = self.old_matrix.conjugate()
        if self.ctrl:
            self.expand_matrix()
        return self._matrix


class U2(Parasgate):
    """U2 GATE

    1 / /√2*([[1., exp(-1.j * φ)],
    [exp(1.j * λ), exp((λ + φ) * 1.j)]]
    """
    def __init__(self, paras, target, ctrl=None, dagger=False):
        super().__init__(name="U2",symbol="U2",paras=paras, ctrl=ctrl, target=target,  dagger=dagger)
        if dagger:
            self.symbol+="†"
        # todo
        if isinstance(self.paras,autograd.numpy.numpy_boxes.ArrayBox):
            # x = self.paras.shape
            if self.paras.size != 2:
                raise ValueError("The number of parameters for U2 should be 2")
            else:
                if self.paras[0].size != 1:
                    self.batch_size = self.paras[0].size
        else:
            if len(self.paras) != 2:
                raise ValueError("The number of parameters for U2 should be 2")
            else:
                # 两种可能，一种是列表或ndarray中有两个参数（无需校验），一种是列表或ndarray中有两个列表
                if isinstance(self.paras[0], Iterable):
                    if len(self.paras[0]) == len(self.paras[1]):
                        if len(self.paras[0]) != 1:
                            self.batch_size = len(self.paras[0])
                    else:
                        raise ValueError("U2二个参数大小不匹配")
        # # change 这部分放在外面校验
        # if len(paras) != 2:
        #     raise ValueError("The number of parameters for U2 should be 2")

    def set_matrix(self,para):
        self._matrix = _u2matrix(para[0],para[1])
        self.old_matrix = _u2matrix(para[0], para[1])
        return self._matrix

    @property
    def matrix(self):
        from ..circuit.parameters import Parameters
        paras = [i.value if isinstance(i,Parameters) else i for i in self.paras]
        if isinstance(self.paras, autograd.numpy.numpy_boxes.ArrayBox):
            # 是否批量，是则只取第一个数字作为赋值，不是批量则不处理
            if self.batch_size != None:
                paras = [self.paras[0][0],self.paras[1][0]]

        self.set_matrix(paras)
        if self.dagger:
            self.symbol = self.symbol if self.symbol[-1] == "†" else self.symbol+"†"
            self._matrix = self._matrix.conjugate()
            self._matrix = self._matrix.T
            self.old_matrix = self.old_matrix.conjugate()
            self.old_matrix = self.old_matrix.T
        if self.ctrl:
            self.expand_matrix()
        return self._matrix

class U3(Parasgate):
    """U1 GATE

    [[cos(0.5 * θ), -exp(φ * 1.j) * sin(0.5 * θ)],
    [exp(λ * 1.j) * sin(0.5 * θ), exp((λ + φ) * 1.j) * cos(0.5 * θ)]]
    """
    def __init__(self, paras, target, ctrl=None, dagger=False):
        super().__init__(name="U3",symbol="U3", paras=paras,ctrl=ctrl, target=target, dagger=dagger)
        if dagger:
            self.symbol+="†"
        # todo
        if isinstance(self.paras,autograd.numpy.numpy_boxes.ArrayBox):
            # x = self.paras.shape
            if self.paras.size != 3:
                raise ValueError("The number of parameters for U3 should be 3")
            else:
                if self.paras[0].size != 1:
                    self.batch_size = self.paras[0].size
        else:
            if len(self.paras) != 3:
                raise ValueError("The number of parameters for U3 should be 3")
            else:
                if isinstance(self.paras[0],Iterable):
                    if len(self.paras[0]) == len(self.paras[1]) and len(self.paras[2]) == len(self.paras[0]):
                        if len(self.paras[0]) != 1:
                            self.batch_size = len(self.paras[0])
                    else:
                        raise ValueError("U3三个参数大小不匹配")
        # # change 这部分放在外面校验
        # if len(paras) != 3:
        #     raise ValueError("The number of parameters for U3 should be 3")


    def set_matrix(self,para):
        self._matrix = _u3matrix(para[0],para[1],para[2])
        self.old_matrix = _u3matrix(para[0], para[1], para[2])
        return self._matrix

    @property
    def matrix(self):
        from ..circuit.parameters import Parameters
        paras = [i.value if isinstance(i,Parameters) else i for i in self.paras]
        if isinstance(self.paras, autograd.numpy.numpy_boxes.ArrayBox):
            if self.batch_size != None:
                paras = [self.paras[0][0],self.paras[1][0],self.paras[2][0]]
        self.set_matrix(paras)
        if self.dagger:
            self.symbol = self.symbol if self.symbol[-1] == "†" else self.symbol+"†"
            self._matrix = self._matrix.conjugate()
            self._matrix = self._matrix.T
            self.old_matrix = self.old_matrix.conjugate()
            self.old_matrix = self.old_matrix.T
        if self.ctrl:
            self.expand_matrix()
        return self._matrix


class H(Noparasgate):
    """H GATE

    [[1/√2., 1/√2],
     [1/√2, -1/√2]]
    """
    def __init__(self,target,ctrl=None,dagger=False):
        super().__init__(name="H",symbol="H",target=target, ctrl=ctrl,dagger=dagger)
        self._matrix = 1 / np.sqrt(2) * np.array([[1., 1.], [1., -1.]], dtype=complex)
        self.old_matrix = 1 / np.sqrt(2) * np.array([[1., 1.], [1., -1.]], dtype=complex)
        if ctrl:
            self.expand_matrix()
        self.dagger = False

    def _dagger(self):
        pass

class I(Noparasgate):
    """I GATE

    [[1., 0.],
    [0., 1.]]
    """
    def __init__(self,target,ctrl=None,dagger=False):
        super().__init__(name="I",symbol="I",target=target, ctrl=ctrl,dagger=dagger)
        self._matrix = np.array([[1., 0.], [0., 1.]], dtype=complex)
        self.old_matrix = np.array([[1., 0.], [0., 1.]], dtype=complex)
        if ctrl:
            self.expand_matrix()
        self.dagger = False
    def _dagger(self):
        pass

class T(Noparasgate):
    """T GATE

    [[1., 0.],
    [0., exp(1.j*pi/4)]]
    """
    def __init__(self,target,ctrl=None,dagger=False):
        super().__init__(name="T",symbol="T",target=target, ctrl=ctrl,dagger=dagger)
        self._matrix=np.array([[1., 0.],[0., np.exp(1.j*np.pi/4)]], dtype=complex)
        self.old_matrix = np.array([[1., 0.],[0., np.exp(1.j*np.pi/4)]], dtype=complex)
        if dagger:
            self.symbol+="†"
        if self.dagger:
            self.symbol+="†"
            self._matrix = self._matrix.conjugate()
            self._matrix = self._matrix.T
            self.old_matrix = self.old_matrix.conjugate()
            self.old_matrix = self.old_matrix.T
        if ctrl:
            self.expand_matrix()

class X(Noparasgate):
    """X GATE

    [[0., 1.],
    [1., 0.]]
    """
    def __init__(self,target,ctrl=None,dagger=False):
        super().__init__(name="X",symbol="X",target=target, ctrl=ctrl,dagger=dagger)
        self._matrix=np.array([[0., 1.],[1., 0.]], dtype=complex)
        self.old_matrix = np.array([[0., 1.],[1., 0.]], dtype=complex)
        if ctrl:
            self.expand_matrix()
        self.dagger = False
    def _dagger(self):
        pass

class Y(Noparasgate):
    """Y GATE

    [[0., -1.j],
    [1.j, 0.]]
    """
    def __init__(self,target,ctrl=None,dagger=False):
        super().__init__(name="Y",symbol="Y",target=target,ctrl=ctrl,dagger=dagger)
        self._matrix=np.array([[0., -1.j],[1.j, 0.]], dtype=complex)
        self.old_matrix = np.array([[0., -1.j], [1.j, 0.]], dtype=complex)
        if ctrl:
            self.expand_matrix()
        self.dagger = False
    def _dagger(self):
        pass

class Z(Noparasgate):
    """Z GATE

    [[1., 0.],
    [0., -1.]]
    """
    def __init__(self,target,ctrl=None,dagger=False):
        super().__init__(name="Z",symbol="Z",target=target,ctrl=ctrl,dagger=dagger)
        self._matrix=np.array([[1., 0.],[0., -1.]], dtype=complex)
        self.old_matrix = np.array([[1., 0.], [0., -1.]], dtype=complex)
        if ctrl:
            self.expand_matrix()
        self.dagger = False
    def _dagger(self):
        pass

class S(Noparasgate):
    """S GATE

    [[1., 0.],
    [0., 1.j]
    """
    def __init__(self,target,ctrl=None,dagger=False):
        super().__init__(name="S",symbol="S",target=target, ctrl=ctrl,dagger=dagger)
        self._matrix=np.array([[1., 0.],[0., 1.j]], dtype=complex)
        self.old_matrix = np.array([[1., 0.], [0., 1.j]], dtype=complex)
        if self.dagger:
            self.symbol += "†"
            self._matrix = self._matrix.conjugate()
            self.old_matrix = self.old_matrix.conjugate()

        if ctrl:
            self.expand_matrix()

class RX(Parasgate):
    """RX GATE

    [[cos(0.5 * θ), -1.j * sin(0.5 * θ)],
    [-1.j * sin(0.5 * θ), cos(0.5 * θ)]]
    """
    def __init__(self, paras, target, ctrl=None, dagger=False):
        super().__init__(name="RX",symbol="RX", paras=paras, target=target, ctrl=ctrl, dagger=dagger)
        if dagger:
            self.symbol+="†"
        # todo
        if isinstance(self.paras,autograd.numpy.numpy_boxes.ArrayBox):
            # x = self.paras.shape
            if self.paras.size != 1 :
                self.batch_size = self.paras.size
            else:
                self.paras = [self.paras]
        else:
            if len(self.paras) != 1:
                self.batch_size = len(self.paras)
                for para in self.paras:
                    if isinstance(para, Iterable):
                        raise ValueError("The number of parameters for RX should be 1")
            else:
                if isinstance(paras[0], Iterable):
                    raise ValueError("The number of parameters for RX should be 1")

    def set_matrix(self,para):
        self._matrix = _rx(para[0])
        self.old_matrix = _rx(para[0])
        return self._matrix

    @property
    def matrix(self):
        from ..circuit.parameters import Parameters
        paras = [i.value if isinstance(i,Parameters) else i for i in self.paras]
        # if isinstance(self.paras, autograd.numpy.numpy_boxes.ArrayBox):
        #     if self.paras.size == 1:
        #         paras = [self.paras]
        self.set_matrix(paras)
        if self.dagger:
            self.symbol+="†"
            self._matrix = self._matrix.conjugate()
            self.old_matrix = self.old_matrix.conjugate()
        if self.ctrl:
            self.expand_matrix()
        return self._matrix

class RY(Parasgate):
    """RY GATE

    [[cos(0.5 * θ), - sin(0.5 * θ)],
    [sin(0.5 * θ), cos(0.5 * θ)]]
    """
    def __init__(self, paras, target, ctrl=None, dagger=False):
        super().__init__(name="RY", symbol="RY",paras=paras,ctrl=ctrl, target=target, dagger=dagger)
        if dagger:
            self.symbol+="†"
        # todo
        if isinstance(self.paras, autograd.numpy.numpy_boxes.ArrayBox):
            # x = self.paras.shape
            if self.paras.size != 1:
                self.batch_size = self.paras.size
            else:
                self.paras = [self.paras]
        else:
            if len(self.paras) != 1:
                self.batch_size = len(self.paras)
                for para in self.paras:
                    if isinstance(para, Iterable):
                        raise ValueError("The number of parameters for RY should be 1")
            else:
                if isinstance(paras[0], Iterable):
                    raise ValueError("The number of parameters for RY should be 1")
        # # change 这部分放在外面校验
        # 修改中，记得改回来
        # if len(paras) != 1:
        #     raise ValueError("The number of parameters for RY should be 1")

    def set_matrix(self,para):
        self._matrix = _ry(para[0])
        self.old_matrix = _ry(para[0])
        return self._matrix

    @property
    def matrix(self):
        from ..circuit.parameters import Parameters
        paras = [i.value if isinstance(i,Parameters) else i for i in self.paras]
        # if isinstance(self.paras, autograd.numpy.numpy_boxes.ArrayBox):
        #     if self.batch_size is None:
        #         paras = [self.paras]
        self.set_matrix(paras)
        if self.dagger:
            self.symbol+="†"
            self._matrix = self._matrix.T
            self.old_matrix = self.old_matrix.T
        if self.ctrl:
            self.expand_matrix()
        return self._matrix

class RZ(Parasgate):
    """RZ GATE

    [[exp(-0.5j * θ), 0.],
    [0., exp(0.5j * θ)]
    """
    def __init__(self, paras, target, ctrl=None, dagger=False):
        super().__init__(name="RZ",symbol="RZ", paras=paras, ctrl=ctrl, target=target,  dagger=dagger)
        if dagger:
            self.symbol+="†"
        # todo
        if isinstance(self.paras, autograd.numpy.numpy_boxes.ArrayBox):
            # x = self.paras.shape
            if self.paras.size != 1:
                self.batch_size = self.paras.size
            else:
                self.paras = [self.paras]
        else:
            if len(self.paras) != 1:
                self.batch_size = len(self.paras)
                for para in self.paras:
                    if isinstance(para, Iterable):
                        raise ValueError("The number of parameters for RZ should be 1")
            else:
                if isinstance(paras[0], Iterable):
                    raise ValueError("The number of parameters for RZ should be 1")

    def set_matrix(self,para):
        self._matrix = _rz(para[0])
        self.old_matrix = _rz(para[0])
        return self._matrix

    @property
    def matrix(self):
        from ..circuit.parameters import Parameters
        paras = [i.value if isinstance(i,Parameters) else i for i in self.paras]
        # if isinstance(self.paras, autograd.numpy.numpy_boxes.ArrayBox):
        #     if self.batch_size is None:
        #         paras = [self.paras]
        self.set_matrix(paras)
        if self.dagger:
            self.symbol+="†"
            self._matrix = self._matrix.conjugate()
            self.old_matrix = self.old_matrix.conjugate()

        if self.ctrl:
            self.expand_matrix()
        return self._matrix

class P(Parasgate):
    """P GATE

    [[1,   0],
    [0, exp(1.j*θ)]
    """
    def __init__(self, paras, target, ctrl=None, dagger=False):
        super().__init__(name="P",symbol="P", paras=paras,ctrl=ctrl, target=target,  dagger=dagger)
        if dagger:
            self.symbol+="†"

        # todo
        if isinstance(self.paras,autograd.numpy.numpy_boxes.ArrayBox):
            # x = self.paras.shape
            if self.paras.size != 1 :
                self.batch_size = self.paras.size
            else:
                paras = [self.paras]
        else:
            if len(self.paras) != 1:
                self.batch_size = len(self.paras)
        # # change 这部分放在外面校验
        # if len(paras) != 1:
        #     raise ValueError("The number of parameters for P should be 1")


    def set_matrix(self,para):
        self._matrix = _p(para[0])
        self.old_matrix = _p(para[0])
        return self._matrix

    @property
    def matrix(self):
        from ..circuit.parameters import Parameters
        paras = [i.value if isinstance(i,Parameters) else i for i in self.paras]
        # if isinstance(self.paras, autograd.numpy.numpy_boxes.ArrayBox):
        #     if self.batch_size is None:
        #         paras = [self.paras]
        self.set_matrix(paras)
        if self.dagger:
            self.symbol+="†"
            self._matrix = self._matrix.conjugate()
            self.old_matrix = self.old_matrix.conjugate()

        if self.ctrl:
            self.expand_matrix()
        return self._matrix


class SWAP(Noparasgate):
    """SWAP GATE

    [[1.+0.j 0.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 1.+0.j 0.+0.j]
     [0.+0.j 1.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 0.+0.j 1.+0.j]]
    """
    def __init__(self,target,ctrl=None,dagger=False):
        super().__init__(name="SWAP",target=target, ctrl=ctrl,dagger=dagger)
        self._matrix = np.array([[1., 0., 0., 0.],[0., 0., 1., 0.],[0., 1., 0., 0.],[0., 0., 0., 1.]], dtype=complex)
        self.old_matrix = np.array([[1., 0., 0., 0.], [0., 0., 1., 0.], [0., 1., 0., 0.], [0., 0., 0., 1.]], dtype=complex)
        self.symbol = "(X)"
        self.dagger = False
        if len(target)!= 2 :
            raise ValueError("SWAP element need two target")
        if ctrl:
            self.expand_matrix()

    def expand_matrix(self):
        if len(self.ctrl) >= 1:
            number = len(self._matrix)
            lens = 2 ** (len(self.ctrl) + 1) // (number //2)
            if lens not in [0,1]:
                conver_matrix = np.zeros((lens, lens))
                conver_matrix[lens - 1, lens - 1] = 1
                self._matrix = np.kron(conver_matrix, self._matrix)
                for i in range(len(self._matrix) - number):
                    for j in range(len(self._matrix) - number):
                        if i == j:
                            self._matrix[i, j] = 1
        else:
            raise ValueError("SWAP do not support multiple control bits(>1).")

    def _dagger(self):
        pass


class IsingZZ(Parasgate):
    """IsingZZ GATE

    [[exp(-0.5j*θ), 0, 0, 0]
     [0, exp(0.5j*θ), 0, 0]
     [0, 0, exp(0.5j*θ), 0]
     [0, 0, 0, exp(-0.5j*θ)]]
    """

    def __init__(self, paras, target, ctrl, dagger=False):
        super().__init__(name="IZZ", symbol="IZZ", paras=paras, target=target, ctrl=ctrl, dagger=dagger)
        if dagger:
            self.symbol += "†"
        if isinstance(self.paras, autograd.numpy.numpy_boxes.ArrayBox):
            # x = self.paras.shape
            if self.paras.size != 1:
                self.batch_size = self.paras.size
            else:
                self.paras = [self.paras]
        else:
            if len(self.paras) != 1:
                self.batch_size = len(self.paras)
                for para in self.paras:
                    if isinstance(para, Iterable):
                        raise ValueError("The number of parameters for IsingZZ should be 1")
            else:
                if isinstance(paras[0], Iterable):
                    raise ValueError("The number of parameters for IsingZZ should be 1")

    def set_matrix(self, para):
        self._matrix = _isingZZ(para[0])
        self.old_matrix = _isingZZ(para[0])
        return self._matrix

    @property
    def matrix(self):
        from ..circuit.parameters import Parameters
        paras = [i.value if isinstance(i, Parameters) else i for i in self.paras]
        self.set_matrix(paras)
        if self.dagger:
            self.symbol += "†"
            self._matrix = self._matrix.conjugate()
            self.old_matrix = self.old_matrix.conjugate()
        if self.ctrl:
            self.expand_matrix()
        return self._matrix

    def expand_matrix(self):
        if len(self.ctrl) >= 1:
            number = len(self._matrix)
            lens = 2 ** (len(self.ctrl) + 1) // (number //2)
            if lens not in [0,1]:
                conver_matrix = np.zeros((lens, lens))
                conver_matrix[lens - 1, lens - 1] = 1
                self._matrix = np.kron(conver_matrix, self._matrix)
                for i in range(len(self._matrix) - number):
                    for j in range(len(self._matrix) - number):
                        if i == j:
                            self._matrix[i, j] = 1
        else:
            raise ValueError("IsingZZ do not support multiple control bits(>1).")


class CNOT(Noparasgate):
    """CNOT GATE

    [[1.+0.j 0.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 1.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 0.+0.j 1.+0.j]
     [0.+0.j 0.+0.j 1.+0.j 0.+0.j]]
    """
    def __init__(self,target,ctrl=None,dagger=False):
        super().__init__(name="CNOT",symbol="CNOT",target=target, ctrl=ctrl,dagger=dagger)
        self._matrix=np.array([[0., 1.],[1., 0.]], dtype=complex)
        self.old_matrix = np.array([[0., 1.],[1., 0.]], dtype=complex)
        self.dagger = False
        if len(target)!= 1:
            raise ValueError("CNOT element need one target")
        if ctrl:
            self.expand_matrix()
        else:
            raise ValueError("CNOT need one ctrl")
    def _dagger(self):
        pass

class CX(Noparasgate):
    """CX GATE

    [[1.+0.j 0.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 1.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 0.+0.j 1.+0.j]
     [0.+0.j 0.+0.j 1.+0.j 0.+0.j]]
    """
    def __init__(self,target,ctrl=None,dagger=False):
        super().__init__(name="CX",symbol="CX",target=target, ctrl=ctrl,dagger=dagger)
        self._matrix = np.array([[0., 1.], [1., 0.]], dtype=complex)
        self.old_matrix = np.array([[0., 1.], [1., 0.]], dtype=complex)
        self.dagger = False
        if len(target)!= 1:
            raise ValueError("CX element need one target")
        if ctrl:
            self.expand_matrix()
        else:
            raise ValueError("CX need one ctrl")
    def _dagger(self):
        pass


class CZ(Noparasgate):
    """CZ GATE

    [[ 1.+0.j  0.+0.j  0.+0.j  0.+0.j]
     [ 0.+0.j  1.+0.j  0.+0.j -0.+0.j]
     [ 0.+0.j  0.+0.j  1.+0.j  0.+0.j]
     [ 0.+0.j -0.+0.j  0.+0.j -1.+0.j]]
    """
    def __init__(self,target,ctrl=None,dagger=False):
        super().__init__(name="CZ",symbol="CZ",target=target,ctrl=ctrl,dagger=dagger)
        self._matrix=np.array([[1., 0.],[0., -1.]], dtype=complex)
        self.old_matrix = np.array([[1., 0.],[0., -1.]], dtype=complex)
        self.dagger = False
        if len(target)!= 1:
            raise ValueError("CZ element need one target")
        if ctrl:
            self.expand_matrix()
        else:
            raise ValueError("CZ need one ctrl")
    def _dagger(self):
        pass

class TOFFOLI(Noparasgate):
    """TOFFOLI GATE

    [[1.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 1.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 1.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 0.+0.j 1.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 0.+0.j 0.+0.j 1.+0.j 0.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 1.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 1.+0.j]
     [0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 1.+0.j 0.+0.j]]
    """
    def __init__(self,target,ctrl=None,dagger=False):
        super().__init__(name="TOFFOLI",symbol="TOFFOLI",target=target, ctrl=ctrl,dagger=dagger)
        self._matrix=np.array([[0., 1.],[1., 0.]], dtype=complex)
        self.old_matrix = np.array([[0., 1.], [1., 0.]], dtype=complex)
        self.dagger = False
        if ctrl and len(ctrl)>1:
            self.expand_matrix()
        else:
            raise ValueError("TOFFOLI element require two control bits")
    def _dagger(self):
        pass

class CCX(Noparasgate):
    """CCX GATE

    [[1.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 1.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 1.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 0.+0.j 1.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 0.+0.j 0.+0.j 1.+0.j 0.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 1.+0.j 0.+0.j 0.+0.j]
     [0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 1.+0.j]
     [0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 0.+0.j 1.+0.j 0.+0.j]]
    """
    def __init__(self,target,ctrl=None,dagger=False):
        super().__init__(name="CCX",symbol="CCX",target=target, ctrl=ctrl,dagger=dagger)
        self._matrix = np.array([[0., 1.], [1., 0.]], dtype=complex)
        self.old_matrix = np.array([[0., 1.], [1., 0.]], dtype=complex)
        self.dagger = False
        if ctrl and len(ctrl)>1:
            self.expand_matrix()
        else:
            raise ValueError("CCX element require two control bits")
    def _dagger(self):
        pass


class MEASURE(Noparasgate):
    """MEASURE GATE"""
    def __init__(self, target, cbit):
        super().__init__(name="MEASURE", symbol="MEASURE", target=target,ctrl=None,
                         dagger=False
                         )
        self.cbit = cbit
    def _dagger(self):
        raise ValueError("The measure gate cannot have a dagger operation")



def usergate(name,matrix):
    """Users customize quantum gates through matrices """
    matrix = np.array(matrix,dtype=complex)
    matrix_c = matrix.conjugate()
    matrix_t = matrix_c.T
    size = matrix_t.shape[0]
    I = np.eye(size,dtype=complex)
    condition = (np.around(np.dot(matrix,matrix_t), 3)==I).all()
    if condition:
        class Newgate(Basicgate):
            def __init__(self,target, ctrl=None, symbol=None, dagger=False):
                super().__init__(name="NEW", symbol=name, ctrl=ctrl, target=target, dagger=dagger)
                self._matrix = matrix
                self.old_matrix = matrix
                if self.dagger:
                    self.symbol += "†"
                    self._matrix = self._matrix.T
                    self._matrix = self._matrix.conjugate()
                if 2 ** len(target) < size or 2 ** len(target) > size:
                    raise ValueError("matrix size is not match ctrl length")

            def expand_matrix(self):
                if len(self.ctrl) >= 1:
                    number = len(self._matrix)
                    lens = (2 ** len(self.ctrl) * self.old_matrix.shape[0] )// number
                    if lens not in [0, 1]:
                        conver_matrix = np.zeros((lens, lens))
                        conver_matrix[lens - 1, lens - 1] = 1
                        self._matrix = np.kron(conver_matrix, self._matrix)
                        for i in range(len(self._matrix) - number):
                            for j in range(len(self._matrix) - number):
                                if i == j:
                                    self._matrix[i, j] = 1

        return Newgate
    else:
        raise ValueError("This matrix is not a Unitary Matrix")

# theta,phi,beta = Parameters("theta"),Parameters("phi"),Parameters("beta")
# u1 = U1([theta],[0])
# u1.update_paras({"theta":1.23})
# print(u1.matrix)
# u1.update_paras({"theta":2.23})
# print(u1.matrix)
# u1.update_paras({"theta":3.23})
# print(u1.matrix)
#
# u2 = U2([phi,theta],[0],[1])
# u2.update_paras({"phi":1.23,"theta":1.54})
# print(u2.matrix)
# u2.update_paras({"theta":2.23,"phi":3.13})
# print(u2.matrix)
#
# u3 = U3([phi,theta,beta],[0])
# u3.update_paras({"phi":1.23,"theta":1.54,"beta":2.31})
# print(u3.matrix)
# gate = SWAP([0, 1], [2,3])
# print(gate.matrix.shape)
# print(gate.matrix.shape)