# -*- coding: utf-8 -*-
from .gate import U1,U2,U3,H,I,T,X,Y,Z,S,RX,RY,RZ,P,SWAP,CNOT,CX,CZ,TOFFOLI,CCX,MEASURE,usergate
from scipy.optimize import root,fsolve
import autograd.numpy as np
from sympy import symbols,E,cos,sin,solve,re
from scipy.linalg import eig
# 只做单比特受控门分解
# 支持基本门、单比特受控门、自定义单比特受控门
# f1-f4是公式，求得四个参数，通过四个参数计算A、B、C，最终得到分解结果
# 基本门的受控门分解预设好，主要解决任意单比特门（未知）受控门的分解
# 单比特受控门分解
def resolve(gate):
    if not isinstance(gate,(CCX,TOFFOLI)):
        if gate.matrix.shape[0] > 4:
            raise ValueError("Quantum gate decomposition only supports single bit controlled gates")

    if isinstance(gate, H):
        if gate.ctrl is not None:
            return "ch q[%s],q[%s];\n" % (gate.ctrl[0], gate.target[0])
        else:
            return "h q[%s];\n" % gate.target[0]

    elif isinstance(gate, X):
        if gate.ctrl is not None:
            return "cx q[%s],q[%s];\n" % (gate.ctrl[0], gate.target[0])
        else:
            return "x q[%s];\n" % gate.target[0]

    elif isinstance(gate, I):
        if gate.ctrl is not None:
            return "ci q[%s],q[%s];\n" % (gate.ctrl[0], gate.target[0])
        else:
            return "i q[%s];\n" % gate.target[0]

    elif isinstance(gate, Y):
        if gate.ctrl is not None:
            return "cy q[%s],q[%s];\n" % (gate.ctrl[0], gate.target[0])
        else:
            return "y q[%s];\n" % gate.target[0]

    elif isinstance(gate, Z):
        if gate.ctrl is not None:
            return "cz q[%s],q[%s];\n" % (gate.ctrl[0], gate.target[0])
        else:
            return "z q[%s];\n" % gate.target[0]

    elif isinstance(gate, (CX, CNOT)):
        return "cx q[%s],q[%s];\n" % (gate.ctrl[0],gate.target[0])

    elif isinstance(gate, (CCX, TOFFOLI)):
        return "ccx q[%s],q[%s],q[%s];\n" % (gate.ctrl[0], gate.ctrl[1], gate.target[0])

    elif isinstance(gate, CZ):
        return "cz q[%s],q[%s];\n" % (gate.ctrl[0], gate.target[0])

    elif isinstance(gate, MEASURE):
        str1 = "measure" + " q[%s] -> c[%s];" % (gate.target[0], gate.cbit[0]) + "\n"
        return str1


    elif isinstance(gate, S):
        if gate.ctrl is not None:
            if not gate.dagger:
                return "cs q[%s],q[%s];\n" % (gate.ctrl[0], gate.target[0])
            else:
                return "csdg q[%s],q[%s];\n" % (gate.ctrl[0], gate.target[0])
        else:
            if gate.dagger:
                return "sdg q[%s];\n" % gate.target[0]
            else:
                return "s q[%s];\n" % gate.target[0]

    elif isinstance(gate, T):
        if gate.ctrl is not None:
            if not gate.dagger:
                return "ct q[%s],q[%s];\n" % (gate.ctrl[0], gate.target[0])
            else:
                return "ctdg q[%s],q[%s];\n" % (gate.ctrl[0], gate.target[0])
        else:
            if gate.dagger:
                return "tdg q[%s];\n" % gate.target[0]
            else:
                return "t q[%s];\n" % gate.target[0]

    elif isinstance(gate,U1):
        if gate.ctrl is not None:
            if not gate.dagger:
                return "cu1(%.3f) q[%s],q[%s];\n" % (gate.paras[0], gate.ctrl[0], gate.target[0])
            else:
                return "cu1(%.3f) q[%s],q[%s];\n" % (-gate.paras[0], gate.ctrl[0], gate.target[0])
        else:
            if not gate.dagger:
                return "u1(%.3f) q[%s];\n" % (gate.paras[0],gate.target[0])
            else:
                return "u1(%.3f) q[%s];\n" % (-gate.paras[0], gate.target[0])

    elif isinstance(gate,U2):
        if gate.ctrl is not None:
            if not gate.dagger:
                return "cu2(%.3f,%.3f) q[%s],q[%s];\n" % (gate.paras[0], gate.paras[1], gate.ctrl[0], gate.target[0])
            else:
                return "cu2(%.3f,%.3f) q[%s],q[%s];\n" % (np.pi-gate.paras[1], np.pi-gate.paras[0], gate.ctrl[0], gate.target[0])
        else:
            if not gate.dagger:
                return "u2(%.3f,%.3f) q[%s];\n" % (gate.paras[0],gate.paras[1],gate.target[0])
            else:
                return "u2(%.3f,%.3f) q[%s];\n" % (np.pi-gate.paras[1], np.pi-gate.paras[0], gate.target[0])

    elif isinstance(gate,U3):
        if gate.ctrl is not None:
            if not gate.dagger:
                return "cu3(%.3f,%.3f,%.3f) q[%s],q[%s];\n" % (gate.paras[0], gate.paras[1], gate.paras[2],gate.ctrl[0], gate.target[0])
            else:
                return "cu3(%.3f,%.3f,%.3f) q[%s],q[%s];\n" % (gate.paras[0], np.pi-gate.paras[2], np.pi-gate.paras[1], gate.ctrl[0], gate.target[0])
        else:
            if not gate.dagger:
                return "u3(%.3f,%.3f,%.3f) q[%s];\n" % (gate.paras[0],gate.paras[1], gate.paras[2],gate.target[0])
            else:
                return "u3(%.3f,%.3f,%.3f) q[%s];\n" % (gate.paras[0], np.pi-gate.paras[2], np.pi-gate.paras[1], gate.target[0])

    elif isinstance(gate, RX):
        if gate.ctrl is not None:
            if not gate.dagger:
                return "crx(%.3f) q[%s],q[%s];\n" % (gate.paras[0], gate.ctrl[0], gate.target[0])
            else:
                return "crx(%.3f) q[%s],q[%s];\n" % (-gate.paras[0], gate.ctrl[0], gate.target[0])
        else:
            if not gate.dagger:
                return "rx(%.3f) q[%s];\n" % (gate.paras[0],gate.target[0])
            else:
                return "rx(%.3f) q[%s];\n" % (-gate.paras[0], gate.target[0])

    elif isinstance(gate, RY):
        if gate.ctrl is not None:
            if not gate.dagger:
                return "cry(%.3f) q[%s],q[%s];\n" % (gate.paras[0], gate.ctrl[0], gate.target[0])
            else:
                return "cry(%.3f) q[%s],q[%s];\n" % (-gate.paras[0], gate.ctrl[0], gate.target[0])
        else:
            if not gate.dagger:
                return "ry(%.3f) q[%s];\n" % (gate.paras[0], gate.target[0])
            else:
                return "ry(%.3f) q[%s];\n" % (-gate.paras[0], gate.target[0])

    elif isinstance(gate, RZ):
        if gate.ctrl is not None:
            if not gate.dagger:
                return "crz(%.3f) q[%s],q[%s];\n" % (gate.paras[0], gate.ctrl[0], gate.target[0])
            else:
                return "crz(%.3f) q[%s],q[%s];\n" % (-gate.paras[0], gate.ctrl[0], gate.target[0])
        else:
            if not gate.dagger:
                return "rz(%.3f) q[%s];\n" % (gate.paras[0], gate.target[0])
            else:
                return "rz(%.3f) q[%s];\n" % (-gate.paras[0], gate.target[0])

    elif isinstance(gate, P):
        if gate.ctrl is not None:
            if not gate.dagger:
                return "cp(%.3f) q[%s],q[%s];\n" % (gate.paras[0], gate.ctrl[0], gate.target[0])
            else:
                return "cp(%.3f) q[%s],q[%s];\n" % (-gate.paras[0], gate.ctrl[0], gate.target[0])
        else:
            if not gate.dagger:
                return "p(%.3f) q[%s];\n" % (gate.paras[0],gate.target[0])
            else:
                return "p(%.3f) q[%s];\n" % (-gate.paras[0], gate.target[0])


    elif isinstance(gate,SWAP):
        str1 = "swap" + " q[%s],q[%s];" % (gate.target[0], gate.target[1])+ "\n"
        return str1

    if gate.old_matrix.shape[0] == 4:
        raise ValueError("Quantum gate decomposition only supports single bit controlled gates")
    matrix = gate.old_matrix

    for index in np.ndindex(matrix.shape):
        # 获取当前元素的实部和虚部
        real = matrix[index].real
        imag = matrix[index].imag

        if abs(real)<1e-5:
            real = 0
        if abs(imag)<1e-5:
            imag = 0

        matrix[index] = real + imag*1j

    if gate.ctrl==None :
        onebit = True
    else:
        onebit = False

    alpha,beta,gamma,theta= symbols('alpha beta gamma theta')

    tag = 0
    for data in np.nditer(matrix):
        if data == 0:
            tag += 1

    if np.sin(np.arccos(matrix[0, 0])) == matrix[0, 1] and matrix[0, 0]== matrix[1, 1]:
        f1 = 1j * (alpha - beta / 2 - theta / 2)
        f2 = 1j * (alpha - beta / 2 + theta / 2)
        f3 = 1j * (alpha + beta / 2 - theta / 2)
        f4 = cos(gamma / 2) - matrix[1, 1]
    else:
        f1 = E**(1j * (alpha - beta / 2 - theta / 2)) * cos(gamma / 2) - matrix[0, 0]
        f2 = -1 * E**(1j * (alpha - beta / 2 + theta / 2)) * sin(gamma / 2) - matrix[0, 1]
        f3 = E**(1j * (alpha + beta / 2 - theta / 2)) * sin(gamma / 2) - matrix[1, 0]
        f4 = E**(1j * (alpha + beta / 2 + theta / 2)) * cos(gamma / 2) - matrix[1, 1]

    tag = 0
    for data in np.nditer(matrix):
        if data == 0:
            tag += 1

    try:
        if tag==2:
            f5 = theta - beta
            result = solve([f1,f2,f3,f4,f5],[alpha, beta, gamma, theta])
        else:
            result = solve([f1, f2, f3, f4], [alpha, beta, gamma, theta])
    except NotImplementedError:
        raise ValueError("The quantum gate %s decomposition error"%gate.name)


    if isinstance(result,list):
        result = result[0]
    elif isinstance(result,dict):
        result = [result[i] for i in [alpha, beta, gamma, theta]]

    result = [float(re(i/np.pi)) for i in result]

    alpha, beta, gamma, theta = result[0], result[1], result[2], result[3]

    if onebit:
        raise ValueError("Quantum gate decomposition only supports single bit controlled gates")
    else:
        target = gate.target[0]
        control = gate.ctrl[0]
        result = "rz(%.3f*pi) q[%d];\ncx q[%d],q[%d];\nrz(%.3f*pi) q[%d];\nry(%.3f*pi) q[%d];\ncx q[%d],q[%d];\nu1(%.3f*pi) q[%d];\nry(%.3f*pi) q[%d];\nrz(%.3f*pi) q[%d];\n"%((theta-beta)/2,target,control,target,(beta+theta)/-2,target,gamma/-2,target,control,target,alpha,control,gamma/2,target,beta,target)

    return result


def three_gate_decompose(gate):
    eigenvalues, eigenvectors = eig(gate([0]).matrix)

    sqrt_eigenvalues = np.sqrt(eigenvalues)  # 注意复数平方根的处理可能需要额外的规则
    P = eigenvectors
    D_sqrt = np.diag(sqrt_eigenvalues)
    V = P @ D_sqrt @ np.linalg.inv(P)
    return V





