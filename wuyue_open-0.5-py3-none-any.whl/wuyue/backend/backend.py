# -*- coding: utf-8 -*-
from ..element.gate import MEASURE
from ..circuit.circuit import QuantumCircuit
from ..programe.prog import QuantumProg
import numpy as np
from .backend_amplitude import AmplitudeBackend
from .backend_density_matrix import DensityMatrixBackend
from .backend_single_amplitude import SingleAmpBackend
from .backend_partial_amplitude import PartialAmpBackend
from .backend_tensor_circuit import TensorCircuitBackend
from abc import ABC
class Backend(ABC):
    """
    Quantum simulator that simulate quantum circuit.

    Args:
        backend (str): which backend you want. SDK only support Full amplitude simulators

    Raises:
        TypeError: if `backend_name` is not str.
        ValueError: if `backend_name` is not supported.

    Examples:
        from wuyue.backend import Backend
        sim = Backend(backend_name="Full amplitude")
        sim.state
        None
        sim.circuit
        None
    """
    @classmethod
    def get_device(self, device_name="Full amplitude"):
        self.device_name = device_name
        if not isinstance(device_name,str):
            raise TypeError("SDK computing backend needs to be a string")
        if device_name == "Full amplitude":
            self.device = AmplitudeBackend()
        elif device_name == "Tensor Circuit":
            self.device = TensorCircuitBackend()
        elif device_name == "Density matrix":
            self.device = DensityMatrixBackend()
        elif device_name == "Single amplitude":
            self.device = SingleAmpBackend()
        elif device_name == "Partial amplitude":
            self.device = PartialAmpBackend()
        else:
            raise ValueError("SDK only support Full amplitude simulators and does not support %s"%device_name)
        return self.device







