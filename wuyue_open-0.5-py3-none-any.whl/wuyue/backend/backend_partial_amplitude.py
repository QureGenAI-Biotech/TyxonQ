# -*- coding: utf-8 -*-
from ..simulator import partial_amplitude
from ..circuit.circuit import QuantumCircuit
from ..programe.prog import QuantumProg
import numpy as np
class PartialAmpBackend(object):
    """
    Quantum simulator that simulate quantum circuit.

    Args:
        backend (str): which backend you want. SDK only support Full amplitude simulators

    Raises:
        TypeError: if `backend_name` is not str.
        ValueError: if `backend_name` is not supported.

    Examples:
        from wuyue.backend import Backend
        sim = Backend(backend_name="Full amplitude")
        sim.state
        None
        sim.circuit
        None
    """
    def __init__(self):
        self.simulator = partial_amplitude.Sim_partial
        self.circuit = None

    def apply(self,circuit):
        """
        Apply a circuit on this simulator.

        Args:
            circuit (QuantumCircuit or QuantumProg): The circuit you want to apply.

        Raises:
            TypeError: if `circuit` is not a QuantumCircuit or QuantumProg.
            ValueError: if `circuit` already exists.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            from wuyue.backend import Backend
            sim = Backend(backend_name="Full amplitude")
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            q.all_add(H)
            sim.apply(q)
            print(sim.get_states())
            ['0.500+0.000j', '0.500+0.000j', '0.500+0.000j', '0.500+0.000j']
        """
        if not isinstance(circuit,(QuantumCircuit,QuantumProg)):
            raise TypeError("The input circuit is not QuantumCircuit or QuantumProg")
        if not self.circuit:
            self.circuit = circuit
            self.circuit.apply_circuit()
            self.sim = self.simulator(self.circuit)
        else:
            raise ValueError("There are Quantum circuit on the back end of the calculation, and new Quantum circuit cannot be added")


    def __str__(self):
        """Return a string representation of the object."""
        # self._repr = "%s(%d, '%s')" % (self.__class__.__qualname__, self._bits, self._name)
        ret = "SingleAmp backend"
        if self.circuit:
            ret += " with %s"%str(self.circuit)
        return ret

    def __repr__(self):
        return self.__str__()

    def get_partialamps(self,amps):
        result = self.sim.cal_partialamps(amps)
        return result

    def get_partialprobs(self,amps):
        result = self.sim.cal_partialamps(amps)
        result = [i**2 for i in result]
        return result

    def clear(self):
        """
        Clear the circuit inside the simulator.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            from wuyue.backend import Backend
            sim = Backend(backend_name="Full amplitude")
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            q.all_add(H)
            sim.apply(q)
            print(sim.get_states())
            ['0.500+0.000j', '0.500+0.000j', '0.500+0.000j', '0.500+0.000j']
            sim.clear()
            print(sim.state)
            None
            print(sim.circuit)
            None
        """
        self.circuit = None
        self.state = None
        self.sim = None

    def _verify_parameters(self):
        if self.circuit.use_parameter is None:
            pass
        else:
            for paras in self.circuit.use_parameter.values():
                if paras.value is None:
                    raise ValueError(f"parameter {paras.name} not assigned a value")

    def bind_parameters(self, key_value: dict):
        for key, value in key_value.items():
            from ..circuit.parameters import Parameters,ParameterVector
            if isinstance(key,Parameters):
                name = key.name
            elif isinstance(key, str):
                name = key
            elif isinstance(key,ParameterVector):
                if isinstance(value,(list,np.ndarray)) and len(value)==len(key):
                    for index,paras in enumerate(key):
                        name = paras.name
                        if name in self.circuit.use_parameter.keys():
                            self.circuit.use_parameter[name].set_data(value[index])
                        else:
                            raise ValueError(f"Cannot bind parameters {name} not present in the circuit.")
                    continue
                else:
                    raise ValueError("The value of the dictionary needs to be a list or numpy array, "
                                     "and its number should be equal to the number of parameters")
            else:
                raise TypeError("The keys of the dictionary need to be related to the parameters")
            if name in self.circuit.use_parameter.keys():
                self.circuit.use_parameter[name].set_data(value)
            else:
                raise ValueError(f"Cannot bind parameters {key} not present in the circuit.")


