# -*- coding: utf-8 -*-
from ..simulator import full_amplitude,machine_learning
from ..element.gate import MEASURE
from ..circuit.circuit import QuantumCircuit
from ..programe.prog import QuantumProg

import autograd.numpy as np
class AmplitudeBackend(object):
    """
    Quantum simulator that simulate quantum circuit.

    Args:
        backend (str): which backend you want. SDK only support Full amplitude simulators

    Raises:
        TypeError: if `backend_name` is not str.
        ValueError: if `backend_name` is not supported.

    Examples:
        from wuyue.backend import Backend
        sim = Backend(backend_name="Full amplitude")
        sim.state
        None
        sim.circuit
        None
    """
    def __init__(self):
        self.simulator = full_amplitude.Sim_full
        self.state = None
        self.circuit = None

    def apply(self,circuit,autograd=False):
        """
        Apply a circuit on this simulator.

        Args:
            circuit (QuantumCircuit or QuantumProg): The circuit you want to apply.

        Raises:
            TypeError: if `circuit` is not a QuantumCircuit or QuantumProg.
            ValueError: if `circuit` already exists.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            from wuyue.backend import Backend
            sim = Backend(backend_name="Full amplitude")
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            q.all_add(H)
            sim.apply(q)
            print(sim.get_states())
            ['0.500+0.000j', '0.500+0.000j', '0.500+0.000j', '0.500+0.000j']
        """
        if not isinstance(circuit,(QuantumCircuit,QuantumProg)):
            raise TypeError("The input circuit is not QuantumCircuit or QuantumProg")
        if not self.circuit:
            if autograd:
                self.simulator = machine_learning.Sim_full
            else:
                self.simulator = full_amplitude.Sim_full
            if circuit.qubits > 30:
                raise ValueError("Quantum circuit exceeds 30 bits, the backend cannot calculate")
            self.circuit = circuit
            self.circuit.apply_circuit()
            self.sim = self.simulator(self.circuit)
        else:
            raise ValueError("There are Quantum circuit on the back end of the calculation, and new Quantum circuit cannot be added")


    def __str__(self):
        """Return a string representation of the object."""
        # self._repr = "%s(%d, '%s')" % (self.__class__.__qualname__, self._bits, self._name)
        ret = "Full Amplitude backend"
        if self.circuit:
            ret += " with %s"%str(self.circuit)
        return ret

    def __repr__(self):
        return self.__str__()

    def run(self,shots):
        """
        Perform full amplitude analog measurements on the circuit.

        Args:
            shots (int): Number of circuit measurements.

        Raises:
            ValueError: if `circuit` not exists.
            ValueError: if `circuit` does not have MEASURE gate.

        Returns:
            dict, Circuit measurement results.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            from wuyue.backend import Backend
            sim = Backend(backend_name="Full amplitude")
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit,cbit)
            q.all_add(H)
            q.all_add(MEASURE)
            sim.apply(q)
            print(sim.run(1000))
            {'00': 249, '01': 244, '10': 265, '11': 242}
        """
        if self.circuit is None:
            raise ValueError(
                "Quantum circuit has not been added to the back end of quantum computing")
        if not isinstance(self.circuit.gates[-1],MEASURE):
            raise ValueError("The circuit does not have a measurement gate and cannot be measured")
        self._verify_parameters()
        return self.sim.run(shots)

    def get_probs(self,bits=None):
        """
        Perform full amplitude analog measurements on the circuit.

        Raises:
            ValueError: if `circuit` not exists.

        Returns:
            list, Expected results of the circuit.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            from wuyue.backend import Backend
            sim = Backend(backend_name="Full amplitude")
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            q.all_add(H)
            sim.apply(q)
            print(sim.get_probs())
            ['0.250', '0.250', '0.250', '0.250']
        """
        if self.circuit is None:
            raise ValueError(
                "Quantum circuit has not been added to the back end of quantum computing")
        self._verify_parameters()
        return self.sim.cal_probs()

    def get_density_matrix(self):
        if self.circuit is None:
            raise ValueError(
                "Quantum circuit has not been added to the back end of quantum computing")
        self._verify_parameters()
        if self.circuit.qubits > 15:
            raise ValueError(
                "Quantum circuit exceeds 15 bits, unable to calculate density matrix")
        psi = self.sim.cal_states(self.circuit.gates, self.circuit.start_state)
        density_matrix = np.outer(psi, psi.conj().T)
        return density_matrix

    def get_states(self):
        """
        Current Quantum state of the circuit.

        Raises:
            ValueError: if `circuit` not exists.

        Returns:
            list, Current Quantum state of the circuit.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            from wuyue.backend import Backend
            sim = Backend(backend_name="Full amplitude")
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            q.all_add(H)
            sim.apply(q)
            print(sim.get_states())
            ['0.500+0.000j', '0.500+0.000j', '0.500+0.000j', '0.500+0.000j']
        """
        if self.circuit is None:
            raise ValueError(
                "Quantum circuit has not been added to the back end of quantum computing")
        self._verify_parameters()
        psi = self.sim.cal_states(self.circuit.gates, self.circuit.start_state)
        self.circuit.state = psi
        self.state = psi
        return psi

    def get_amps(self):
        """
        Perform full amplitude simulation of the circuit amplitude.

        Raises:
            ValueError: if `circuit` not exists.

        Returns:
            list, Expected results of the circuit.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            from wuyue.backend import Backend
            sim = Backend(backend_name="Full amplitude")
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            q.all_add(H)
            sim.apply(q)
            print(sim.get_amps())
            ['0.500', '0.500', '0.500', '0.500']
        """
        if self.circuit is None:
            raise ValueError(
                "Quantum circuit has not been added to the back end of quantum computing")
        self._verify_parameters()
        return self.sim.cal_amp()

    def get_phase(self):
        """
        Perform full amplitude simulation of the circuit phase.

        Raises:
            ValueError: if `circuit` not exists.

        Returns:
            list, Expected results of the circuit.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            from wuyue.backend import Backend
            sim = Backend(backend_name="Full amplitude")
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            q.all_add(RX, paras=[pi / 2])
            sim.apply(q)
            print(sim.get_phase())
            ['0.000', '-1.571', '-1.571', '3.142']
        """
        if self.circuit is None:
            raise ValueError(
                "Quantum circuit has not been added to the back end of quantum computing")
        self._verify_parameters()
        return self.sim.cal_phase()

    def expval_pauli(self, pauli_list):
        if self.circuit is None:
            raise ValueError(
                "Quantum circuit has not been added to the back end of quantum computing")
        self._verify_parameters()
        return self.sim.expval_pauli(pauli_list)

    def expval_pauli_test(self,pauli_list):
        if self.circuit is None:
            raise ValueError(
                "Quantum circuit has not been added to the back end of quantum computing")
        self._verify_parameters()
        return self.sim.expval_pauli_test(pauli_list)

    def clear(self):
        """
        Clear the circuit inside the simulator.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            from wuyue.backend import Backend
            sim = Backend(backend_name="Full amplitude")
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            q.all_add(H)
            sim.apply(q)
            print(sim.get_states())
            ['0.500+0.000j', '0.500+0.000j', '0.500+0.000j', '0.500+0.000j']
            sim.clear()
            print(sim.state)
            None
            print(sim.circuit)
            None
        """
        self.circuit = None
        self.state = None

    def _verify_parameters(self):
        if self.circuit.use_parameter is None:
            pass
        else:
            for paras in self.circuit.use_parameter.values():
                if paras.value is None:
                    raise ValueError(f"parameter {paras.name} not assigned a value")

    def bind_parameters(self, key_value: dict):
        for key, value in key_value.items():
            from ..circuit.parameters import Parameters,ParameterVector
            if isinstance(key,Parameters):
                name = key.name
            elif isinstance(key, str):
                name = key
            elif isinstance(key,ParameterVector):
                if isinstance(value,(list,np.ndarray)) and len(value)==len(key):
                    for index,paras in enumerate(key):
                        name = paras.name
                        if name in self.circuit.use_parameter.keys():
                            self.circuit.use_parameter[name].set_data(value[index])
                        else:
                            raise ValueError(f"Cannot bind parameters {name} not present in the circuit.")
                    continue
                else:
                    raise ValueError("The value of the dictionary needs to be a list or numpy array, "
                                     "and its number should be equal to the number of parameters")
            else:
                raise TypeError("The keys of the dictionary need to be related to the parameters")
            if name in self.circuit.use_parameter.keys():
                self.circuit.use_parameter[name].set_data(value)
            else:
                raise ValueError(f"Cannot bind parameters {key} not present in the circuit.")


