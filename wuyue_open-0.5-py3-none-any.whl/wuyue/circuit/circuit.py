# -*- coding: utf-8 -*-
import autograd.numpy.numpy_boxes

from ..element.gate import *
from ..element.noise import *
from ..element.decompose import resolve
from .parameters import Parameters,ParameterVector
import re
import copy
from collections.abc import Iterable
from ..register.classicalregister import ClassicalRegister
from ..register.quantumregister import QuantumRegister
from ..register.Bit import Bit
import itertools
from typing import Optional, Union
import autograd.numpy as np
from ..ecloudsdkcore.license.require_license import require_license

@require_license
class QuantumCircuit(object):
    """
    The quantum circuit module.
    A quantum circuit consists of quantum registers, which contain one or more
    quantum gates and can be simulated and calculated in a quantum simulator.
    By adding quantum gates to quantum circuits, different quantum circuits can be constructed

    Args:
        qreg (QuantumRegister): A Quantum register for storing quantum gates
        creg (ClassicalRegister): A Classical Register for storing quantum computing results
        name (str) : A Quantum circuit' name

    Raises:
        TypeError: if Quantum register is not QuantumRegister class
        TypeError: if Classical register is not ClassicalRegister class

    Examples:
        from wuyue.circuit import QuantumCircuit
        from wuyue.register.classicalregister import ClassicalRegister
        from wuyue.register.quantumregister import QuantumRegister
        qubit = QuantumRegister(2)
        cbit = ClassicalRegister(2)
        q = QuantumCircuit(qubit, cbit)
        print(q.qreg)
        QuantumRegister(2, 'qubit0')
        print(q.creg)
        ClassicalRegister(2, 'cbit0')
        print(q.name)
        Circuit0
    """
    instances_counter = itertools.count()
    def __init__(self, qreg: QuantumRegister, creg:ClassicalRegister, name = None):
        if isinstance(qreg, QuantumRegister):
            self.qreg = qreg
            self.qubits = len(self.qreg)
        else:
            raise TypeError("Quantum register must be of the QuantumRegister class")
        if isinstance(creg, ClassicalRegister):
            self.creg = creg
            for i in self.creg:
                i.append(0)
            self.cbits = len(self.creg)
        else:
            raise TypeError("Classical register must be of the ClassicalRegister class")

        self.gate_list = [CNOT, TOFFOLI,  MEASURE, H,
                          X, Y, Z, T, S, RX, RY, RZ, P, U1, U2, U3, CX, CZ, CCX, SWAP,IsingZZ]
        self.noise_list = [BitFlip, PhaseFlip, PauliChannel, Depolarizing, AmplitudeDamping, GeneralizedAmplitudeDamping,
                           PhaseDamping, TwoQubitDepolarizing, TwoQubitDephasing,]
        self._gates = []
        self.start_state = None
        self.state = None
        self._end = False
        self.readout_noise = [[] for i in range(self.qubits)]
        self.readout_tag = False
        self.controled = []
        self._use_parameters = []
        self.start_pos = 0
        self.symbol_dagger = False
        self.batch_size = None
        if name:
            self.name = name
        else:
            self.name = "Circuit" + str(next(self.instances_counter))

    def __str__(self):
        """Return a string representation of the object."""
        self._repr = "%s(%s,%s)" % (self.__class__.__qualname__, str(self.qreg),str(self.creg))
        return self._repr

    def __repr__(self):
        return self.__str__()


    def _add_noise(self, nosie:KrausOperation, target:Union[list,QuantumRegister], *args, **kwargs):
        """Add a nosie operated to the circuit"""
        if len(set(target)) != len(target):
            raise ValueError("Target cannot have duplicate values")
        if issubclass(nosie, KrausOperation):
            self.__insert_noise(nosie, target, *args, **kwargs)
            return self


    # circuit.add(gate, target, control,paras,dagger)
    # target只能有一个，ctrl可以有n个
    def add(self, operate, target:Union[list, Bit], *args, **kwargs) -> object:
        """
        Adding Quantum Gates to Quantum Circuits.

        Args:
            gate (Basicgate): The quantum gate you want to apply
            target (Bit): The Target position of quantum register to be applied
            control (Bit): The control position of quantum register to be applied
            paras (list): Parameters of quantum gates
            dagger (bool): Whether to perform Hermitian conjugation on quantum

        Raises:
            TypeError: If the target bits of quantum gates are of type other than Bit.
            TypeError: If the control bits of quantum gates are of type other than Bit.
            TypeError: If 'quantum gate' is not a reasonable quantum gate.
            ValueError: If 'quantum gate' has duplicate target positions
            ValueError: If 'quantum gates' have equal target and control positions
            ValueError: If 'quantum gate' has a target position that exceeds the circuit limit
            ValueError: If 'measure quantum gates' have not classical register position
            ValueError: If 'measure quantum gate' has a classical position that exceeds the register limit
            ValueError: If 'measure quantum gate' has different numbers of quantum register positions and classical register positions

        Returns：
            QuantumCircuit, The quantum circuit with this quantum gate added.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit,cbit)
            q.add(H,qubit[0]).add(H,qubit[1]).add(X,qubit[0]).add(X,qubit[1])
            q.draw()
            q0   ―――――――H――――――――――――――X―――――――

            q1   ―――――――H――――――――――――――X―――――――

            c    ――――――――――――――――――――――――――――――
        """
        if not isinstance(target,list):
            raise TypeError("The target bit can be of type list")

        substring = self.qreg._name
        target = self._bit_to_list(target,substring)

        if issubclass(operate,(Basicgate,BARRIER,RESET)):
            if operate == MEASURE:
                self._add_measure(target, *args, **kwargs)
            elif operate == BARRIER:
                self.qreg[target[0]].append(operate(target=target[0]))
            elif operate == RESET:
                self.qreg[target[0]].append(operate(target=target[0]))
            else:
                self._add_gate(operate, target, *args, **kwargs)
        elif issubclass(operate,KrausOperation):
            self._add_noise(operate, target, *args, **kwargs)
        elif issubclass(operate, Readout_Noise):
            noise = args[0](target, args[1])
            print('noise',noise)
            print('args[0]',args[0])
            readout_noise = Readout_Noise(target=target,noise=noise)
            self.readout_tag = True
            self.readout_noise[target[0]].append(readout_noise.noise)
        else:
            raise TypeError("circuit need a current operate class")
        return self

    def _add_measure(self, target, cbit:Union[ClassicalRegister,list]):
        substring = self.creg._name
        cbit = self._bit_to_list(cbit,substring)

        if not self._end:
            maxdepth = max([len(self.qreg[i]) for i in range(self.qubits)])
            for gates in self.qreg:
                gates.extend([None] * (maxdepth - len(gates)))
            self._end = True

        if self.readout_tag:
            for idx,val in enumerate(self.readout_noise):
                if idx == target[0] and val != []:
                    self.qreg[target[0]].append(val[0])


        if len(target) > self.cbits:
            raise ValueError("index of cbit out of creg")
        elif len(cbit) == len(target):
            for i in range(len(target)):
                self.qreg[target[i]].append(MEASURE(target=[target[i]], cbit=[cbit[i]]))
        else:
            raise ValueError("The number of quantum register positions and classical register positions of the measurement gate is different")

    def _add_gate(self, gate, target, control: Union[list,QuantumRegister,None] = None, paras:Union[list,None]=None, dagger=False):
        if control is not None:
            substring = self.qreg._name
            control = self._bit_to_list(control, substring)
            target_control = target + control
            if len(target_control) != len(set(target_control)):
                raise ValueError("There cannot be duplicate values in target and control")
        else:
            if len(target) != len(set(target)):
                raise ValueError("Target cannot have duplicate values")

        # 判断参数是否是可迭代对象，标量转列表
        if paras is not None:
            try:
                iter(paras)
            except TypeError:
                paras = [paras]
        # if paras is not None:
        #     try:
        #         iter(paras)
        #         if isinstance(paras,autograd.numpy.numpy_boxes.ArrayBox):
        #             paras = [paras]
        #     except TypeError:
        #         if isinstance(paras, np.ndarray) and paras.ndim == 0:
        #             paras = paras.item()
        #         paras = [paras]

        if gate not in self.gate_list or gate == SWAP or gate == IsingZZ:
            self.__insert_qubit(gate, target, control, paras, dagger)
        else:
            if len(target) > 1:
                raise ValueError("The add function can only operate on one quantum gate")
            elif len(target) == 1:
                self.__insert_qubit(gate, target, control, paras, dagger)

    def mul_add(self, operate:Union[Basicgate, KrausOperation], target:Union[list, Bit], *args, **kwargs) -> object:
        """
        Apply quantum gates to multi bits of quantum circuits

        Args:
            operate (Basicgate, KrausOperation): The quantum gate you want to apply
            target (list(Bit)): The Target position of quantum register to be applied
            control (list(Bit)): The control position of quantum register to be applied
            paras (list): Parameters of quantum gates
            dagger (bool): Whether to perform Hermitian conjugation on quantum
            bits (int): The number of bits for user quantum gates

        Raises:
            TypeError: If the target bits of quantum gates are of type other than Bit.
            TypeError: If the control bits of quantum gates are of type other than Bit.
            ValueError: If the number of bits in a custom quantum gate exceeds 3 bits.
            ValueError: The proportion of the number of quantum gate control bits to the number of target bits is inconsistent
            TypeError: If 'quantum gate' is not a reasonable quantum gate.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(3)
            cbit = ClassicalRegister(3)
            q = QuantumCircuit(qubit,cbit)
            q.mul_add(H,qubit[0,1,2])
            q.mul_add(CNOT,qubit[1,2],qubit[0,1])
            q.draw()
            q0   ―――――――H――――――――――――――●――――――――――――――――――――
                                                    ┃
            q1   ―――――――H―――――――――――――CNOT――――――――――――●―――――――
                                                                          ┃
            q2   ―――――――H―――――――――――――――――――――――――――CNOT――――――

            c    ―――――――――――――――――――――――――――――――――――――――――――
        """
        if not isinstance(target,list):
            raise TypeError("The target bit can be of type list")
        substring = self.qreg._name
        target = self._bit_to_list(target,substring)
        print('target',target)

        if issubclass(operate, KrausOperation):
            if operate == TwoQubitDepolarizing or operate == TwoQubitDephasing:
                for index,value in enumerate(target):
                    # if index/2 == 0:#这里应该是取余不是除法
                    if index % 2 == 0:
                        self._add_noise(operate, target[index:index+2], *args, **kwargs)
            else:
                for i in target:
                    self._add_noise(operate, [i], *args, **kwargs)
            return self

        elif operate == MEASURE:
            self._add_measure(target, *args, **kwargs)
            return self

        elif operate == BARRIER:
            for i in target:
                self.qreg[i].append(BARRIER(target=i))
            return self

        elif operate == RESET:
            for i in target:
                self.qreg[i].append(RESET(target=i))
            return self

        elif issubclass(operate,Basicgate):
            self._mul_add_gate(operate, target, *args, **kwargs)
            return self
        else:
            raise TypeError("circuit need a current operate class")

    def _mul_add_gate(self, gate, target, control: Union[list, QuantumRegister, None] = None,
                      paras: Union[list, None] = None, dagger=False):
        if control is not None:
            substring = self.qreg._name
            control = self._bit_to_list(control, substring)

        # if not isinstance(paras, list) and paras is not None:
        #     paras = [paras]

        if gate == SWAP or gate == IsingZZ:
            gate_qubit = 2
        elif issubclass(gate, Basicgate) and gate not in self.gate_list:
            raise TypeError("The add function cannot support Newgate")
        else:
            gate_qubit = 1

        if control:
            multiple = len(control) / len(target)
            for index, value in enumerate(target):
                if index % gate_qubit == 0:
                    _target = target[index: index + gate_qubit]
                    _control = control[int(index * multiple):int((index + gate_qubit) * multiple)]
                    self._add_gate(gate, target=_target, control=_control, paras=paras, dagger=dagger)

        else:
            if gate_qubit == 1:
                for i in target:
                    self._add_gate(gate, target=[i], paras=paras, dagger=dagger)
                return self
            else:
                for index, value in enumerate(target): #两比特门不加控制位
                    if index % gate_qubit == 0:
                        self._add_gate(gate, target=target[index: index + gate_qubit], paras=paras, dagger=dagger)

    def _bit_to_list(self,target,substring):
        if isinstance(target,Bit):
            target = [target]
        for i in target:
            if isinstance(i, int):
                continue
            if not isinstance(i, Bit):
                raise TypeError("Please use the correct register for the position of the operater")
            else:
                if i.name != substring:
                    raise TypeError("Please use the correct register for the position of the operater")
                tar_tag = re.findall('\d+', re.sub(substring, "", str(target)))
                target = [int(i) for i in tar_tag]
        return target
    @property
    def gates(self):
        """Return to all quantum gates of the Quantum circuit"""
        return self._gates

    def apply_circuit(self):
        """Import the quantum gates of the Quantum circuit into the list in turn
         Raises:
            TypeError: If 'quantum gate' is not a reasonable quantum gate.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(3)
            cbit = ClassicalRegister(3)
            q = QuantumCircuit(qubit, cbit)
            q.mul_add(H, qubit[0, 1, 2])
            q.mul_add(CNOT, qubit[1, 2], qubit[0, 1])
            print(q.gates)
            []
            q.apply_circuit()
            print(q.gates)
            [H, H, H, CNOT, CNOT]
        """
        maxdepth = max([len(self.qreg[i]) for i in range(self.qubits)])
        for i in self.qreg:
            i.extend([None] * (maxdepth - len(i)))
        conver = np.array(self.qreg)
        self._gates = []
        for i in range(conver.shape[1]):
            gate_col = conver[:, i]
            for gate in gate_col:
                if isinstance(gate, Basicgate) or isinstance(gate, (RESET,BARRIER)):
                    self._gates.append(gate)
                elif isinstance(gate,KrausOperation):
                    self._gates.append(gate)
                elif gate==None or gate=="ctrl" :
                    continue


    def __check_compiler(self, complier:str):
        """Check whether the Pseudocode passed in by the quantum compiler is correct"""
        pattern_paras = r'^(RY|RZ|RX|P)\sq\[\d+\]\,\([0-9pi+\-*/.]+\)$'
        pattern_one = r'^(H|T|S|X|Y|Z|BARRIER|RESET)\sq\[\d+\]$'
        pattern_two = r'^(CX|CNOT|CZ|SWAP|IZZ)\sq\[\d+\]\,q\[\d+\]$'
        pattern_three = r'^(CCX|TOFFOLI)\sq\[\d+\]\,q\[\d+\]\,q\[\d+\]$'
        pattern_control =  r'^(CONTROL)\s(q\[\d+\]\,)*q\[\d+\]$'
        pattern_dagger = r'^(DAGGER|ENDDAGGER|ENDCONTROL)$'
        pattern_measure = r'^(MEASURE)\sq\[\d+\]\,c\[\d+\]$'
        input_split = complier.split("\n")
        dagger_tage = 0
        control_tag = 0
        for gate in input_split:
            if re.match(pattern_paras, gate) or re.match(pattern_one, gate) or re.match(pattern_two, gate) or re.match(pattern_three, gate) or \
                re.match(pattern_dagger, gate) or re.match(pattern_measure, gate):
                if gate=="DAGGER" and dagger_tage==1:
                    raise ValueError("After DAGGER, it should be ENDDAGGER")
                elif gate=="DAGGER" and dagger_tage==0:
                    dagger_tage = 1
                elif gate == "ENDDAGGER" and dagger_tage == 1:
                    dagger_tage = 0
                elif gate == "ENDDAGGER" and dagger_tage == 0:
                    raise ValueError("After ENDDAGGER, it should be DAGGER")
                elif gate == "ENDCONTROL" and control_tag == 1:
                    control_tag = 0
                elif gate == "ENDCONTROL" and control_tag == 0:
                    raise ValueError("Befor ENDCONTROL, it should be CONTROL")
            elif re.match(pattern_control, gate) :
                gate_name,bits = gate.split(" ")
                if gate_name=="CONTROL" and control_tag==0:
                    control_tag=1
                elif gate_name=="CONTROL" and control_tag==1:
                    raise ValueError("After CONTROL, it should be ENDCONTROL")
            else:
                raise ValueError("The input format is incorrect")
        if dagger_tage!=0 or control_tag!=0:
            raise ValueError("DAGGER and ENDDAGGER/CONTROL and ENDCONTROL need to match")

    def from_compiler(self,complier:str):
        """Constructing Quantum circuit from quantum Pseudocode
        Raises:
            TypeError: If 'quantum gate' is not a reasonable quantum gate.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            # 构建量子寄存器
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            # 构建量子线路
            q = QuantumCircuit(qubit, cbit)
            # 构建伪代码
            compiler_code = ""RY q[0],(0.785398)
            RX q[1],(0.785398)
            X q[0]
            SWAP q[1],q[0]
            S q[1]
            Z q[0]""
            q.from_compiler(compiler_code)
            # 绘制线路
            q.draw()
            q0   ―――RY(0.785)――――――――――X―――――――――――――(X)―――――――――――――Z―――――――
                                                                      ┃
            q1   ―――RX(0.785)――――――――――――――――――――――――(X)―――――――――――――S―――――――

            c    ―――――――――――――――――――――――――――――――――――――――――――――――――――――――
            """
        if "\r" in complier:
            complier = complier.replace("\r","")
        input_split = complier.split("\n")
        control_bit = None
        dagger = False

        for gate in input_split:
            if "(" in gate:
                # 分成三部分
                command_str, pars= gate.split("(")

                paras, index_str = pars.split(")")
                # eval
                paras = eval(paras,{"pi":np.pi})

            elif gate == "DAGGER": #?CONTROL相关的没有代码
                dagger = True
                continue

            elif gate == "ENDDAGGER":
                dagger = False
                continue

            elif issubclass(eval(gate.split(" ")[0]),(Basicgate,BARRIER,RESET)):
                paras = None
                command_str,index_str = gate.split(" ")
            else:
                raise TypeError("%s is not supported" % gate)

            index = re.findall("\d+", index_str)
            inds = [int(i) for i in index]
            command_str = eval(command_str)

            if command_str == SWAP or command_str==IsingZZ:
                target = inds[(len(inds)-2):]
                control = inds[:(len(inds)-2)]
            elif command_str == MEASURE:
                target = inds[-1:]
                cbit = inds[:-1]
                self.add(command_str, target, cbit)
                continue
            else:
                target = inds[-1:]
                control = inds[:-1]
            self.add(command_str,target,control,paras,dagger)

    def __check_qasm(self, qasm: str):

        """Check whether the Pseudocode passed in by the quantum compiler is correct"""
        # 提取并验证 OPENQASM 2.0 基本语法
        # 定义OPENQASM 2.0基本语法正则化表达式模式
        # gate_list = ["gp0",""]
        pattern_openqasm = r'^OPENQASM 2.0;$'
        pattern_include = r'^include "qelib1.inc";$'
        pattern_qreg = r'^qreg q\[\d+\];$'
        pattern_creg = r'^creg c\[\d+\];$'

        #  定义其他门正则化表达式模式
        #  ^抓取开头,$抓取结尾,*重复多次

        pattern_gate = r"gate\s+(\w+)\s+(\w+)\s*\{((?:\s*(t|s)\s+\w+;\s*)+)\}"
        pattern_func_name = r"(\w+)\s+(\w+) q\[\d+\];$"

        pattern_paras = r'^(ry|rz|rx|p|rydg|rzdg|rxdg|pdg)\([0-9pi+\-*/.]+\)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_u1paras = r'^(u1dg|u1)\([0-9pi+\-*/.]+\)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_u2paras = r'^(u2dg|u2)\([0-9pi+\-*/.]+\,[0-9pi+\-*/.]+\)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_u3paras = r'^(u3dg|u3)\([0-9pi+\-*/.]+\,[0-9pi+\-*/.]+\,[0-9pi+\-*/.]+\)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_one = r'^(h|t|s|x|y|z|barrier|reset|tdg|sdg|hdg|xdg|ydg|zdg)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_two = r'^(cx|cnot|cz|swap|cxdg|cnotdg|czdg|swapdg|izz|izzdg)\s(q\[\d+\]\,)*q\[\d+\];$'
        pattern_three = r'^(ccx|toffoli|ccxdg|toffolidg)\s(q\[\d+\]\,)*q\[\d+\];$'
        # pattern_control = r'^(CONTROL)\s(q\[\d+\]\,)*q\[\d+\];$'
        # pattern_dagger = r'^(dagger|enddagger|endcnotrol);$'
        pattern_measure = r'^(measure)\s+q\[\d+\]\s*->\s*c\[\d+\];$'

        input_split = qasm.split("\n")
        # 改为从第四行开始校验其他门
        # input_split = lines[4:]

        # Validate the initial lines
        if not re.match(pattern_openqasm, input_split[0]):
            raise ValueError("The first line must be 'OPENQASM 2.0;'")
        if not re.match(pattern_include, input_split[1]):
            raise ValueError("The second line must be 'include \"qelib1.inc\";'")

        gate_end = 2
        if input_split[2][:4] == "gate": #?这个条件往下不太理解是干嘛的
            sub_pattern_paras = r'^(ry|rz|rx|p|rydg|rzdg|rxdg|pdg)\([0-9pi+\-*/.]+\)\s+[a-zA-Z]+(?:\s*,[a-zA-Z]+){0,};$'
            sub_pattern_u1paras = r'^(u1dg|u1)\([0-9pi+\-*/.]+\)\s+[a-zA-Z]+(?:\s*,[a-zA-Z]+){0,};$'
            sub_pattern_u2paras = r'^(u2dg|u2)\([0-9pi+\-*/.]+\,[0-9pi+\-*/.]+\)\s+[a-zA-Z]+(?:\s*,[a-zA-Z]+){0,};$'
            sub_pattern_u3paras = r'^(u3dg|u3)\([0-9pi+\-*/.]+\,[0-9pi+\-*/.]+\,[0-9pi+\-*/.]+\)\s+[a-zA-Z]+(?:\s*,[a-zA-Z]+){0,};$'
            sub_pattern_one = r'^(h|t|s|x|y|z|barrier|tdg|sdg|hdg|xdg|ydg|zdg|)\s+[a-zA-Z]+(?:\s*,[a-zA-Z]+){0,};$'
            sub_pattern_two = r'^(cx|cnot|cz|swap|cxdg|cnotdg|czdg|swapdg|izz|izzdg)\s+[a-zA-Z]+(?:\s*,[a-zA-Z]+){0,};$'
            sub_pattern_three = r'^(ccx|toffoli|ccxdg|toffolidg)\s+[a-zA-Z]+(?:\s*,[a-zA-Z]+){0,};$'

            pattern_gate2 = r'^[A-Za-z][A-Za-z0-9_]{0,30}[A-Za-z0-9]$'
            pattern_gate3 = r'^[a-zA-Z]+(?:\s*,[a-zA-Z]+){0,}$'

            gate_name = {}
            for i in range(3,len(input_split)):
                if input_split[i][:4] == "qreg":
                    gate_end = i
                    break

            com_gate = input_split[2:gate_end]

            boundary = 0
            for gate in com_gate:
                #校验门信息
                if gate.startswith("gate"):
                    _,name,paras = gate.split(" ")
                    # pattern_gate2 由大小写字母、数字、下划线组成，以字母开头，字母或数字结尾，长度限制2-10个字符，不可与其他量子门重名
                    # pattern_gate3 字母，字母，字母
                    if re.match(pattern_gate2, name) and re.match(pattern_gate3, paras):
                        paras = paras.split(",")
                        gate_name[name] = paras
                        gate_name[name+"dg"] = paras
                    else:
                        raise ValueError("Combination gate verification failed")

                # 校验括号
                elif gate == "{" or gate == "}":
                    if gate == "{" and boundary == 0:
                        boundary = 1
                    elif gate == "}" and boundary == 1:
                        boundary = 0
                    elif (gate == "}" and boundary ==0) or (gate == "{" and boundary == 1):
                        raise ValueError("After {, it should be }")

                elif re.match(sub_pattern_paras, gate) or re.match(sub_pattern_u1paras, gate) \
                    or re.match(sub_pattern_u2paras, gate) or re.match(sub_pattern_u3paras, gate) \
                    or re.match(sub_pattern_one, gate) or re.match(sub_pattern_two, gate) \
                    or re.match(sub_pattern_three, gate):
                    pass
                else:
                    raise ValueError("Combination gate verification failed")
            gate_name_keys = gate_name.keys()
            gate_name_str = "|".join(gate_name_keys)
            pattern_user_gate = rf'^({gate_name_str})\s(q\[\d+\]\,)*q\[\d+\];$'
        else:
            pattern_user_gate = "  "
            gate_name = {}
        # print('pattern_user_gate',pattern_user_gate)
        if not re.match(pattern_qreg, input_split[gate_end]):
            raise ValueError("The third line must be 'qreg q[n];'")
        if not re.match(pattern_creg, input_split[gate_end+1]):
            raise ValueError("The fourth line must be 'creg c[n];'")

        dagger_tage = 0
        control_tag = 0

        # 改为从第四行开始校验其他门
        # print('input_split[gate_end+2:]',input_split[gate_end+2:])
        for gate in input_split[gate_end+2:]:
            # print('gate',gate)
            if re.match(pattern_paras, gate) or re.match(pattern_one, gate) \
                    or re.match(pattern_two, gate) or re.match(pattern_u1paras, gate) \
                    or re.match(pattern_u2paras, gate) or re.match(pattern_u3paras, gate) \
                    or re.match(pattern_three, gate) or re.match(pattern_measure, gate):
                pass
            elif re.match(pattern_user_gate, gate): #跟上面不理解的条件有关if input_split[2][:4] == "gate":
                # print('进这里') #进不去因为输入多加了空格
                name,qubits = gate.split(" ")
                qubit = qubits.split(",")
                if len(qubit) != len(gate_name[name]):
                    raise ValueError("The number of qubits in quantum gates is inconsistent")

            # elif re.match(pattern_control, gate):
            #     print('gate1', gate)
            #     gate_name, bits = gate.split(" ")
            #     if gate_name == "CONTROL" and control_tag == 0:
            #         control_tag = 1
            #     elif gate_name == "CONTROL" and control_tag == 1:
            #         raise ValueError("After CONTROL, it should be ENDCONTROL")
            #     print('gate_name,control_tag', gate_name,control_tag)
            else:
                raise ValueError("The input format is incorrect")

        # if dagger_tage != 0 or control_tag != 0:
        #     raise ValueError("DAGGER and ENDDAGGER/CONTROL and ENDCONTROL need to match")



    def __insert_noise(self,operation,target, *args, **kwargs):
        if len(target) > 1:
            pos1 = min(target)
            pos2 = max(target)
            self.qreg[pos1].append(operation(target, *args, **kwargs))
            for i in range(pos1 + 1, pos2 + 1):
                self.qreg[i].append("ctrl")
            maxlayer = max([len(self.qreg[j]) for j in range(pos1, pos2 + 1)])
            for k in range(pos1, pos2 + 1):
                layeri = len(self.qreg[k])
                pos = layeri - 1
                if layeri != maxlayer:
                    for i in range(abs(layeri - maxlayer)):
                        self.qreg[k].insert(pos, None)
        else:
            self.qreg[target[0]].append(operation(target, *args, **kwargs))


    def __insert_qubit(self, gate, target, control, paras, dagger):
        """Inserting quantum registers according to single bit and multi bit quantum gate classification"""
        if len(target)>1 or (len(target)==1 and control):
            if control:
                pos1 = min(min(control),min(target))
                pos2 = max(max(control),max(target))
            else:
                pos1 = min(target)
                pos2 = max(target)
            self.__insert(pos1, gate, target, control, paras, dagger)
            for i in range(pos1+1,pos2+1):
                self.qreg[i].append("ctrl")
            maxlayer = max([len(self.qreg[j]) for j in range(pos1, pos2 + 1)])
            for k in range(pos1, pos2+1):
                layeri = len(self.qreg[k])
                pos = layeri-1
                if layeri != maxlayer:
                    for i in range(abs(layeri - maxlayer)):
                        self.qreg[k].insert(pos, None)
        elif len(target)==1 and not control:
            self.__insert(max(target), gate, target, control, paras, dagger)

    def __insert(self, pos1, gate, target, control, paras, dagger):
        """Inserting quantum gates into quantum registers"""
        if paras is not None:
            for para in paras:
                if isinstance(para,Parameters) and para not in self._use_parameters:
                    self._use_parameters.append(para)
            insert_gate = gate(target=target, ctrl=control, paras=paras, dagger=dagger)
            if insert_gate.batch_size is not None:
                try:
                    self.set_batch(batch_size=insert_gate.batch_size)
                except ValueError:
                    raise ValueError(f"{insert_gate.name} batch_size is inconsistent with the previously batch_size")
            self.qreg[pos1].append(insert_gate)
        else:
            self.qreg[pos1].append(gate(target=target, ctrl=control, dagger=dagger))

    def all_add(self,operate,*args,**kwargs):
        """
        Apply quantum gates to all bits of quantum circuits,only supports single bit gates.

        Args:
            gate (Basicgate): The quantum gate you want to apply
            paras (list): Parameters of quantum gates
            dagger (bool): Whether to perform Hermitian conjugation on quantum

        Raises:
            TypeError: If 'quantum gate' is not a single bit gates.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit,cbit)
            q.all_add(H)
            q.all_add(X)
            q.draw()
            q0   ―――――――H――――――――――――――X―――――――

            q1   ―――――――H――――――――――――――X―――――――

            c    ――――――――――――――――――――――――――――――
            """

        if operate == MEASURE:
            for i in range(self.qubits):
                self.add(operate,target=self.qreg[i],cbit=self.creg[i])
        elif operate == BARRIER:
            for i in range(self.qubits):
                self.add(operate,target=self.qreg[i])
        # change
        elif operate == RESET:
            for i in range(self.qubits):
                self.add(operate,target=self.qreg[i])
        elif operate in [H,X,Y,Z,S,T,]:
            for i in range(self.qubits):
                self.add(operate, target=self.qreg[i],*args, **kwargs)
        elif operate in [RX,RY,RZ,P,U1,U2,U3]:
            for i in range(self.qubits):
                self.add(operate,target=self.qreg[i],*args, **kwargs)
        elif operate in self.noise_list and operate not in [TwoQubitDepolarizing,TwoQubitDephasing]:
            for i in range(self.qubits):
                self.add(operate, self.qreg[i],*args, **kwargs)
        else:
            raise TypeError("all_add only support one bit gate")

    def dagger(self):
        """Obtaining Conjugate transpose of Quantum circuit
        Raises:
            TypeError: If 'quantum gate' is measure gate.

        Returns:
            circuit (Quantumcircuit): Conjugate transpose of Quantum circuit

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            q.add(H,qubit[0])
            q.add(RX,qubit[0],paras=[pi/2])
            q.add(Y,qubit[1])
            q.add(CNOT,qubit[1],qubit[0])
            q.draw()
            q0   ―――――――H――――――――――RX(1.571)――――――――――●―――――――
                                                      ┃
            q1   ―――――――Y――――――――――――――――――――――――――――CNOT―――――

            c    ―――――――――――――――――――――――――――――――――――――――――――――
            q.dagger()
            q.draw()
            q0   ―――――――●――――――――――RX†(1.571)―――――――――H―――――――
                        ┃
            q1   ――――――CNOT―――――――――――――――――――――――――――Y―――――――

            c    ―――――――――――――――――――――――――――――――――――――――――――――
        """
        # 首先self.qubits从第二列开始翻转，其次每个gate都做dagger
        self.symbol_dagger = False if self.symbol_dagger else True
        use_bit = []
        for i in range(self.qubits):
            if len(self.qreg[i]) != 0:
                use_bit.append(i)
        # 将self.qubits转换成n行m列形式
        maxdepth = max([len(self.qreg[i]) for i in use_bit])
        for i in use_bit:
            self.qreg[i].extend([None] * (maxdepth - len(self.qreg[i])))
        # 翻转
        for i in range(self.qubits):
            self.qreg[i].reverse()
            # dagger
            for j in self.qreg[i]:
                if isinstance(j,Basicgate) and not isinstance(j,MEASURE):
                    j._dagger()
                elif isinstance(j,int) or isinstance(j,str) or j==None or isinstance(j,(BARRIER, RESET)):
                    continue
                else:
                    raise TypeError("unsupported measure gate")
        return self

    #todo
    #假设batch随着门改变啊而改变
    def set_batch(self,batch_size):
        if not isinstance(batch_size,int) or batch_size <= 0:
            raise ValueError("batch_size must be a positive integer")

        if self.batch_size is None :
            self.batch_size = batch_size
        else:
            if self.batch_size != batch_size:
                raise ValueError("batch_size is inconsistent with the previously batch_size")

    def get_tempgates(self):
        """Import the quantum gates of the Quantum circuit into the temp_gates list in turn

        returns:
            conver (numpy.array):  Convert to numpy form quantum register for reading quantum gates in columns

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(3)
            cbit = ClassicalRegister(3)
            q = QuantumCircuit(qubit,cbit)
            q.mul_add(H,qubit[0,1,2])
            q.mul_add(CNOT,qubit[1,2],qubit[0,1])
            q.get_tempgates()
            print(q.temp_gates)
            [H, H, H, CNOT, CNOT]
        """
        # 获取self.temp_gates，所有门按顺序依次导入到列表内
        self.temp_gates = []
        self.temp_qreg = copy.deepcopy(self.qreg)
        # qreg = copy.deepcopy()
        maxdepth = max([len(self.temp_qreg[i]) for i in range(self.qubits)])
        for i in self.temp_qreg:
            i.extend([None] * (maxdepth - len(i)))
        conver = np.array(self.temp_qreg)
        for i in range(conver.shape[1]):
            gate_col = conver[:, i]
            for operate in gate_col:
                if isinstance(operate, Basicgate):
                    self.temp_gates.append(operate)
                elif isinstance(operate,(BARRIER, RESET)):
                    self.temp_gates.append(operate)
                elif isinstance(operate,KrausOperation):
                    self.temp_gates.append(operate)
        return conver

    def from_qasm(self, qasm: str):
        """Constructing Quantum circuit from quantum QASM code
        Raises:
            TypeError: If 'quantum gate' is not a reasonable quantum gate.

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            qasm_code = ""OPENQASM 2.0;
            include "qelib1.inc";
            qreg q[2];
            creg c[2];
            h q[0];
            h q[1];
            cx q[1],q[0];""
            q.from_qasm(qasm_code)
            q.draw()
            q0   ―――――――H――――――――――――――CX――――――
                                                    ┃
            q1   ―――――――H――――――――――――――●―――――――

            c    ――――――――――――――――――――――――――――――
            """
        if "\r" in qasm:
            qasm = qasm.replace("\r","")
        self.__check_qasm(qasm)
        input_split = qasm.split("\n")

        if not (input_split[0] == "OPENQASM 2.0;" and input_split[1] == 'include "qelib1.inc";'):
            raise ValueError("Incorrect prefix for QASM") #感觉这个不需要了 在__check_qasm(qasm)足够了

        gate_end = 2
        com_gate_dict = {}
        # 处理组合门逻辑部分
        if input_split[2][:4] == "gate":
            com_gate = []
            for i in range(3,len(input_split)):
                if input_split[i] == "{":
                    start = i
                if input_split[i] == "}":
                    com_gate.append(input_split[start-1:i+1])
                if input_split[i][:4] == "qreg":
                    gate_end = i
                    break
            # 解析组合门中的信息
            for gate in com_gate:
                name_paras = gate[0].split(" ")
                fun_name = name_paras[1]
                fun_paras = name_paras[2]
                fun_paras = fun_paras.split(",")
                fun_body_list = gate[2:-1]
                fun_body = []
                for sub_gate in fun_body_list:
                    if sub_gate == "":
                        continue #这里
                    sub_gate = sub_gate.replace(";","")
                    sub_gate_split = sub_gate.split(" ")
                    # paras
                    if "(" in sub_gate_split[0]:
                        sub_command, sub_paras = sub_gate_split[0].split("(")
                        sub_paras = sub_paras.strip(")")
                        sub_paras = eval(sub_paras, {"pi": np.pi})
                        if isinstance(sub_paras, tuple):
                            sub_paras = list(sub_paras)
                        else:
                            sub_paras = [sub_paras]
                    else:
                        sub_paras = None
                        sub_command = sub_gate_split[0]

                    if sub_command[0] == "c" and sub_command != "ccx" and sub_command != "cx" and sub_command != "cnot":
                        sub_command = sub_command[1:]

                    dagger_dg = 'dg'
                    if sub_command.find(dagger_dg) != -1:
                        sub_command = sub_command.strip(dagger_dg)
                        sub_dagger_flag = True
                    else:
                        sub_dagger_flag = False

                    sub_command = sub_command.upper()

                    if sub_command == "BARRIER":
                        data = [sub_command, sub_gate_split[1]]
                    elif sub_command == "RESET":
                        data = [sub_command, sub_gate_split[1]]

                    elif sub_command == "SWAP" or sub_command=="IZZ":
                        sub_target = sub_gate_split[1].split(",")

                        if len(sub_target) > 2:
                            sub_control = sub_target[:-2]
                            sub_target = sub_target[-2:]
                            sub_control = ",".join(sub_control)
                            sub_target = ",".join(sub_target)
                            data = [sub_command, sub_target, sub_control, sub_paras, sub_dagger_flag]
                        else:
                            sub_target = ",".join(sub_target)
                            data = [sub_command, sub_target, None, sub_paras, sub_dagger_flag]

                    else:
                        sub_target = sub_gate_split[1].split(",")
                        if len(sub_target) > 1:
                            sub_control = sub_target[:-1]
                            sub_target = [sub_target[-1]]
                            sub_control = ",".join(sub_control)
                            sub_target = ",".join(sub_target)
                            data = [sub_command, sub_target, sub_control, sub_paras, sub_dagger_flag]
                        else:
                            sub_target = ",".join(sub_target)
                            data = [sub_command, sub_target, None, sub_paras, sub_dagger_flag]
                    fun_body.append(data)
                com_gate_dict[fun_name] = [fun_name, fun_paras, fun_body]

        # 正常执行其他命令
        qubits = re.findall("\d+", input_split[gate_end])
        cbits = re.findall("\d+", input_split[gate_end+1])
        if int(qubits[0]) > self.qubits or int(cbits[0]) > self.cbits:
            raise ValueError("QASM' bits is greater than the circuit' bits")

        input_split = input_split[gate_end+2:]
        for gate in input_split:
            ctrl_tag = False
            if gate == "":
                continue
            gate_split = gate.split(" ")
            # paras
            if "(" in gate_split[0]:
                command, paras = gate_split[0].split("(")
                paras = paras.strip(")")
                paras = eval(paras, {"pi": np.pi})
                if isinstance(paras, tuple):
                    paras = list(paras)
                else:
                    paras = [paras]
            else:
                paras = None
                command = gate_split[0]

            if command[0] == "c" and command != "ccx" and command != "cx" and command != "cnot":
                command = command[1:]
                ctrl_tag = True

            dagger_dg = 'dg'
            if command.find(dagger_dg) != -1:
                command = command.replace(dagger_dg,"")
                # command = command.strip(dagger_dg)
                dagger_flag = True
            else:
                dagger_flag = False

            if command == "measure":
                m_qubit = re.findall("\d+", gate_split[1])
                m_qubit = [int(i) for i in m_qubit]
                m_cbit = re.findall("\d+", gate_split[3])
                m_cbit = [int(i) for i in m_cbit]
                self.add(MEASURE, m_qubit, m_cbit)

            elif command == "barrier":
                target = re.findall("\d+", gate_split[1])
                target = [int(i) for i in target]
                for i in target:
                    self.add(BARRIER, [i])
            # change
            elif command == "reset":
                target = re.findall("\d+", gate_split[1])
                target = [int(i) for i in target]
                for i in target:
                    self.add(RESET, [i])

            elif command == "swap":
                target = re.findall("\d+", gate_split[1])
                target = [int(i) for i in target]

                if len(target) > 2:
                    control = target[:-2]
                    target = target[-2:]
                    self.add(SWAP, target, control, paras=paras)
                else:
                    self.add(SWAP, target)

            elif command=="izz":
                target = re.findall("\d+", gate_split[1])
                target = [int(i) for i in target]

                if len(target) > 2:
                    control = target[:-2]
                    target = target[-2:]
                    self.add(IsingZZ, target, control, paras=paras,dagger=dagger_flag)
                else:
                    self.add(IsingZZ, target, paras=paras,dagger=dagger_flag)

            else:
                if command in com_gate_dict.keys():
                    # 提取目标位置
                    target = re.findall("\d+", gate_split[1])
                    target = [int(i) for i in target]
                    # 读取组合门的内容
                    gate_data = com_gate_dict[command]
                    gate_paras = gate_data[1]
                    gate_data = gate_data[2]
                    if dagger_flag == True:
                        gate_data = copy.deepcopy(gate_data[::-1])
                    else:
                        gate_data = gate_data
                    for run_data in copy.deepcopy(gate_data):
                        # 读取组合门每条执行命令的内容
                        run_command = run_data[0]
                        run_target = run_data[1]
                        if run_command == "BARRIER":
                            for index, value in enumerate(gate_paras):
                                run_target = run_target.replace(value, str(target[index]))
                            run_target = re.findall("\d+", run_target)
                            run_target = [int(i) for i in run_target]
                            for i in run_target:
                                eval(f"self.add({run_command}, [{i}])")
                            continue
                        run_control = run_data[2]
                        run_paras = run_data[3]
                        run_dagger = run_data[4]
                        if dagger_flag == True:
                            if run_dagger == True:
                                run_dagger = False
                            else:
                                run_dagger = True
                        # 作用到线路中
                        if run_control is None:
                            for index, value in enumerate(gate_paras):
                                run_target = run_target.replace(value, str(target[index]))
                            execute_command = f"self.add({run_command}, [{run_target}], paras={run_paras}, dagger={run_dagger})"
                            eval(execute_command)
                        else:
                            for index, value in enumerate(gate_paras):
                                run_target = run_target.replace(value, str(target[index]))
                                run_control = run_control.replace(value, str(target[index]))
                            execute_command = f"self.add({run_command}, [{run_target}], [{run_control}], paras={run_paras}, dagger={run_dagger})"
                            eval(execute_command)
                else:
                    command = eval(command.upper())
                    target = re.findall("\d+", gate_split[1])
                    target = [int(i) for i in target]
                    if len(target) > 1:
                        control = target[:-1]
                        target = [target[-1]]
                        self.add(command, target, control, paras=paras, dagger=dagger_flag)
                    else:
                        self.add(command, target, paras=paras, dagger=dagger_flag)


    # def QIR(self):
    #     """Convert Quantum circuit into quantum QIR code
    #
    #     Args:
    #         addr (str): Quantum QIR code storage address
    #
    #     Raises:
    #         TypeError: If the address is not a string
    #         ValueError: If the address does not endwith '.txt'
    #
    #     returns:
    #         result (str): Quantum QIR code
    #
    #     Examples:
    #         from wuyue.circuit import QuantumCircuit
    #         from register.classicalregister import ClassicalRegister
    #         from register.quantumregister import QuantumRegister
    #         from element.gate import *
    #         qubit = QuantumRegister(3)
    #         cbit = ClassicalRegister(3)
    #         q = QuantumCircuit(qubit, cbit)
    #         q.add(RX,qubit[0],qubit[1],paras=[np.pi/2])
    #         q.add(H, qubit[0], qubit[1])
    #         q.mul_add(CNOT, qubit[1, 2], qubit[0, 1])
    #         q.add(H, qubit[0]).add(H, qubit[1]).add(X, qubit[0]).add(X, qubit[1])
    #         q.add(CCX, qubit[0], qubit[1,2])
    #         q.add(SWAP, qubit[0,1],qubit[2])
    #         q.all_add(MEASURE)
    #         #q.draw()
    #         print(q.QIR())
    #         CONTROL q[1]
    #         RX q[0],(1.571)
    #         ENDCONTROL
    #         CONTROL q[1]
    #         H q[0]
    #         ENDCONTROL
    #         CNOT q[0],q[1]
    #         CNOT q[1],q[2]
    #         CCX q[1],q[2],q[0]
    #         CONTROL q[2]
    #         SWAP q[0],q[1]
    #         ENDCONTROL
    #         MEASURE q[0],c[0]
    #         MEASURE q[1],c[1]
    #         MEASURE q[2],c[2]
    #     """
    #
    #     # QIR prefix
    #
    #     result = ""
    #     for gate in self.temp_gates:
    #         if isinstance(gate,BARRIER):
    #             symbol = "BARRIER q[%s]"%gate.target
    #             symbol += "\n"
    #             result += symbol
    #             continue
    #
    #         if isinstance(gate,RESET): # change
    #             symbol = r'$|0\rangle$' + "q[%s]"%gate.target[0]
    #             symbol += "\n"
    #             result += symbol
    #             continue
    #
    #         if gate.name == "MEASURE":
    #             str1 = "MEASURE" + " q[%d],c[%d]\n" % (gate.target[0], gate.cbit[0])
    #             result += str1
    #             continue
    #
    #         if gate.dagger == True:
    #             result += 'DAGGER\n'
    #
    #         if gate.name == "NEW":
    #             raise ValueError("QIR does not support usergate")
    #
    #         # 含参门输出
    #         if isinstance(gate,Parasgate):
    #             if gate.name == "U1" or gate.name == "U2" or gate.name == "U3":
    #                 raise ValueError(
    #                     f"QIR does not support {gate.name}")
    #             symbol = gate.name.upper()+ " q[%s]," % gate.target[0] + "(" + ",".join(["%.3f"%i for i in gate.paras]) + ")"
    #
    #         # 不含参门输出
    #         else:
    #             symbol = gate.name.upper()+ " q[%s]" % gate.target[0]
    #
    #         if gate.ctrl:
    #             pos = gate.ctrl + gate.target
    #
    #             # print(pos)
    #             if symbol[0]!="C" and gate.symbol != "TOFFOLI":
    #                 output = 'CONTROL'+ " " + ",".join(["q[%s]"%i for i in gate.ctrl]) + "\n"
    #                 if gate.name == "SWAP":
    #                     symbol = gate.name + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
    #                 elif gate.name == "IZZ":
    #                     symbol = (gate.name + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
    #                               + "(" + ",".join(["%.3f"%i for i in gate.paras]) + ")")
    #                 output += symbol + '\n'
    #                 result += output
    #                 result += 'ENDCONTROL\n'
    #             else:
    #                 result += gate.symbol +" " + ",".join(["q[%s]" % i for i in pos]) + "\n"
    #
    #         else:
    #             if gate.name == "SWAP":
    #                 symbol = gate.name + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
    #                 result += symbol + '\n'
    #             elif gate.name == "IZZ":
    #                 symbol = (gate.name + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
    #                           + "(" + ",".join(["%.3f" % i for i in gate.paras]) + ")")
    #                 result += symbol + '\n'
    #             else:
    #                 result += (symbol+"\n")
    #
    #         #单独与前gate.dagger进行判断
    #         if gate.dagger == True:
    #             result += 'ENDDAGGER\n'
    #
    #     # The final output is judged, and the logic layer is the same level as the beginning
    #     if result.endswith("\n"):
    #         result = result.rstrip("\n")
    #     return result
    #
    # def to_pseudecode(self):
    #     """Convert Quantum circuit into quantum pseude code
    #
    #     Args:
    #         addr (str): Quantum pseude code storage address
    #
    #     Raises:
    #         TypeError: If the address is not a string
    #         ValueError: If the address does not endwith '.txt'
    #
    #     returns:
    #         result (str): Quantum pseude code
    #
    #     Examples:
    #         from wuyue.circuit import QuantumCircuit
    #         from wuyue.register.classicalregister import ClassicalRegister
    #         from wuyue.register.quantumregister import QuantumRegister
    #         from wuyue.element.gate import *
    #         qubit = QuantumRegister(3)
    #         cbit = ClassicalRegister(3)
    #         q = QuantumCircuit(qubit, cbit)
    #         q.add(P, qubit[0], qubit[1,2],paras=[np.pi/2],dagger=True)
    #         q.add(RX, qubit[0], qubit[1,2],paras=[np.pi/2],dagger=True)
    #         q.add(RY, qubit[0], qubit[1,2],paras=[np.pi/2],dagger=True)
    #         q.add(H, qubit[0], qubit[1,2])
    #         q.mul_add(CNOT, qubit[1,2], qubit[0,1])
    #         q.add(H, qubit[0]).add(H, qubit[1]).add(X, qubit[0]).add(X, qubit[1])
    #         q.add(CCX, qubit[0], qubit[1,2])
    #         q.add(TOFFOLI, qubit[0], qubit[1,2])
    #         q.add(SWAP, qubit[0,1],qubit[2])
    #         q.all_add(MEASURE)
    #         print(q.to_pseudecode())
    #         DAGGER
    #         P(1.571) q[1],q[2],q[0]
    #         ENDDAGGER
    #         DAGGER
    #         RX(1.571) q[1],q[2],q[0]
    #         ENDDAGGER
    #         DAGGER
    #         RY(1.571) q[1],q[2],q[0]
    #         ENDDAGGER
    #         H q[1],q[2],q[0]
    #         CNOT q[0],q[1]
    #         H q[0]
    #         CNOT q[1],q[2]
    #         X q[0]
    #         H q[1]
    #         X q[1]
    #         CCX q[1],q[2],q[0]
    #         CCX q[1],q[2],q[0]
    #         SWAP q[2],q[0],q[1]
    #         MEASURE q[0],c[0]
    #         MEASURE q[1],c[1]
    #         MEASURE q[2],c[2]
    #     """
    #     # pseudecode prefix
    #     self.get_tempgates()
    #     result = ""
    #     # Print door information in sequence
    #     for gate in self.temp_gates:
    #         if isinstance(gate, BARRIER):
    #             symbol = "BARRIER q[%s]" % gate.target
    #             symbol += "\n"
    #             result += symbol
    #             continue
    #
    #         if gate.name == "MEASURE":
    #             str1 = "MEASURE" + " q[%d],c[%d]\n" % (gate.target[0], gate.cbit[0])
    #             result += str1
    #             continue
    #
    #         if gate.name == "TOFFOLI":
    #             str1 = 'CCX' + " " + ",".join(["q[%s]" % i for i in gate.ctrl]) + \
    #                       ",q[%s]" % (gate.target[0]) + "\n"
    #             result += str1
    #             continue
    #
    #         if gate.name == "CX":
    #             str1 = 'CNOT' + " " + ",".join(["q[%s]" % i for i in gate.ctrl]) + \
    #                       ",q[%s]" % (gate.target[0]) + "\n"
    #             result += str1
    #             continue
    #
    #         if gate.dagger == True:
    #             result += 'DAGGER\n'
    #
    #         if gate.name == "NEW":
    #             raise ValueError("QIR does not support usergate")
    #
    #         # 含参门输出
    #         if isinstance(gate, Parasgate):
    #             if gate.name == "U1" or gate.name == "U2" or gate.name == "U3":
    #                 raise ValueError(
    #                     f"QIR does not support {gate.name}")
    #             symbol = gate.name.upper() + "(" + ",".join(["%.3f" % i for i in gate.paras]) + ")" \
    #                      + " q[%s]" % gate.target[0]
    #
    #         # 不含参门输出
    #         else:
    #             symbol = gate.name.upper() + " q[%s]" % gate.target[0]
    #
    #         if gate.ctrl:
    #             pos = gate.ctrl + gate.target
    #             if symbol[0] != "C":
    #                 output =  ",".join(["q[%s]" % i for i in gate.ctrl])
    #                 output =  symbol.replace(" q[%s]" % gate.target[0], "") + " " + output
    #                 if gate.name == "SWAP":
    #                     output += ",q[%s],q[%s]" % (gate.target[0], gate.target[1]) + '\n'
    #                 elif gate.name == "IZZ":
    #                     output += (",q[%s],q[%s]" % (gate.target[0], gate.target[1])
    #                                + "(" + ",".join(["%.3f" % i for i in gate.paras]) + ")" + '\n')
    #                 else:
    #                     output += ",q[%s]" % gate.target[0] + '\n'
    #                 result += output
    #
    #             else:
    #                 result += gate.symbol + " " + ",".join(["q[%s]" % i for i in pos]) + "\n"
    #         else:
    #             if gate.name == "SWAP":
    #                 symbol = gate.name + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
    #                 result += symbol + '\n'
    #             elif gate.name == "IZZ":
    #                 symbol = (gate.name + ",q[%s],q[%s]" % (gate.target[0], gate.target[1])
    #                           + "(" + ",".join(["%.3f" % i for i in gate.paras]) + ")")
    #                 result += symbol + '\n'
    #             else:
    #                 # str1 = symbol + " q[%s]" % gate.target[0]
    #                 str1 = symbol
    #                 result += (str1+"\n")
    #
    #         # 单独与前gate.dagger进行判断
    #         if gate.dagger == True:
    #             result += 'ENDDAGGER\n'
    #
    #     # The final output is judged, and the logic layer is the same level as the beginning
    #     if result.endswith("\n"):
    #         result = result.rstrip("\n")
    #
    #     return result

    def get_gate_seq(self):
        self.gate_seq = []
        conver = self.get_tempgates()
        for i in range(conver.shape[1]):
            gate_col = conver[:, i]
            self.gate_seq.append([])
            for j in range(len(gate_col)):
                if isinstance(gate_col[j], Basicgate):
                    self.gate_seq[i].append(gate_col[j])
        return self.gate_seq

    def QASM(self, addr=None, decompose=False):
        """Convert Quantum circuit into quantum QASM code

        Args:
            addr (str): Quantum QASM code storage address

        Raises:
            TypeError: If the address is not a string
            ValueError: If the address does not endwith '.txt'

        returns:
            result (str): Quantum QASM code

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            q.all_add(H)
            q.add(CX,qubit[0],qubit[1])
            print(q.QASM())
            'OPENQASM 2.0;
            include "qelib1.inc";
            qreg q[2];
            creg c[2];
            h q[0];
            h q[1];
            cx q[1],q[0];'
        """

        self.get_tempgates()

        # QASM prefix
        result = ""
        result += "OPENQASM 2.0\n"
        result += 'include "qelib1.inc"\n'
        result += f"qreg q[{str(self.qubits)}]\n"
        result += f"creg c[{str(self.cbits)}]\n"

        # Print door information in sequence
        for gate in self.temp_gates:
            if isinstance(gate, BARRIER):
                symbol = "barrier q[%s]" % gate.target[0]
                symbol += "\n"
                result += symbol
                continue

            # if isinstance(gate, RESET):
            #     raise ValueError("QASM can not support reset")
            elif isinstance(gate, RESET):
                symbol = r'reset' + " q[%s]" % gate.target[0]
                symbol += "\n"
                result += symbol
                continue

            if gate.name == "MEASURE":
                str1 = "measure" + " q[%d] -> c[%d]\n" % (gate.target[0], gate.cbit[0])
                result += str1
                continue

            if decompose: #分解？干嘛用的
                if isinstance(gate, Basicgate):
                    symbol = resolve(gate)
                    result += symbol
                    continue

            if gate.name == "NEW":
                raise ValueError(
                    "QASM does not support usergate,if usergate can be decomposed, please set parameter decompose to true")

            #判断是否有dagger，有dagger
            if gate.dagger == True:
                # 含参门U1门、U2门、U3门、RX门、RY门、RZ门、P门输出
                if isinstance(gate, Parasgate):
                    if gate.batch_size == None:
                        symbol = gate.name.lower() + "dg" + "(" + ",".join(
                            ["%.3f" % i._value if isinstance(i,autograd.numpy.numpy_boxes.ArrayBox) else "%.3f" % i for i in gate.paras]) + ")" + " q[%s]" % gate.target[0]
                    else:
                        # 多batchsize的情况理应产出不了QASM
                        raise ValueError(f"{gate.name} batch_size is not None")

                # 不含参门H门、X门、Y门、Z门、T门、S门、CX门、CZ门、CCX门、SWAP门输出
                else:
                    symbol = gate.name.lower() + "dg" + " q[%s]" % gate.target[0]

                if gate.ctrl:
                    # pos = gate.ctrl + gate.target
                    if symbol[0] != "C" and symbol != "TOFFOLI":
                        output = ",".join(["q[%s]" % i for i in gate.ctrl])
                        output = symbol.replace(" q[%s]" % gate.target[0], "") + " " + output

                        if gate.name == "SWAP":
                            output += " q[%s],q[%s]" % (gate.target[0], gate.target[1]) + '\n'
                        elif gate.name == "IZZ":
                            output += ",q[%s]" % (gate.target[1]) + '\n'
                        else:
                            output += ",q[%s]" % gate.target[0] + '\n'

                        result += output

                else:
                    if gate.name == "SWAP":
                        symbol = gate.name.lower() + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
                        result += symbol + '\n'
                    elif gate.name == "IZZ":
                        symbol += ",q[%s]" % (gate.target[1])
                        result += symbol + '\n'
                    else:
                        # str1 = symbol + " q[%s]" % gate.target[0]
                        str1 = symbol.lower()
                        result += (str1 + "\n")

            else:

                if isinstance(gate, Parasgate):
                    if gate.batch_size == None:
                        symbol = gate.name.lower() + "(" + ",".join(
                            ["%.3f" % i._value if isinstance(i,autograd.numpy.numpy_boxes.ArrayBox) else "%.3f" % i for i in gate.paras]) + ")" + " q[%s]" % gate.target[0]
                    else:
                        # 多batchsize的情况理应产出不了QASM
                        raise ValueError(f"{gate.name} batch_size is not None")
                        # # 多batchsize的情况可以输出QASM
                        # symbol = gate.name.lower() + "(" + ",".join(
                        #     ["batch"]) + ")" + " q[%s]" % gate.target[0]
                else:
                    symbol = gate.name.lower() + " q[%s]" % gate.target[0]

                if gate.ctrl:
                    pos = gate.ctrl + gate.target
                    if symbol[0] != "C" and symbol != "TOFFOLI":
                        # 有几个控制位都能进行控制
                        output = ",".join(["q[%s]" % i for i in gate.ctrl])
                        output = symbol.replace(" q[%s]" % gate.target[0], "") + " " + output

                        if gate.name == "SWAP":
                            output += " q[%s],q[%s]" % (gate.target[0], gate.target[1]) + '\n'
                        elif gate.name == "IZZ":
                            output += ",q[%s]" % (gate.target[1])+ '\n'
                        else:
                            output += ",q[%s]" % gate.target[0] + '\n'

                        result += output

                    else:
                        result += gate.symbol + " " + ",".join(["q[%s]" % i for i in pos]) + "\n"

                else:
                    if gate.name == "SWAP":
                        symbol = gate.name.lower() + " q[%s],q[%s]" % (gate.target[0], gate.target[1])
                        result += symbol + '\n'
                    elif gate.name == "IZZ":
                        symbol += ",q[%s]" % (gate.target[1])
                        result += symbol + '\n'
                    else:
                        # str1 = symbol + " q[%s]" % gate.target[0]
                        str1 = symbol.lower()
                        result += (str1 + "\n")

        # 分割每行输出
        lines = result.splitlines()
        # 添加尾缀
        result_list = [line + ';' for line in lines]

        result = '\n'.join(result_list)

        # The final output is judged, and the logic layer is the same level as the beginning
        if result.endswith("\n"):
            result = result.rstrip("\n")

        if addr is not None:
            if not isinstance(addr, str):
                raise TypeError("Address needs to be a string")
            if not addr.endswith(".txt"):
                raise ValueError("Address needs to end with'.txt'")
            # write file
            with open(addr, "w") as f:
                f.write(result)
        return result

    def draw(self):
        """Quantum circuit display

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(3)
            cbit = ClassicalRegister(3)
            q = QuantumCircuit(qubit,cbit)
            q.mul_add(H,qubit[0,1,2])
            q.mul_add(CNOT,qubit[1,2],qubit[0,1])
            q.draw()
            q0   ―――――――H――――――――――――――●――――――――――――――――――――
                                                    ┃
            q1   ―――――――H―――――――――――――CNOT――――――――――――●―――――――
                                                                          ┃
            q2   ―――――――H―――――――――――――――――――――――――――CNOT―――――

            c    ―――――――――――――――――――――――――――――――――――――――――――
        """
        # 绘制量子线路字符画
        # 可以绘制if和while
        # U1 U2 U3 不加参数，不然长度太大
        draw_list = self.get_tempgates()
        # print(draw_list)
        draw_str = [[] for i in range(self.qubits)]
        sup_str = [[] for i in range(self.qubits)]
        for j in range(len(self.qreg)):
            draw_str[j].append(("q%d"%j).ljust(5, " "))
            sup_str[j].append("     ")
        num = 0
        for i in range(draw_list.shape[1]):
            gate_col = draw_list[:, i]
            measure = 0
            U3_tag,U2_tag = 0,0
            for temp_gate in gate_col:
                if isinstance(temp_gate,U2):
                    U2_tag = 1
                elif isinstance(temp_gate,U3):
                    U3_tag = 1
                    break
            if U3_tag == 1:
                length = 25
            elif U2_tag ==1 :
                length =20
            else:
                length=15

            for j in range(len(gate_col)):
                if isinstance(gate_col[j], Basicgate):
                    if isinstance(gate_col[j], Parasgate):
                        temp_paras = []
                        if gate_col[j].batch_size is None:
                            for paras_gate in gate_col[j].paras:
                                if not isinstance(paras_gate, Parameters):
                                    if isinstance(paras_gate, autograd.numpy.numpy_boxes.ArrayBox):
                                        temp_paras.append("%.3f" % paras_gate._value)
                                    else:
                                        temp_paras.append("%.3f" % paras_gate)
                                else:
                                    if paras_gate.value is None:
                                        temp_paras.append(f"{paras_gate.name}")
                                    else:
                                        temp_paras.append(f"{paras_gate.value:.3f}")
                        else:
                            temp_paras.append("batch")

                        symbol = gate_col[j].symbol + "(" + ",".join(temp_paras) + ")"

                    else:
                        symbol = gate_col[j].symbol
                    if gate_col[j].ctrl:
                        target = gate_col[j].target
                        control = gate_col[j].ctrl
                        pos1 = min(min(target), min(control))
                        pos2 = max(max(target), max(control))
                        for k in range(pos1,pos2+1):
                            if k in target:
                                draw_str[k].append(symbol.center(length, "-"))
                            elif k in control:
                                draw_str[k].append("●".center(length, "-"))
                            else:
                                draw_str[k].append("┃".center(length, "-"))

                            if k<pos2:
                                sup_str[k].append("┃".center(length, " "))
                            else:
                                sup_str[k].append(" ".center(length, " "))
                        num = pos2-pos1
                    else:
                        target = gate_col[j].target
                        if symbol == "(X)":
                            pos1 = min(target)
                            pos2 = max(target)
                            for k in range(pos1, pos2+1):
                                if k in target:
                                    draw_str[k].append("(X)".center(length, "-"))
                                else:
                                    draw_str[k].append("┃".center(length, "-"))
                                if k<pos2:
                                    sup_str[k].append("┃".center(length, " "))
                                else:
                                    sup_str[k].append(" ".center(length, " "))
                            num = pos2-pos1
                        elif gate_col[j].symbol == "IZZ":
                            pos1 = min(target)
                            pos2 = max(target)
                            for k in range(pos1, pos2+1):
                                if k in target:
                                    draw_str[k].append(symbol.center(length, "-"))
                                else:
                                    draw_str[k].append("┃".center(length, "-"))
                                if k<pos2:
                                    sup_str[k].append("┃".center(length, " "))
                                else:
                                    sup_str[k].append(" ".center(length, " "))
                            num = pos2-pos1
                        elif gate_col[j].name == "NEW":
                            pos1 = min(target)
                            pos2 = max(target)
                            lens = len(gate_col[j].symbol)
                            for k in range(pos1, pos2+1):
                                if k in target:
                                    draw_str[k].append(("┃%s┃"%(gate_col[j].symbol)).center(length, "-"))
                                else:
                                    draw_str[k].append(("┃%s┃"%(" "*lens)).center(length, "-"))
                                if k<pos2:
                                    sup_str[k].append(("┃%s┃"%(" "*lens)).center(length, " "))
                                else:
                                    sup_str[k].append(" ".center(length, " "))
                            num = pos2-pos1
                        elif symbol=="MEASURE":
                            c = gate_col[j].cbit[0]
                            symbol = symbol + "[%d]"%c
                            draw_str[j].append(symbol.center(15, "-"))
                            sup_str[j].append("║".center(15, " "))
                            measure = 1
                        else:
                            draw_str[j].append(symbol.center(length, "-"))
                            sup_str[j].append(" ".center(length, " "))

                elif isinstance(gate_col[j],KrausOperation):
                    if isinstance(gate_col[j],(AmplitudeDamping,GeneralizedAmplitudeDamping,PhaseDamping)):
                        if isinstance(gate_col[j],GeneralizedAmplitudeDamping):
                            paras = [gate_col[j].gamma,gate_col[j].probability]
                            symbol = gate_col[j].symbol + "(" + ",".join(
                                ["%.1f" % i for i in paras]) + ")"
                        else:
                            symbol = gate_col[j].symbol + f"({gate_col[j].gamma})"
                    elif isinstance(gate_col[j], (PauliChannel,ResetNoise)):
                        symbol = gate_col[j].symbol + "(" + ",".join(["%.1f" % i for i in gate_col[j].probability]) + ")"
                    else:
                        symbol = gate_col[j].symbol + f"({gate_col[j].probability})"
                    if isinstance(gate_col[j],(TwoQubitDepolarizing,TwoQubitDephasing)):
                        target = gate_col[j].targets
                        pos1 = min(target)
                        pos2 = max(target)
                        for k in range(pos1, pos2 + 1):
                            if k in target:
                                draw_str[k].append(symbol.center(length, "-"))
                            else:
                                draw_str[k].append("┃".center(length, "-"))
                            if k < pos2:
                                sup_str[k].append("┃".center(length, " "))
                            else:
                                sup_str[k].append(" ".center(length, " "))
                        num = pos2 - pos1
                    else:
                        draw_str[j].append(symbol.center(length, "-"))
                        sup_str[j].append(" ".center(length, " "))

                elif isinstance(gate_col[j], BARRIER):
                    draw_str[j].append("BARRIER".center(length, "-"))
                    sup_str[j].append(" ".center(length, " "))

                elif isinstance(gate_col[j], RESET):# change
                    draw_str[j].append("|0>".center(length, "-"))
                    sup_str[j].append(" ".center(length, " "))

                else:
                    if num==0:
                        if measure:
                            draw_str[j].append("║".center(length, "-"))
                            sup_str[j].append("║".center(length, " "))
                        else:
                            draw_str[j].append("-".center(length, "-"))
                            sup_str[j].append(" ".center(length, " "))
                    else:
                        num-=1
        output = ""
        for i in range(len(draw_str)):
            lens =0
            for j in draw_str[i]:
                lens += len(j)
                output += j
            output += "\n"
            for k in sup_str[i]:
                output += k
            output += "\n"
        if self.creg:
            output  += "c    "
            output += "-"*(lens-5)
        print(output)
        return output

    # 计算多个矩阵的直积
    def __multikron(self,parameter:list):
        """Calculate the direct product of multiple matrices"""
        matrix = parameter[0]
        for i in parameter[1:]:
            matrix = np.kron(matrix,i)
        return matrix

    def __enlarge_two(self,ctrl,target,matrix):
        """Unitary matrix representation of 2-bit quantum gates"""
        # 2bit量子门的酉矩阵表示
        I = np.array([[1, 0], [0, 1]], dtype=complex)
        m0 = np.array([[1, 0], [0, 0]], dtype=complex)
        m1 = np.array([[0, 0], [0, 1]], dtype=complex)
        # 理解：m0和m1为ctrl位置，I和matrix为target位置
        if ctrl>target:
            # target和ctrl相邻   U = [1,0;0,0]⊗I + [0,0;0,1]⊗matrix
            # target和ctrl不相邻 U = [1,0;0,0](⊗I⊗I...)⊗I + [0,0;0,1](⊗I⊗I...)⊗matrix
            length = ctrl-target
            for i in range(length-1):
                m0 = np.kron(m0,I)
                m1 = np.kron(m1,I)
            matrix = np.kron(m0, I)+np.kron(m1, matrix)
        else:
            # target和ctrl相邻   U = I⊗[1,0;0,0] + matrix⊗[0,0;0,1]
            # target和ctrl不相邻 U = I(⊗I⊗I...)⊗[1,0;0,0] + matrix(⊗I⊗I...)⊗[0,0;0,1]
            length = target-ctrl
            # matrix = np.kron(I,m0) + np.kron(matrix,m1)
            I1 =I
            matrix1 =matrix
            for i in range(length-1):
                I1 = np.kron(I1,I)
                matrix1 = np.kron(matrix1,I)
            matrix = np.kron(I1, m0) + np.kron(matrix1, m1)
        return matrix

    def __enlarge_three(self,ctrl,target,matrix):
        """Unitary matrix representation of 3 bit quantum gates"""
        I = np.array([[1, 0], [0, 1]], dtype=complex)
        m0 = np.array([[1, 0], [0, 0]], dtype=complex)
        m1 = np.array([[0, 0], [0, 1]], dtype=complex)
        ctrl.sort()
        # target = target[0]
        # 理解：m0和m1为ctrl位置，I和matrix为target位置
        # 可优化 将三种情况汇聚成一种 四个列表汇聚成一个
        if ctrl[0]>target:
            # target和ctrl1、ctrl2相邻,计算为ctrl * ctrl * target   U = [1,0;0,0]⊗[1,0;0,0]⊗I + [1,0;0,0]⊗[0,0;0,1]⊗I + [0,0;0,1]⊗[1,0;0,0]⊗I + [0,0;0,1]⊗[0,0;0,1]⊗matrix
            # target和ctrl1、ctrl2不相邻,计算为ctrl (*I..) * ctrl (*I..) * target U = [1,0;0,0](⊗I⊗I...)⊗[1,0;0,0](⊗I⊗I...)⊗I.....(同上)
            list1,list2,list3,list4 = [m0,m0,I],[m0,m1,I],[m1,m0,I],[m1,m1,matrix]
            length1 = ctrl[0] - target
            length2 = ctrl[1] - ctrl[0]
            for i in range(length2-1):
                list1.insert(1, I)
                list2.insert(1, I)
                list3.insert(1, I)
                list4.insert(1, I)
            for i in range(length1-1):
                list1.insert(-1, I)
                list2.insert(-1, I)
                list3.insert(-1, I)
                list4.insert(-1, I)
            matrix = self.__multikron(list1)+self.__multikron(list2)+self.__multikron(list3)+self.__multikron(list4)
        elif ctrl[1]<target:
            # target和ctrl1、ctrl2相邻,计算为target * ctrl * ctrl                 U = I⊗[1,0;0,0]⊗[1,0;0,0] + I⊗[1,0;0,0]⊗[0,0;0,1] + I⊗[0,0;0,1]⊗[1,0;0,0] + matrix⊗[0,0;0,1]⊗[0,0;0,1]
            # target和ctrl1、ctrl2不相邻,计算为target * ctrl (*I..) * ctrl (*I..) U = I⊗[1,0;0,0](⊗I⊗I...)⊗[1,0;0,0](⊗I⊗I...).....(同上)
            list1,list2,list3,list4 = [I,m0,m0],[I,m0,m1],[I,m1,m0],[matrix,m1,m1]
            length1 = target - ctrl[1]
            length2 = ctrl[1] - ctrl[0]
            for i in range(length1-1):
                list1.insert(1, I)
                list2.insert(1, I)
                list3.insert(1, I)
                list4.insert(1, I)
            for i in range(length2-1):
                list1.insert(-1, I)
                list2.insert(-1, I)
                list3.insert(-1, I)
                list4.insert(-1, I)
            matrix = self.__multikron(list1)+self.__multikron(list2)+self.__multikron(list3)+self.__multikron(list4)
        else:
            # target和ctrl1、ctrl2相邻,计算为ctrl * target * ctrl                 U = [1,0;0,0]⊗I⊗[1,0;0,0] + [1,0;0,0]⊗I⊗[0,0;0,1] + [0,0;0,1]⊗I⊗[1,0;0,0] + [0,0;0,1]⊗matrix⊗[0,0;0,1]
            # target和ctrl1、ctrl2不相邻,计算为ctrl (*I..) * target * ctrl (*I..) U = I⊗[1,0;0,0](⊗I⊗I...)⊗[1,0;0,0](⊗I⊗I...).....(同上)
            list1, list2, list3, list4 = [m0, I, m0], [m0, I, m1], [m1, I, m0], [m1, matrix, m1]
            length1 = target - ctrl[0]
            length2 = ctrl[1] - target
            for i in range(length2 - 1):
                list1.insert(1, I)
                list2.insert(1, I)
                list3.insert(1, I)
                list4.insert(1, I)
            for i in range(length1 - 1):
                list1.insert(-1, I)
                list2.insert(-1, I)
                list3.insert(-1, I)
                list4.insert(-1, I)
            matrix = self.__multikron(list1) + self.__multikron(list2) + self.__multikron(list3) + self.__multikron(list4)
        return matrix

    def get_matrix(self):
        """Unitary matrix expression for computing Quantum circuit
        Raises:
            TypeError: If 'Quantum circuit' have measurement gate
            ValueError: If 'Quantum circuit' is greater than 3 bits

        returns:
            matrix (numpy.array): Unitary matrix

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            q.mul_add(H, qubit[0, 1])
            q.add(CNOT, qubit[1], qubit[0])
            q.add(X, qubit[0]).add(X, qubit[1])
            print(q.get_matrix())
            [[ 0.5+0.j -0.5+0.j  0.5+0.j -0.5+0.j]
             [ 0.5+0.j  0.5+0.j -0.5+0.j -0.5+0.j]
             [ 0.5+0.j -0.5+0.j -0.5+0.j  0.5+0.j]
             [ 0.5+0.j  0.5+0.j  0.5+0.j  0.5+0.j]]
        """
        # 1、计算每个单位的矩阵qmatrix；2、计算每列矩阵cmatrix（A、B、C...）；3、计算总的矩阵matrix（C*B*A）
        if self.batch_size is not None:
            raise ValueError("This method does not support batch sizes > 0")
        draw_list = self.get_tempgates()
        # print(draw_list)
        matrix = 0
        for i in range(draw_list.shape[1]):
            gate_col = draw_list[:, i]
            # print(gate_col)
            cmatrix = 0
            for qgate in gate_col[::-1]:
            # for qgate in gate_col:
                if isinstance(qgate,Basicgate) and not isinstance(qgate,MEASURE):
                    if qgate.matrix.shape[0]==2:
                        qmatrix = qgate.matrix
                    elif isinstance(qgate,SWAP):
                        qmatrix = np.array([[0., 1.],[1., 0.]], dtype=complex)
                        target = qgate.target[0]
                        ctrl = qgate.target[1]
                        if qgate.ctrl:
                            ctrl1,ctrl2,target = qgate.target[1],qgate.ctrl[0],qgate.target[0]
                            qmatrix1 = self.__enlarge_three([ctrl1,ctrl2], target, qmatrix)
                            ctrl1,ctrl2,target = qgate.target[0],qgate.ctrl[0],qgate.target[1]
                            qmatrix2 = self.__enlarge_three([ctrl1,ctrl2], target, qmatrix)
                            ctrl1, ctrl2, target = qgate.target[1], qgate.ctrl[0], qgate.target[0]
                            qmatrix3 = self.__enlarge_three([ctrl1,ctrl2], target, qmatrix)
                        else:
                            qmatrix1 = self.__enlarge_two(ctrl, target, qmatrix)
                            qmatrix2 = self.__enlarge_two(target, ctrl, qmatrix)
                            qmatrix3 = self.__enlarge_two(ctrl, target, qmatrix)
                        qmatrix = np.dot(np.dot(qmatrix1,qmatrix2),qmatrix3)
                    elif isinstance(qgate,IsingZZ):
                        if qgate.ctrl:
                            target = qgate.target[0]
                            ctrl = qgate.ctrl[0]
                            qmatrix = qgate.old_matrix
                            qmatrix = self.__enlarge_two(ctrl,target,qmatrix)
                        else:
                            qmatrix = qgate.matrix
                    elif qgate.matrix.shape[0]==8:
                        target = qgate.target[0]
                        ctrl = qgate.ctrl
                        qmatrix = qgate.old_matrix
                        qmatrix = self.__enlarge_three(ctrl, target, qmatrix)
                    elif qgate.matrix.shape[0]==4:
                        target = qgate.target[0]
                        ctrl = qgate.ctrl[0]
                        qmatrix = qgate.old_matrix
                        qmatrix = self.__enlarge_two(ctrl,target,qmatrix)
                    else:
                        raise ValueError("can not support >3 bits")
                elif qgate==None:
                    qmatrix = np.array([[1,0],[0,1]],dtype=complex)
                elif qgate=="ctrl"or isinstance(qgate,int) or isinstance(qgate,str):
                    continue
                else:
                    raise TypeError("unsupport measure gate")
                if isinstance(cmatrix,int):
                    cmatrix = qmatrix
                else:
                    cmatrix = np.kron(cmatrix,qmatrix)
                    # cmatrix = np.kron(qmatrix, cmatrix)
            # print(cmatrix)
            if isinstance(matrix, int):
                matrix = cmatrix
            else:
                matrix = np.dot(cmatrix,matrix)
                # matrix = np.dot(matrix,cmatrix)
            # print(matrix)
            matrix = np.around(matrix,9)
        return matrix

    def set_state(self,state):
        """Set the initial quantum state of the quantum circuit"""
        self.start_state = np.array(state,dtype=complex)
        if self.start_state.ndim > 2:
            raise ValueError("The set_state array dimension cannot be greater than 2")
        elif self.start_state.ndim == 2 and 2 ** self.qubits != len(self.start_state[0]):
            raise ValueError("The set_state dimension is inconsistent with qubits")
        elif self.start_state.ndim == 1 and 2 ** self.qubits != len(self.start_state):
            raise ValueError("The set_state dimension is inconsistent with qubits")
        # if 2 ** self.qubits != len(self.start_state):
        #     raise ValueError("The set_state dimension is inconsistent with qubits")
        if self.start_state.ndim == 2:
            try:
                self.set_batch(self.start_state.shape[0])
            except ValueError:
                raise ValueError(f"start_state batch_size is inconsistent with the previously batch_size")


    def depth(self):
        """Calculate the depth of Quantum circuit

        returns:
            maxdepth (int): depth of Quantum circuit

        Examples:
            from wuyue.circuit import QuantumCircuit
            from wuyue.register.classicalregister import ClassicalRegister
            from wuyue.register.quantumregister import QuantumRegister
            from wuyue.element.gate import *
            qubit = QuantumRegister(2)
            cbit = ClassicalRegister(2)
            q = QuantumCircuit(qubit, cbit)
            q.mul_add(H, qubit[0, 1])
            q.add(CNOT, qubit[1], qubit[0])
            print(q.depth())
            2
        """
        self.get_tempgates()
        maxdepth = max([len(self.qreg[i]) for i in range(self.qubits)])
        # if not isinstance(self.temp_gates[-1],MEASURE):
        #     maxdepth = max([len(self.qreg[i]) for i in range(self.qubits)])
        # else:
        #     maxdepth = max([len(self.qreg[i]) for i in range(self.qubits)]) - 1
        return maxdepth

    @property
    def use_parameter(self):
        # paras_name = [i.name for i in self._use_parameters]
        paras = {}
        if self._use_parameters == []:
            return None
        for i in self._use_parameters:
            paras[i.name] = i
        return paras

    def bind_parameters(self, key_value:dict, inplace=False):
        if inplace:
            circuit = self
        else:
            circuit = copy.deepcopy(self)
        for key,value in key_value.items():
            if isinstance(key,Parameters):
                name = key.name
            elif isinstance(key,ParameterVector):
                if isinstance(value,(list,np.ndarray)) and len(value)==len(key):
                    for index,paras in enumerate(key):
                        name = paras.name
                        if name in self.use_parameter.keys():
                            circuit.use_parameter[name].set_data(value[index])
                        else:
                            raise ValueError(f"Cannot bind parameters {name} not present in the circuit.")
                    continue
                else:
                    raise ValueError("The value of the dictionary needs to be a list or numpy array, "
                                     "and its number should be equal to the number of parameters")
            elif isinstance(key, str):
                name = key
            else:
                raise TypeError("The keys of the dictionary need to be related to the parameters")
            if name in self.use_parameter.keys():
                circuit.use_parameter[name].set_data(value)
            else:
                raise ValueError(f"Cannot bind parameters {name} not present in the circuit.")
            # circuit._use_parameters[0].set_data(value)
        return circuit

class Readout_Noise:
    def __init__(self,target,noise):
        self.target = target
        if isinstance(noise,(BitFlip,PhaseFlip,PauliChannel,Depolarizing,AmplitudeDamping,GeneralizedAmplitudeDamping,
                           PhaseDamping)):
            self.noise = noise
        else:
            raise TypeError("The noise needs to be one bit noise class")

class BARRIER:
    """BARRIER"""
    def __init__(self,target):
        if isinstance(target, int):
            self.target = [target]
        else:
            self.target = target
        self.symbol = "BARRIER"
        self.name = "BARRIER"
    def __str__(self):
        return self.symbol
    def __repr__(self):
        return self.symbol

class RESET:
    """RESET"""
    def __init__(self,target):
        if isinstance(target,int):
            self.target = [target]
        else:
            self.target = target
        self.symbol = "RESET"
        self.name = "RESET"
    def __str__(self):
        return self.symbol
    def __repr__(self):
        return self.symbol