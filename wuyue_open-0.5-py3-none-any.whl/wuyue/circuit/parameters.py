# -*- coding: utf-8 -*-
from uuid import uuid4
class Parameters:
    def __init__(self,data):
        self._uuid = uuid4()
        self._hash = hash(self._uuid)
        if isinstance(data,str):
            self.name = data
            self._value = None

    def set_data(self,data):
        self._value = data

    def __str__(self):
        return f"Parameters({self.name})"

    def __repr__(self):
        return str(self)

    def __hash__(self):
        return self._hash

    def __eq__(self, other):
        if isinstance(other, Parameters):
            return self._uuid == other._uuid
        else:
            return False

    @property
    def value(self):
        return self._value

class ParameterVector:
    def __init__(self,data,number):
        self.name = data
        self.number = number
        self.paras = []
        for i in range(number):
            self.paras.append(Parameters(f"{self.name}[{i}]"))

    def __getitem__(self, item):
        if isinstance(item, slice):
            start, stop, step = item.indices(self.number)
            return self.paras[start:stop:step]

        if item > self.number:
            raise IndexError(f"Index out of range: {item} > {self.number}")
        return self.paras[item]

    def __iter__(self):
        return iter(self.paras[: self.number])

    def __len__(self):
        return self.number

    def __str__(self):
        return f"{self.name}, {[str(item) for item in self.paras[: self.number]]}"

    def __repr__(self):
        return f"{self.__class__.__name__}(name={self.name}, length={len(self)})"
