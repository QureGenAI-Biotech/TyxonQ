# -*- coding: utf-8 -*-
from ..element.noise import *
from ..element.gate import *
from ..register.Bit import Bit
class NoiseModel(object):
    def __init__(self,qubit:int):
        self.noise_list = [BitFlip,PhaseFlip,PauliChannel,Depolarizing,AmplitudeDamping,GeneralizedAmplitudeDamping,PhaseDamping]
        self.used_noise_list = set()
        self.gate_list = {}
        self._1qubit_gate = (H, X, Y, Z, T, S, RX, RY, RZ, P, U1, U2, U3)
        self._nqubit_gate = (CNOT,CX, CZ, SWAP,TOFFOLI,CCX)
        self.gate_name_list = {H:"H",X:"X", Y:"Y", Z:"Z", T:"T", S:"S", RX:"RX", RY:"RY",
                               P:"P", RZ:"RZ", CX:"CX", CNOT:"CNOT", CZ:"CZ", CCX:"CCX",
                               TOFFOLI:"TOFFOLI", SWAP:"SWAP", U1:"U1", U2:"U2", U3:"U3"}
        self.qubits = qubit

    def add_one_qubit_error(self,noise:KrausOperation,gate:list,qubits:list,probability:float):
        self.used_noise_list.add(noise)
        if not set(gate).issubset(self._1qubit_gate):
            raise ValueError("Function add_one_qubit_error is only one qubit gate")
        if max(qubits) >= self.qubits:
            raise ValueError("The number of qubits is greater than the number of bits in the noise model")
        if min(qubits) < 0:
            raise ValueError("The number of qubits is smaller than 0")

        gate = [self.gate_name_list[i] for i in gate]
        for i in gate:
            for qubit in qubits:
                self._add_error(noise,i,qubit,probability)

    def _add_error(self,noise:KrausOperation,gate,qubit:int,probability:float):
        noise = noise([qubit], probability)
        if gate not in self.gate_list.keys():
            self.gate_list[gate] = {qubit: [noise]}
        else:
            if qubit not in self.gate_list[gate].keys():
                self.gate_list[gate][qubit] = [noise]
            else:
                if noise not in self.gate_list[gate][qubit]:
                    self.gate_list[gate][qubit].append(noise)

    def add_mul_qubit_error(self, noise:KrausOperation, gate:list, qubits:list, probability:float):
        self.used_noise_list.add(noise)
        if not set(gate).issubset(self._nqubit_gate):
            raise ValueError("Function add_mul_qubit_error is only multi qubit gate")
        if max(qubits) >= self.qubits:
            raise ValueError("The number of qubits is greater than the number of bits in the noise model")
        if min(qubits) < 0:
            raise ValueError("The number of qubits is smaller than 0")
        gate = [self.gate_name_list[i] for i in gate]
        for i in gate:
            noise = noise(qubits, probability)
            for qubit in qubits:
                if i not in self.gate_list.keys():
                    self.gate_list[i] = {qubit: [noise]}
                else:
                    if qubit not in self.gate_list[i].keys():
                        self.gate_list[i][qubit] = [noise]
                    else:
                        if noise not in self.gate_list[i][qubit]:
                            self.gate_list[i][qubit].append(noise)

    def add_all_qubit_error(self, noise:KrausOperation, gate:list, probability:float):
        self.used_noise_list.add(noise)
        gate = [self.gate_name_list[i] for i in gate]
        for i in gate:
            for qubit in range(self.qubits):
                self._add_error(noise, i, qubit, probability)

    def __repr__(self):
        str1 = "NoiseModel \n     Gates with noise: "
        str1 += ", ".join(self.gate_list.keys())
        return str1

def full_noise_model(noise:KrausOperation,qubits,one_bit_probability,two_bit_probability):
    if noise not in [BitFlip,PhaseFlip,Depolarizing]:
        raise ValueError("The full noise model can only be BitFlip\PhaseFlip\Depolarizing")
    noise_model = NoiseModel(qubits)
    noise_model.add_all_qubit_error(noise, gate=[H, X, Y, Z, T, S, RX, RY, RZ, P],
                                   probability=one_bit_probability)
    noise_model.add_all_qubit_error(noise, gate=[CNOT, CX, CZ, SWAP],
                                   probability=two_bit_probability)
    return noise_model



