# coding: utf-8


class HttpResponse(object):

    def __init__(self, code, headers, data):
        self.code = code
        self.headers = headers
        self.data = data
