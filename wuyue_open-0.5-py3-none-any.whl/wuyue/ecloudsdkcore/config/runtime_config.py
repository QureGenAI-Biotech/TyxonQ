# coding: utf-8


class RuntimeConfig(object):

    def __init__(
            self,
            read_timeout=None,
            connect_timeout=None,
            auto_retry=None,
            max_retry_times=None,
            retry_period=None,
            max_during_time=None,
            http_proxy=None,
            https_proxy=None,
            auth_type=None,
            ignore_gateway=None,
            central_transport_enabled=None,
            ignore_ssl=None,
            cert_file=None,
            client_cert_file=None,
            client_key_file=None,
            runtime_header_params=None,
            provider=None
    ):
        self.read_timeout = read_timeout
        self.connect_timeout = connect_timeout
        self.auto_retry = auto_retry
        self.max_retry_times = max_retry_times
        self.retry_period = retry_period
        self.max_during_time = max_during_time
        self.http_proxy = http_proxy
        self.https_proxy = https_proxy
        self.auth_type = auth_type
        self.ignore_gateway = ignore_gateway
        self.central_transport_enabled = central_transport_enabled
        self.ignore_ssl = ignore_ssl
        self.cert_file = cert_file
        self.client_cert_file = client_cert_file
        self.client_key_file = client_key_file
        self.runtime_header_params = runtime_header_params
        self.provider = provider