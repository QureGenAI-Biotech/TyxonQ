# coding: utf-8
from enum import Enum


class AuthType(Enum):
    AK = 1,
    TOKEN = 2,
    NO_AUTH = 3


class Config(object):

    def __init__(
            self,
            access_key=None,
            secret_key=None,
            security_token=None,
            pool_id=None,
            read_timeout=None,
            connect_timeout=None,
            protocol="http",
            auto_retry=False,
            max_retry_times=None,
            retry_period=None,
            max_during_time=None,
            http_proxy=None,
            https_proxy=None,
            client_proxy_username=None,
            client_proxy_password=None,
            client_proxy_host=None,
            client_proxy_port=None,
            client_proxy_protocol=None,
            source=None,
            auth_type=AuthType.AK,
            ignore_gateway=False,
            central_transport_enabled=True,
            ignore_ssl=True,
            cert_file=None,
            client_cert_file=None,
            client_key_file=None,
            global_query_params=None,
            global_header_params=None,
            provider=None
    ):
        self.access_key = access_key
        self.secret_key = secret_key
        self.security_token = security_token
        self.pool_id = pool_id
        self.read_timeout = read_timeout
        self.connect_timeout = connect_timeout
        self.protocol = protocol
        self.auto_retry = auto_retry
        self.max_retry_times = max_retry_times
        self.retry_period = retry_period
        self.max_during_time = max_during_time
        self.http_proxy = http_proxy
        self.https_proxy = https_proxy
        self.client_proxy_username = client_proxy_username
        self.client_proxy_password = client_proxy_password
        self.client_proxy_host = client_proxy_host
        self.client_proxy_port = client_proxy_port
        self.client_proxy_protocol = client_proxy_protocol
        self.source = source
        self.auth_type = auth_type
        self.ignore_gateway = ignore_gateway
        self.central_transport_enabled = central_transport_enabled
        self.ignore_ssl = ignore_ssl
        self.cert_file = cert_file
        self.client_cert_file = client_cert_file
        self.client_key_file = client_key_file
        self.global_query_params = global_query_params
        self.global_header_params = global_header_params
        self.provider = provider
