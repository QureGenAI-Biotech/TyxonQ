# coding: utf-8
"""
Request position

Description:
  This file defines the request location object parent
"""


class Body(object):
    """
    parent class - position body
    """
    pass


class Header(object):
    """
    parent class - position header
    """
    pass


class Path(object):
    """
    parent class - position path
    """
    pass


class Query(object):
    """
    parent class - position query
    """
    pass
