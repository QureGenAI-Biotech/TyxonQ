from ..retry.retry_template import RetryTemplate

MAX_RETRY_TIMES = 10
MAX_DURING_TIME = 60 * 1000


class RetryTemplateBuilder(object):
    def __init__(self, retry_policy=None, retry_times=None, max_during_time=None):
        self.retry_policy = retry_policy
        self.retry_times = retry_times
        self.max_during_time = max_during_time

    def set_retry_policy(self, retry_policy=None):
        self.retry_policy = retry_policy
        return self

    def set_retry_times(self, retry_times=None):
        self.retry_times = retry_times
        return self

    def set_max_during_time(self, max_during_time=None):
        self.max_during_time = max_during_time
        return self

    def build(self):
        retry_times = self.retry_times
        if self.retry_times is None or self.retry_times <= 0:
            retry_times = MAX_RETRY_TIMES
        max_time = self.max_during_time
        if self.max_during_time is None or self.max_during_time <= 0:
            max_time = MAX_DURING_TIME
        return RetryTemplate(retry_policy=self.retry_policy, retry_times=retry_times, max_during_time=max_time)
