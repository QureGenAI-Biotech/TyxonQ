import abc
import datetime
import math
import random


class Policy(abc.ABC):
    @abc.abstractmethod
    def compute_wait_time(self, retry_context):
        pass


def no_wait():
    return FixedRetryPolicy(0)


def wait_retry_policy(sleep_time):
    return FixedRetryPolicy(sleep_time)


class FixedRetryPolicy(Policy):
    def __init__(self, sleep_time):
        self.sleep_time = sleep_time

    def compute_wait_time(self, retry_context):
        return self.sleep_time


class RandomRetryPolicy(Policy):
    def __init__(self, minimum, maximum):
        self.minimum = minimum
        self.maximum = maximum

    def compute_wait_time(self, retry_context):
        t = random.choice(datetime.datetime.now().second * 1000)
        return abs(t % (self.maximum - self.minimum)) + self.minimum


class IncrementingRetryPolicy(Policy):
    def __init__(self, init_wait_time, increment):
        self.init_wait_time = init_wait_time
        self.increment = increment

    def compute_wait_time(self, retry_context):
        res = self.init_wait_time + (self.increment * (retry_context.get_retry_times() - 1))
        if res > 0:
            return res
        return 0


class ExponentialRetryPolicy(Policy):
    def __init__(self, multiplier, maximum_wait):
        self.multiplier = multiplier
        self.maximum_wait = maximum_wait

    def compute_wait_time(self, retry_context):
        exp = math.pow(float(retry_context.get_retry_times()), 2)
        t = random.randint(int(exp) * self.multiplier)
        if t > self.maximum_wait:
            return self.maximum_wait
        return t


class CompositeRetryPolicy(Policy):
    def __init__(self, wait_policies):
        self.wait_policies = wait_policies

    def compute_wait_time(self, retry_context):
        wait_time = 0
        for policy in range(self.wait_policies):
            wait_time += policy.compute_wait_time(retry_context)
        return wait_time
