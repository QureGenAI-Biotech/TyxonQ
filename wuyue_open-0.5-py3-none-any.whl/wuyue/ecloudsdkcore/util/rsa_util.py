from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5
import base64


class RSAUtil:
    def __init__(self, public_key=None, private_key=None):
        self.public_key = self.load_public_key(public_key)  # 私钥对象
        self.private_key = self.load_private_key(private_key)  # 私钥对象

    def _recover_pem_format(self, base64_str, key_type):
        """将无换行Base64字符串恢复为标准PEM格式"""
        # 定义PEM头部和尾部
        if key_type == 'public':
            header = '-----BEGIN PUBLIC KEY-----\n'
            footer = '\n-----END PUBLIC KEY-----'
        elif key_type == 'private':
            header = '-----BEGIN PRIVATE KEY-----\n'
            footer = '\n-----END PRIVATE KEY-----'
        else:
            raise ValueError("key_type必须是'public'或'private'")

        # 每64个字符添加一个换行符（PEM格式要求）
        pem_lines = [base64_str[i:i + 64] for i in range(0, len(base64_str), 64)]
        pem_content = '\n'.join(pem_lines)

        # 拼接完整PEM格式
        return header + pem_content + footer

    def load_public_key(self, base64_key):
        if base64_key is None:
            return None
        """加载无换行Base64格式的公钥"""
        # 恢复为PEM格式
        pem_key = self._recover_pem_format(base64_key, 'public')
        # 导入公钥
        self.public_key = RSA.import_key(pem_key)
        return self.public_key

    def load_private_key(self, base64_key):
        if base64_key is None:
            return None
        """加载无换行Base64格式的私钥"""
        # 恢复为PEM格式
        pem_key = self._recover_pem_format(base64_key, 'private')
        # 导入私钥
        self.private_key = RSA.import_key(pem_key)
        return self.private_key

    def encrypt(self, plain_text):
        """使用公钥加密，返回Base64编码的密文"""
        if not self.public_key:
            raise ValueError("请先加载公钥")

        # 创建加密器（使用更安全的OAEP填充模式）
        cipher = PKCS1_v1_5.new(self.public_key)

        # 处理明文（确保为字节类型）
        if isinstance(plain_text, str):
            plain_text = plain_text.encode('utf-8')

        # 加密并转为Base64
        encrypted_bytes = cipher.encrypt(plain_text)
        return base64.b64encode(encrypted_bytes).decode('utf-8')

    def decrypt(self, encrypted_base64):
        """使用私钥解密Base64编码的密文"""
        if not self.private_key:
            raise ValueError("请先加载私钥")

        # 创建解密器
        cipher = PKCS1_v1_5.new(self.private_key)

        # 解密流程：Base64解码 → 私钥解密
        encrypted_bytes = base64.b64decode(encrypted_base64)
        decrypted_bytes = cipher.decrypt(encrypted_bytes, None)

        return decrypted_bytes.decode('utf-8')
