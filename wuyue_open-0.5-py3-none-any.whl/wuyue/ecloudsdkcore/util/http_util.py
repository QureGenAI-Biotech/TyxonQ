# coding: utf-8
"""
@author:ecloud-sdk
@file:http_util.py
@time:2021/07/18
"""
import re


def select_header_accept(accepts):
    """Returns `Accept` based on an array of accepts provided.

    :param accepts: List of headers.
    :return: Accept (e.g. application/json).
    """
    if not accepts:
        return

    accepts = [x.lower() for x in accepts]

    if 'application/json' in accepts:
        return 'application/json'
    else:
        return ', '.join(accepts)


def select_header_content_type(content_types):
    """Returns `Content-Type` based on an array of content_types provided.

    :param content_types: List of content-types.
    :return: Content-Type (e.g. application/json).
    """
    if not content_types:
        return 'application/json'

    content_types = [x.lower() for x in content_types]

    if 'application/json' in content_types or '*/*' in content_types:
        return 'application/json'
    else:
        return content_types[0]


def select_filename_by_header(headers):
    content_disposition = headers['Content-Disposition']
    if content_disposition:
        filename = re.search(r'filename=[\'"]?([^\'"\s]+)[\'"]?',
                             content_disposition).group(1)
        return filename
    return None
