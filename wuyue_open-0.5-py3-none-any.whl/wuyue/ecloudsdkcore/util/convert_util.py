# coding: utf-8
import datetime
import mimetypes
import os
import re
import tempfile

import six

from ..util.common_util import is_unset

PRIMITIVE_TYPES = (float, bool, bytes, six.text_type) + six.integer_types
NATIVE_TYPES_MAPPING = {
    'int': int,
    'long': int if six.PY3 else long,  # noqa: F821
    'float': float,
    'str': str,
    'bool': bool,
    'date': datetime.date,
    'datetime': datetime.datetime,
    'object': object,
}


def sanitize_for_serialization(obj):
    if obj is None:
        return None
    elif isinstance(obj, PRIMITIVE_TYPES):
        return obj
    elif isinstance(obj, list):
        return [sanitize_for_serialization(sub_obj)
                for sub_obj in obj]
    elif isinstance(obj, tuple):
        return tuple(sanitize_for_serialization(sub_obj)
                     for sub_obj in obj)
    elif isinstance(obj, (datetime.datetime, datetime.date)):
        return obj.isoformat()

    if isinstance(obj, dict):
        obj_dict = obj
    else:
        obj_dict = {obj.attribute_map[attr]: getattr(obj, attr)
                    for attr, _ in six.iteritems(obj.data_types)
                    if getattr(obj, attr) is not None}

    return {key: sanitize_for_serialization(val)
            for key, val in six.iteritems(obj_dict)}


def deserialize(data, klass, model_package):
    """Deserializes dict, list, str into an object.

    :param model_package: model package used to deserialize data
    :param data: dict, list or str.
    :param klass: class literal, or string of class name.

    :return: object.
    """
    if data is None:
        return None

    if type(klass) == str:
        if klass.startswith('list['):
            sub_kls = re.match(r'list\[(.*)\]', klass).group(1)
            return [deserialize(sub_data, sub_kls, model_package)
                    for sub_data in data]

        if klass.startswith('dict('):
            sub_kls = re.match(r'dict\(([^,]*), (.*)\)', klass).group(2)
            return {k: deserialize(v, sub_kls, model_package)
                    for k, v in six.iteritems(data)}

        # convert str to class
        if klass in NATIVE_TYPES_MAPPING:
            klass = NATIVE_TYPES_MAPPING[klass]
        elif model_package is not None:
            klass = getattr(model_package, klass)

    if klass in PRIMITIVE_TYPES:
        return deserialize_primitive(data, klass)
    elif klass == object:
        return deserialize_object(data)
    elif klass == datetime.date:
        return deserialize_date(data)
    elif klass == datetime.datetime:
        return deserialize_datetime(data)
    else:
        return deserialize_model(data, klass, model_package)


def deserialize_model(data, klass, model_package):
    """Deserializes list or dict to model.

    :param model_package: model package used to deserialize data
    :param data: dict, list.
    :param klass: class literal.
    :return: model object.
    """

    if (not klass.data_types and
            not has_attr(klass, 'get_real_child_model')):
        return data

    kwargs = {}
    if klass.data_types is not None:
        for attr, attr_type in six.iteritems(klass.data_types):
            if (data is not None and
                    klass.attribute_map[attr] in data and
                    isinstance(data, (list, dict))):
                value = data[klass.attribute_map[attr]]
                kwargs[attr] = deserialize(value, attr_type, model_package)

    instance = klass(**kwargs)

    if (isinstance(instance, dict) and
            klass.data_types is not None and
            isinstance(data, dict)):
        for key, value in data.items():
            if key not in klass.data_types:
                instance[key] = value
    if has_attr(instance, 'get_real_child_model'):
        klass_name = instance.get_real_child_model(data)
        if klass_name:
            instance = deserialize(data, klass_name, model_package)
    return instance


def has_attr(obj, name):
    if obj is None:
        return False
    return name in obj.__class__.__dict__


def deserialize_primitive(data, klass):
    """Deserializes string to primitive type.

    :param data: str.
    :param klass: class literal.

    :return: int, long, float, str, bool.
    """
    try:
        return klass(data)
    except UnicodeEncodeError:
        return six.text_type(data)
    except TypeError:
        return data


def deserialize_object(value):
    """Return a original value.

    :return: object.
    """
    return value


def deserialize_date(string):
    """Deserializes string to date.

    :param string: str.
    :return: date.
    """
    try:
        from dateutil.parser import parse
        return parse(string).date()
    except ImportError:
        return string


def deserialize_datetime(string):
    """Deserializes string to datetime.

    The string should be in iso8601 datetime format.

    :param string: str.
    :return: datetime.
    """
    try:
        from dateutil.parser import parse
        return parse(string)
    except ImportError:
        return string


def save_to_file(data, file_name=None, file_dir=None):
    if file_dir is None or len(file_dir) == 0:
        file_dir = tempfile.gettempdir()
    if file_name is None or len(file_name) == 0:
        fd, path = tempfile.mkstemp(dir=file_dir)
        os.close(fd)
    else:
        path = os.path.join(file_dir, file_name)

    with open(path, "wb") as f:
        f.write(data)

    return path


def prepare_post_parameters(post_params=None, files=None):
    """Builds form parameters.

    :param post_params: Normal form parameters.
    :param files: File parameters.
    :return: Form parameters with files.
    """
    params = []

    if post_params:
        params = post_params

    if files:
        for k, v in six.iteritems(files):
            if not v:
                continue
            file_names = v if type(v) is list else [v]
            for n in file_names:
                with open(n, 'rb') as f:
                    filename = os.path.basename(f.name)
                    filedata = f.read()
                    mimetype = (mimetypes.guess_type(filename)[0] or
                                'application/octet-stream')
                    params.append(
                        tuple([k, tuple([filename, filedata, mimetype])]))

    return params


def covert_dictvalue_to_str(params):
    if is_unset(params):
        return ""
    for key, value in six.iteritems(params):
        if isinstance(value, list):
            params[key] = ','.join(str(x) for x in value)
        else:
            params[key] = str(value)
    return params
