import pprint

import six


class RegistryLicenseResponse(object):
    data_types = {
        'msg': 'str',
        'data': 'str',
        'code': 'int',
        'error_code': 'str',
        'body': 'dict(str, object)'
    }

    attribute_map = {
        'msg': 'msg',
        'code': 'code',
        'data': 'data',
        'error_code': 'errorCode',
        'body': 'body'
    }

    def __init__(self, msg=None, data=None, code=None, error_code=None, body=None):  # noqa: E501
        """SubmitTaskResponse - a model defined in OpenAPI"""  # noqa: E501
        self._msg = None
        self._data = None
        self._code = None
        self._error_code = None
        self._body = None
        self.discriminator = None
        if msg is not None:
            self.msg = msg
        if code is not None:
            self.code = code
        if error_code is not None:
            self.error_code = error_code
        if body is not None:
            self.body = body
        if data is not None:
            self.data = data

    @property
    def msg(self):
        """Gets the msg of this SubmitTaskResponse.  # noqa: E501

        错误码  # noqa: E501

        :return: The msg of this SubmitTaskResponse.  # noqa: E501
        :type: str
        """
        return self._msg

    @msg.setter
    def msg(self, msg):
        """Sets the msg of this SubmitTaskResponse.

        错误码  # noqa: E501

        :param msg: The msg of this SubmitTaskResponse.  # noqa: E501
        :type: str
        """
        self._msg = msg
    @property
    def data(self):
        """Gets the msg of this SubmitTaskResponse.  # noqa: E501

        错误码  # noqa: E501

        :return: The msg of this SubmitTaskResponse.  # noqa: E501
        :type: str
        """
        return self._data

    @data.setter
    def data(self, data):
        """Sets the msg of this SubmitTaskResponse.

        错误码  # noqa: E501

        :param msg: The msg of this SubmitTaskResponse.  # noqa: E501
        :type: str
        """
        self._data = data
    @property
    def code(self):
        """Gets the code of this SubmitTaskResponse.  # noqa: E501

        响应编码  # noqa: E501

        :return: The code of this SubmitTaskResponse.  # noqa: E501
        :type: int
        """
        return self._code

    @code.setter
    def code(self, code):
        """Sets the code of this SubmitTaskResponse.

        响应编码  # noqa: E501

        :param code: The code of this SubmitTaskResponse.  # noqa: E501
        :type: int
        """
        self._code = code

    @property
    def error_code(self):
        """Gets the error_code of this SubmitTaskResponse.  # noqa: E501

        描述信息  # noqa: E501

        :return: The error_code of this SubmitTaskResponse.  # noqa: E501
        :type: str
        """
        return self._error_code

    @error_code.setter
    def error_code(self, error_code):
        """Sets the error_code of this SubmitTaskResponse.

        描述信息  # noqa: E501

        :param error_code: The error_code of this SubmitTaskResponse.  # noqa: E501
        :type: str
        """
        self._error_code = error_code

    @property
    def body(self):
        """Gets the body of this SubmitTaskResponse.  # noqa: E501

        任务信息  # noqa: E501

        :return: The body of this SubmitTaskResponse.  # noqa: E501
        :type: SubmitTaskResponseBody
        """
        return self._body

    @body.setter
    def body(self, body):
        """Sets the body of this SubmitTaskResponse.

        任务信息  # noqa: E501

        :param body: The body of this SubmitTaskResponse.  # noqa: E501
        :type: SubmitTaskResponseBody
        """
        self._body = body

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.data_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(RegistryLicenseResponse, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, RegistryLicenseResponse):
            return False

        return self.to_dict() == other.to_dict()

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        if not isinstance(other, RegistryLicenseResponse):
            return True

        return self.to_dict() != other.to_dict()