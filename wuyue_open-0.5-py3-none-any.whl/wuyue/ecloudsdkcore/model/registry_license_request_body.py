import six
import pprint

from ..position.request_position import *


class RegistryLicenseRequestBody(Body):
    data_types = {
        'license': 'str',
        'mac_addr': 'str'
    }

    attribute_map = {
        'license': 'license',
        'mac_addr': 'macAddr'
    }

    def __init__(self, license=None, mac_addr=None):
        """RegistryLicenseRequest - snake_case property style"""
        self._license = None
        self._mac_addr = None
        if license is not None:
            self.license = license
        if mac_addr is not None:
            self.mac_addr = mac_addr

    @property
    def license(self):
        return self._license

    @license.setter
    def license(self, license):
        self._license = license

    @property
    def mac_addr(self):
        return self._mac_addr

    @mac_addr.setter
    def mac_addr(self, mac_addr):
        self._mac_addr = mac_addr

    def to_dict(self):
        """Returns the model properties as a dict using attribute_map"""
        result = {}
        for attr, _ in six.iteritems(self.data_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[self.attribute_map[attr]] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[self.attribute_map[attr]] = value.to_dict()
            elif isinstance(value, dict):
                result[self.attribute_map[attr]] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[self.attribute_map[attr]] = value
        if issubclass(RegistryLicenseRequestBody, dict):
            for key, value in self.items():
                result[key] = value
        return result

    def to_str(self):
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        return self.to_str()

    def __eq__(self, other):
        if not isinstance(other, RegistryLicenseRequestBody):
            return False
        return self.to_dict() == other.to_dict()

    def __ne__(self, other):
        if not isinstance(other, RegistryLicenseRequestBody):
            return True
        return self.to_dict() != other.to_dict()