import six
import pprint

class RegistryLicenseResponseBody(object):
    data_types = {
        'license': 'str',
        'expire_timestamp': 'int',
        'first_register': 'str',
    }

    attribute_map = {
        'license': 'license',
        'expire_timestamp': 'expireTimestamp',
        'first_register': 'firstRegister',
    }

    def __init__(self, license=None, expire_timestamp=None, first_register=None):
        """RegistryLicenseResponseBody - snake_case property style"""
        self._license = None
        self._expire_timestamp = None
        self._first_register = None
        self.discriminator = None
        if license is not None:
            self.license = license
        if expire_timestamp is not None:
            self.expire_timestamp = expire_timestamp
        if first_register is not None:
            self.first_register = first_register

    @property
    def license(self):
        return self._license

    @license.setter
    def license(self, license):
        self._license = license

    @property
    def expire_timestamp(self):
        return self._expire_timestamp

    @expire_timestamp.setter
    def expire_timestamp(self, expire_timestamp):
        self._expire_timestamp = expire_timestamp

    @property
    def first_register(self):
        return self._first_register

    @first_register.setter
    def first_register(self, first_register):
        self._first_register = first_register

    def to_dict(self):
        """Returns the model properties as a dict using attribute_map"""
        result = {}
        for attr, _ in six.iteritems(self.data_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[self.attribute_map[attr]] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[self.attribute_map[attr]] = value.to_dict()
            elif isinstance(value, dict):
                result[self.attribute_map[attr]] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[self.attribute_map[attr]] = value
        if issubclass(RegistryLicenseResponseBody, dict):
            for key, value in self.items():
                result[key] = value
        return result

    def to_str(self):
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        return self.to_str()

    def __eq__(self, other):
        if not isinstance(other, RegistryLicenseResponseBody):
            return False
        return self.to_dict() == other.to_dict()

    def __ne__(self, other):
        if not isinstance(other, RegistryLicenseResponseBody):
            return True
        return self.to_dict() != other.to_dict()