import datetime
import uuid
from abc import ABC, abstractmethod
from urllib.parse import unquote_plus
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from Crypto.Cipher import PKCS1_v1_5
from ..auth.credential import CredentialType
from ..auth.util import auth_constants as ac
from ..auth.util import algorithm_util as au
from ..exception.exceptions import SignatureException, InvalidParameterException
from ..util.common_util import is_unset
from ..util.string_util import percent_encode


class AbstractCredential(ABC):

    @abstractmethod
    def sign(self, request, credential):
        pass

    @abstractmethod
    def encrypt(self, origin_str, public_key):
        pass

    @abstractmethod
    def decrypt(self, origin_str, public_key):
        pass


def get_date(fmt):
    return datetime.datetime.now().strftime(fmt)


def nonce():
    return str(uuid.uuid4()).replace("-", "")


class AKSKCredential(AbstractCredential):

    def __init__(self):
        pass

    def sign(self, request, credential):
        if request is None:
            raise ValueError("http request argument can not be None.")
        request.convert_query_params_from_path()
        query_params = request.query_params or {}
        params = dict(query_params)
        params[ac.ACCESS_KEY] = credential.access_key
        params[ac.SIGNATURE_METHOD] = ac.SIGNATURE_SHA256_METHOD_VALUE
        params[ac.SIGNATURE_VERSION] = ac.SIGNATURE_VERSION_VALUE
        params[ac.TIMESTAMP] = get_date(ac.TIMESTAMP_FORMAT)
        params[ac.SIGNATURE_NONCE] = nonce()
        sorted_key = sorted(list(params.keys()))
        canonical_query_string = ""
        pos = 0
        for key in sorted_key:
            value = params.get(key)
            canonical_query_string += ac.QUERY_STRING_PATTERN.format(percent_encode(key), percent_encode(value))
            if pos < len(sorted_key) - 1:
                canonical_query_string += ac.PARAMETER_SEPARATOR
            pos += 1
        hash_string = au.sha256_encode_hex_string(canonical_query_string)
        path = request.path or ""
        servlet_path = unquote_plus(path)
        if request.method is None:
            raise SignatureException("the method of http request can bot be None")
        method = request.method
        string_to_sign = method.upper() + ac.LINE_SEPARATOR + percent_encode(
            servlet_path) + ac.LINE_SEPARATOR + hash_string
        signature = au.hmac_sha256_hex_string(string_to_sign, ac.SECRET_KEY_PREFIX + credential.secret_key)
        request.path = "{0}{1}{2}{3}{4}".format(servlet_path, ac.QUERY_START_SYMBOL, canonical_query_string,
                                                ac.PARAMETER_SEPARATOR,
                                                ac.QUERY_STRING_PATTERN.format(ac.SIGNATURE, percent_encode(signature)))

    def encrypt(self, origin_str, public_key):
        return origin_str

    def decrypt(self, origin_str, public_key):
        return origin_str


class MopCredential(AbstractCredential):
    def __init__(self):
        pass

    def sign(self, request, credential):
        if is_unset(credential.private_key):
            raise InvalidParameterException("RSA private key can not be null")
        request.convert_query_params_from_path()
        query_params = request.query_params or {}
        params = dict(query_params)
        flowd_id = nonce()
        params["flowdId"] = flowd_id
        sorted_key = sorted(list(params.keys()))
        canonical_query_string = ""
        pos = 0
        for key in sorted_key:
            value = params.get(key)
            canonical_query_string += ac.QUERY_STRING_PATTERN.format(percent_encode(key), percent_encode(value))
            if pos < len(sorted_key) - 1:
                canonical_query_string += ac.PARAMETER_SEPARATOR
            pos += 1
        sign_str = au.generate_rsa_signature(credential.private_key, canonical_query_string)
        if request.query_params is None:
            request.query_params = {}
        request.query_params.update({"sign": sign_str})
        request.query_params.update({"flowdId": flowd_id})
        CredentialFactory.get_credential_manager(CredentialType.ECLOUD_AKSK).sign(request, credential)

    def encrypt(self, origin_str, public_key):
        if is_unset(public_key):
            raise InvalidParameterException("RSA public key can not be null")
        key_bytes = au.base64_decode(public_key)
        public_key_obj = RSA.importKey(key_bytes)
        cipher = PKCS1_v1_5.new(public_key_obj)
        encrypted_data = b''
        data = origin_str.encode('utf-8')
        for i in range(0, len(data), 64):
            chunk = data[i:i + 64]
            encrypted_chunk = cipher.encrypt(chunk)
            encrypted_data += encrypted_chunk
        return au.base64_encode_str(encrypted_data)

    def decrypt(self, origin_str, private_key):
        if is_unset(private_key):
            raise InvalidParameterException("RSA private key can not be null")
        data = au.base64_decode(origin_str)
        key_bytes = au.base64_decode(private_key)
        rsa_key = RSA.import_key(key_bytes)
        cipher = PKCS1_v1_5.new(rsa_key)
        decrypted_data = b""
        chunk_size = 75
        for i in range(0, len(data), chunk_size):
            decrypted_chunk = cipher.decrypt(data[i:i + chunk_size], None)
            decrypted_data += decrypted_chunk
        return decrypted_data.decode('utf-8')


class NoneCredential(AbstractCredential):
    def __init__(self):
        pass

    def sign(self, request, credential):
        request.build_query_params_string()

    def encrypt(self, origin_str, public_key):
        pass

    def decrypt(self, origin_str, public_key):
        pass


AKSKCredentialInstance = AKSKCredential()
MopCredentialInstance = MopCredential()
NoneCredentialInstance = NoneCredential()


class CredentialFactory:
    @staticmethod
    def get_credential_manager(credential_type):
        if credential_type == CredentialType.ECLOUD_AKSK:  # AKSK
            return AKSKCredentialInstance
        elif credential_type == CredentialType.MOP:  # Mop
            return MopCredentialInstance
        elif credential_type == CredentialType.NONE:  # None
            return NoneCredentialInstance
        else:
            raise InvalidParameterException("Invalid credential type")  # Invalid credential type
