from enum import Enum

from ..util.common_util import is_unset, is_set


class CredentialType(Enum):
    ECLOUD_AKSK = 1
    MOP = 2
    ECLOUD_S3 = 3
    NONE = 4


class EncryptionType(Enum):
    MOP_RSA = 1
    NONE = 2


class Credential(object):
    def __init__(self, access_key=None, secret_key=None, security_token=None, private_key=None, public_key=None,
                 credential_type=CredentialType.ECLOUD_AKSK, encryption_type=EncryptionType.NONE):
        self.access_key = access_key
        self.secret_key = secret_key
        self.security_token = security_token
        self.private_key = private_key
        self.public_key = public_key
        self.credential_type = credential_type
        self.encryption_type = encryption_type

    def copy_values(self, other):
        if is_unset(self.access_key) and is_set(other.access_key):
            self.access_key = other.access_key
        if is_unset(self.secret_key) and is_set(other.secret_key):
            self.secret_key = other.secret_key
        if is_unset(self.security_token) and is_set(other.security_token):
            self.security_token = other.security_token
        if is_unset(self.private_key) and is_set(other.private_key):
            self.private_key = other.private_key
        if is_unset(self.public_key) and is_set(other.public_key):
            self.public_key = other.public_key

    @staticmethod
    def create():
        return Credential()