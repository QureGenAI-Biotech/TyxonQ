import os
from abc import ABC
from ..auth.util import auth_constants as ac

from ..auth.credential import Credential
from ..exception.exceptions import CredentialException


class AbstractCredentialProvider(ABC):

    def get_credential(self):
        pass


class BasicCredentialProvider(AbstractCredentialProvider):

    def __init__(self, credential):
        self.credential = credential

    def get_credential(self):
        return self.credential

    @staticmethod
    def create(credential):
        return BasicCredentialProvider(credential)


class EnvCredentialProvider(AbstractCredentialProvider):
    def __init__(self):
        pass

    @staticmethod
    def create():
        return EnvCredentialProvider()

    def get_credential(self):
        access_key = os.getenv(ac.ENV_ACCESS_KEY)
        secret_key = os.getenv(ac.ENV_SECRET_KEY)
        private_key = os.getenv(ac.ENV_MOP_PRIVATE_KEY)
        public_key = os.getenv(ac.ENV_MOP_PUBLIC_KEY)
        if access_key and secret_key:
            return Credential(access_key=access_key, secret_key=secret_key, private_key=private_key,
                              public_key=public_key)
        else:
            raise CredentialException("EnvCredentialProvider: accessKey or secretKey cannot be empty")


def get_profile_path_by_default() -> str:
    home_dir = os.path.expanduser("~")
    if not home_dir:
        raise CredentialException("Get the user home directory error")
    dir_path = home_dir + ac.PATH_CREDENTIAL_FILE.replace("/", os.path.sep)
    if not os.path.exists(dir_path):
        raise CredentialException(f"Get the profile directory error: {dir_path} does not exist")
    return dir_path


class ProfileCredentialProvider(AbstractCredentialProvider):
    def __init__(self, credential=None, path=None):
        self.credential = credential
        self.profile_path = path

    def get_profile_path(self) -> str:
        if not os.path.exists(self.profile_path):
            raise CredentialException(f"Get the profile directory error: {self.profile_path} does not exist")
        return self.profile_path

    @staticmethod
    def create(credential=None, path=None):
        return ProfileCredentialProvider(credential, path)

    @staticmethod
    def create_by_default():
        return ProfileCredentialProvider(Credential.create(), '')

    @staticmethod
    def create_by_path(path=None):
        return ProfileCredentialProvider(Credential.create(), path)

    def get_credential(self):
        path = os.getenv(ac.ENV_CREDENTIAL_FILE)
        if path is None:
            if self.profile_path:
                path = self.get_profile_path()
            else:
                path = get_profile_path_by_default()

        if not path:
            raise CredentialException("Profile path cannot be empty")

        try:
            with open(path, 'r') as file:
                config = {}
                for line in file:
                    parts = line.strip().split('=', 1)
                    if len(parts) == 2:
                        key = parts[0].strip()
                        value = parts[1].strip()
                        config[key] = value

        except Exception as e:
            raise CredentialException("Open the profile file error") from e

        return Credential(access_key=config.get(ac.PROFILE_ACCESS_KEY),
                          secret_key=config.get(ac.PROFILE_SECRET_KEY),
                          private_key=config.get(ac.PROFILE_MOP_PRIVATE_KEY),
                          public_key=config.get(ac.PROFILE_MOP_PUBLIC_KEY))
