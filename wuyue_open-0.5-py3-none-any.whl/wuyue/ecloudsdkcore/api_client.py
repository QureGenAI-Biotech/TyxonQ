# coding: utf-8

from __future__ import absolute_import

import atexit
import copy

from .auth.credential import Credential
from .auth.credential_impl import CredentialFactory
from .exception.exceptions import InvalidParameterException
from .http.http_client import HttpClient
from .config.config import AuthType
from .config.runtime_config import RuntimeConfig
from .retry.retry_policy import no_wait, wait_retry_policy
from .retry.retry_template_builder import RetryTemplateBuilder
from .sign import signature
from .util.common_util import default_value, is_set, is_unset


def reset_http_request(http_request):
    http_request.reset()


class ApiClient(object):

    def __init__(self, config, model_package, http_request=None):
        self.config = config
        self.http_client = HttpClient(config, model_package)
        self.http_request = http_request
        # release resources before exit
        atexit.register(self.destroy)

    def __del__(self):
        self.destroy()

    def excute(self, params, runtime_config, return_type):
        http_request = copy.deepcopy(self.http_request)
        # reset HttpRequest of ApiClient
        reset_http_request(http_request)
        if runtime_config is None:
            runtime_config = RuntimeConfig()
        # construct http_request
        self.build_http_request(params, runtime_config, http_request)
        http_request.build_final_url()
        auto_retry = default_value(runtime_config.auto_retry, self.config.auto_retry)
        if auto_retry:
            retry_template = self.build_retry_template(runtime_config)
            return retry_template.call(
                self.http_client.execute, http_request, return_type, runtime_config)
        return self.http_client.execute(http_request, return_type, runtime_config)

    def build_http_request(self, params, runtime_config, http_request):
        http_request.convert_request(params.request)
        http_request.build_api_params(params, self.config, runtime_config)
        provider = default_value(runtime_config.provider, self.config.provider)
        access_key = self.config.access_key
        secret_key = self.config.secret_key
        if is_unset(provider):
            if is_unset(access_key) or is_unset(secret_key):
                raise InvalidParameterException("accessKey or secretKey can not be null")
            credential = Credential(access_key=access_key, secret_key=secret_key)
            CredentialFactory.get_credential_manager(credential.credential_type).sign(http_request, credential)
            return
        credential = provider.get_credential()
        if is_set(self.config.provider) and provider != self.config.provider:
            credential.copy_values(self.config.provider.get_credential())
        if is_unset(credential.access_key) or is_unset(credential.secret_key):
            credential.access_key = access_key
            credential.secret_key = secret_key
        CredentialFactory.get_credential_manager(credential.credential_type).sign(http_request, credential)

    def build_retry_template(self, runtime_config):
        retry_template_builder = RetryTemplateBuilder()
        max_Retry_Times = default_value(runtime_config.max_retry_times, self.config.max_retry_times)
        if max_Retry_Times is not None and max_Retry_Times > 0:
            retry_template_builder.set_retry_times(max_Retry_Times)
        max_during_time = default_value(runtime_config.max_during_time, self.config.max_during_time)
        if max_during_time is not None and max_during_time > 0:
            retry_template_builder.set_max_during_time(max_during_time)
        retry_period = default_value(runtime_config.retry_period, self.config.retry_period)
        if retry_period is not None and retry_period > 0:
            retry_template_builder.set_retry_policy(wait_retry_policy(retry_period))
        else:
            retry_template_builder.set_retry_policy(no_wait())
        return retry_template_builder.build()

    def destroy(self):
        if is_set(self.http_client):
            self.http_client.destroy()
