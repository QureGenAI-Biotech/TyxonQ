from ..util.license_util import LicenseUtil


def require_license(cls):
    class Wrapped(cls):
        def __init__(self, *args, **kwargs):
            LicenseUtil.read_user_dir_license()
            super().__init__(*args, **kwargs)
    return Wrapped
