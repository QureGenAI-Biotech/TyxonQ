from ..license.license_client import LicenseClient
from ..util.license_util import LicenseUtil

class License:

    @staticmethod
    def init_license(sdk_code,access_key,secret_key):

        mac_addr = LicenseUtil.get_mac()
        license_client = LicenseClient(access_key,secret_key)
        response = license_client.registry_license(mac_addr, sdk_code)

        if response.code != 1:
            raise Exception(f"License获取失败: {response.msg}")

        LicenseUtil.save_user_dir_license(response.data)

