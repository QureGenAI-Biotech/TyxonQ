# -*- coding: utf-8 -*-
from ..circuit.circuit import *
from ..programe.prog import *
import numpy as np

# bell state
def bell_state():
    qbit = QuantumRegister(2)
    cbit = ClassicalRegister(2)
    circuit = QuantumCircuit(qbit,cbit)
    circuit.add(H, qbit[0])
    circuit.add(CNOT, qbit[1],qbit[0])
    return circuit

# w state
def w_state(qubits:int):
    qbit = QuantumRegister(qubits)
    cbit = ClassicalRegister(qubits)
    circuit = QuantumCircuit(qbit,cbit)

    for i in range(qubits-1):
        paras = 2 * np.arccos(np.sqrt(1/(qubits-i)))

        if i == 0:
            circuit.add(RY,qbit[i],paras=paras)
        else:
            circuit.add(RY,qbit[i],qbit[i-1],paras=paras)

    for j in reversed(range(qubits-1)):
        circuit.add(CNOT,qbit[j+1],qbit[j])

        if j == 0:
            circuit.add(X,qbit[j])
    return circuit

# ghz state
def ghz_state(qubits):
    qbit = QuantumRegister(qubits)
    cbit = ClassicalRegister(qubits)
    circuit = QuantumCircuit(qbit,cbit)
    # if max(qubits)>circuit.qubits-1:
    #     raise ValueError("The number of bits affected by QFT cannot exceed the number of bits in the circuit")
    for index,qubit in enumerate(range(qubits)):
        if index==0:
            circuit.add(H,qbit[qubit])
        else:
            circuit.add(CNOT,qbit[index],qbit[index-1])
    return circuit
