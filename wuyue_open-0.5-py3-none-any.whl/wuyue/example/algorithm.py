# -*- coding: utf-8 -*-
from ..programe.prog import *
from ..backend.backend import Backend
import numpy as np
from fractions import Fraction
from math import pi
from scipy.linalg import expm

def _qft_unit(circuit,qubit,qubits):
    circuit.add(H,qubit[qubits[0]])
    for index,ctrl in enumerate(qubits[1:]):
        circuit.add(U1,paras=2 * np.pi / 2**(index+2),target=qubit[qubits[0]],control=qubit[ctrl])
    return circuit

def qft(qubits):
    qubit = QuantumRegister(qubits)
    cbit = ClassicalRegister(qubits)
    circuit = QuantumCircuit(qubit,cbit,"QFT")
    qubits = [i for i in range(qubits)]
    n_qubits = len(qubits)

    for i in range(n_qubits):
        circuit = _qft_unit(circuit,qubit,qubits[i:])

    for i in range(n_qubits//2):
        circuit.add(SWAP, qubit[i,n_qubits-1-i])
    return circuit

def qft_dagger(qubits):
    qubit = QuantumRegister(qubits)
    cbit = ClassicalRegister(qubits)
    circuit = QuantumCircuit(qubit,cbit,"QFT")
    qubits = [i for i in range(qubits)][::-1]
    n_qubits = len(qubits)

    for i in range(n_qubits):
        circuit = _qft_unit(circuit,qubit,qubits[i:])

    for i in range(n_qubits//2):
        circuit.add(SWAP, qubit[i,n_qubits-1-i])
    circuit.dagger()
    return circuit

def qaa(circuit:Union[QuantumProg,QuantumCircuit], qbit,iterations, target_index):
    sim = Backend.get_device(device_name="Full amplitude")      #建立一个全振幅模拟后端
    for i in range(iterations):
        _flip_bits(circuit, qbit, target_index)    #翻转某一比特相位
        _imag_circuit(circuit, qbit)                  #映射量子线路
        sim.apply(circuit)
        circuit_prob = sim.get_probs()
        sim.clear()
        print("prob of state {%d} = %s"%(target_index,circuit_prob[target_index]))


def _flip_bits(circuit:Union[QuantumProg,QuantumCircuit], qbit, target_index):
    bit_flip = bin(target_index)
    bit_flip = bit_flip[2:].zfill(circuit.qubits)
    bit_flip = bit_flip[::-1]

    for i in range(len(bit_flip)):
        if bit_flip[i] == "0":
            circuit.add(X,qbit[i])

    circuit.add(Z,qbit[circuit.qubits-1],qbit[range(circuit.qubits-1)])

    for i in range(len(bit_flip)):
        if bit_flip[i] == "0":
            circuit.add(X, qbit[i])

def _imag_circuit(circuit:Union[QuantumProg,QuantumCircuit], qbit:QuantumRegister):
    circuit.all_add(H)
    circuit.all_add(X)
    circuit.add(Z, qbit[circuit.qubits - 1], qbit[range(circuit.qubits - 1)])
    circuit.all_add(X)
    circuit.all_add(H)

def grover(qubits,target):
    # Quantum qubits
    import math
    qubit = QuantumRegister(qubits)
    cbit = ClassicalRegister(qubits)
    circuit = QuantumCircuit(qubit,cbit)

    iter_number = int(pi / 4 * math.sqrt(2 ** qubits))

    if target >= 2 ** qubits or not isinstance(target,int):
        raise ValueError("target out of 2^qubits")
    print("target state: |{%d}>"%target)

    circuit.all_add(H)

    qaa(circuit,qubit,iter_number, target)

    circuit.all_add(MEASURE)
    circuit.draw()
    sim = Backend.get_device(device_name="Full amplitude")
    sim.apply(circuit)
    result = sim.run(1)

    for i,j in result.items():
        if j==1:
            print("measure result: " + str(int(i, base=2)))

    return circuit

def shor(N,number):

    while True:
        # a = np.random.randint(N - 2) + 2  # 获得区间[2,N-1]内的随机整数a
        # b = np.gcd(a, N)  # 得到a与N的最大公因数b
        # if b != 1:
        #     print("random result")
        #     return b, int(N / b)  # 如果b不等于1，则b是N的质因数，返回分解结果
        # 通过连分数分解法计算result/2**q逼近的不可约分数，分母不能大于N
        a = 2
        eigenphase = _qpe_amod15(N_sup=number)
        print(eigenphase)
        if eigenphase==0:
            continue
        f = Fraction.from_float(eigenphase).limit_denominator(N)
        r = f.denominator  # 取f的分母，得到周期r
        print("Result:",r)
        c = np.gcd(a ** (int(r / 2)) - 1, N)
        d = np.gcd(a ** (int(r / 2)) + 1, N)
        if c != 1 and N % c == 0:
            print("Guessed Factors:",c, d)
            return (c, d)



def _mod_operator(power,number):
    qbit1 = QuantumRegister(4)
    cbit1 = ClassicalRegister(4)
    circuit = QuantumCircuit(qbit1,cbit1,name="U²(%s)"%number)
    for _iteration in range(power):
        circuit.add(SWAP,qbit1[2,3]).add(SWAP,qbit1[1,2]).add(SWAP,qbit1[0,1])
    # Circuit_draw(circuit)
    return circuit

def _qpe_amod15(N_sup):
    instances_counter = itertools.count()
    qbit = QuantumRegister(4+N_sup)
    cbit = ClassicalRegister(N_sup)
    qp = QuantumProg(qbit,cbit)
    for q in range(N_sup):
        qp.add(H,qbit[q])                                       #构建均匀叠加态
    qp.add(X,qbit[3+N_sup])                                   #设置辅助线路态为|1>
    for q in range(N_sup):
        qc = _mod_operator(2**q,number = next(instances_counter))
        qp.control(qc,qbit[q],pos=qbit[N_sup])                #添加Oracle
    qp.insert_circuit(qft_dagger(N_sup),pos=qbit[0])          #执行傅里叶逆变换
    qp.mul_add(MEASURE,qbit[range(N_sup)],cbit[range(N_sup)])  #添加测量门
    # Circuit_draw(qp)                                            #绘制线路图
    # print(qp.depth())
    sim = Backend.get_device(device_name="Full amplitude")
    sim.apply(qp)
    result = sim.run(1)                                         #进行测量
    for i,j in result.items():
        if j==1:
            result = i
            break
    result = int(result, 2)  # 将结果从二进制转化为十进制
    eigenphase = float(result / 2 ** N_sup)
    return eigenphase

def qpe():
    N_sup = 4
    instances_counter = itertools.count()
    qbit = QuantumRegister(4 + N_sup)
    cbit = ClassicalRegister(N_sup)
    qp = QuantumProg(qbit, cbit)
    for q in range(N_sup):
        qp.add(H, qbit[q])  # 构建均匀叠加态
    qp.add(X, qbit[3 + N_sup])  # 设置辅助线路态为|1>
    for q in range(N_sup):
        qc = _mod_operator(2 ** q, number=next(instances_counter))
        qp.control(qc, qbit[q], pos=qbit[N_sup])  # 添加Oracle
    qp.insert_circuit(qft_dagger(N_sup), pos=qbit[0])  # 执行傅里叶逆变换
    qp.mul_add(MEASURE, qbit[range(N_sup)], cbit[range(N_sup)])  # 添加测量门
    qp.draw()
    # Circuit_draw(qp)                                            #绘制线路图
    # print(qp.depth())
    sim = Backend.get_device(device_name="Full amplitude")
    sim.apply(qp)
    result = sim.run(1)  # 进行测量
    for i, j in result.items():
        if j == 1:
            result = i
            break
    result = int(result, 2)  # 将结果从二进制转化为十进制
    eigenphase = float(result / 2 ** N_sup)
    return eigenphase

def oracle_circuit(tag,n):
    # 构建oracle线路
    qbit = QuantumRegister(n+1)
    cbit = ClassicalRegister(n+1)
    circuit = QuantumCircuit(qbit, cbit)

    if tag == "balanced":
        number = np.random.randint(1,2**n)
        binary_number = bin(number)[2:].zfill(4)
        for qubit in range(len(binary_number)):
            if binary_number[qubit] == "1":
                circuit.add(X,qbit[qubit])

        for qubit in range(n):
            circuit.add(CX,qbit[n],qbit[qubit])

        for qubit in range(len(binary_number)):
            if binary_number[qubit] == "1":
                circuit.add(X,qbit[qubit])

    if tag == "constant":
        if np.random.randint(2) == 1:
            circuit.add(X,qbit[n])
    return circuit

def dj_algorithm(oracle, n):
    qbit = QuantumRegister(n+1)
    cbit = ClassicalRegister(n)
    dj_prog = QuantumProg(qbit, cbit)

    dj_prog.add(X,qbit[n])
    dj_prog.add(H,qbit[n])

    for qubit in range(n):
        dj_prog.add(H,qbit[qubit])

    dj_prog.extent(oracle)

    for qubit in range(n):
        dj_prog.add(H,qbit[qubit])
    for i in range(n):
        dj_prog.add(MEASURE,qbit[i],cbit[i])
    # dj_prog.draw()
    sim = Backend.get_device(device_name="Full amplitude")
    sim.apply(dj_prog)
    result = sim.run(1000)
    if result["0"*n] ==1000:
        print('constant')
    elif result["1"*n] ==1000:
        print('balanced')
    else:
        print("Input circuit error")
    return dj_prog


# 量子隐形传态算法样例
def quantum_teleportation(state):
    #   初态
    qubit1 = QuantumRegister(1)
    cbit1 = ClassicalRegister(1)
    circuit_S = QuantumCircuit(qubit1,cbit1)
    circuit_S.set_state(state)
    #   线路AB
    qubit2 = QuantumRegister(2)
    cbit2 = ClassicalRegister(2)
    circuit_AB = QuantumCircuit(qubit2,cbit2)
    circuit_AB.add(H,qubit2[0])
    circuit_AB.add(CNOT,qubit2[1],qubit2[0])
    #   将线路AB和初态S进行改变基态
    qubit = QuantumRegister(3)
    cbit = ClassicalRegister(3)
    prog_com = QuantumProg(qubit,cbit)
    prog_com.insert_circuit(circuit_S)
    prog_com.insert_circuit(circuit_AB,1)
    prog_com.add(CNOT,qubit[1],qubit[0])
    prog_com.add(H,qubit[0])
    prog_com.add(MEASURE,qubit[0],cbit[0])
    prog_com.add(MEASURE,qubit[1],cbit[1])
    prog_com.trueif(X,qubit[2])
    prog_com.qif("c[1]==1")
    prog_com.trueif(Z,qubit[2])
    prog_com.qif("c[0]==1")

    # sim = Backend()
    sim = Backend.get_device(device_name="Full amplitude")
    sim.apply(prog_com)
    state1 = sim.get_states()
    prog_com.draw()
    return state1

# 哈密顿量模拟算法
def simulate_hamiltonian(pauliterm,t,slices=3):
    '''
   @param:
        pauliterm:泡利项
        t: 演化时间
        slices: 切片数

    @return: 量子线路
    '''
    qubit=1
    cbit=1

    pauliOperator = PauliOperator(pauliterm) # 泡利算符

    t = t / slices
    qubit_list = QuantumRegister(qubit) #分配为寄存器
    cbits = ClassicalRegister(cbit)
    prog= QuantumProg(qubit_list,cbits) # prog后面看看是不是要改成量子程序，改成量子程序了
    # qp = QuantumProg(qubit, cbit)

    Hamiltonian=pauliOperator.toHamiltonian()
    # print("这里这里Hamiltonian", Hamiltonian)
    for i in range(slices):
        for op in Hamiltonian:
            # prog = simulate_one_term(qubit,cbit,qubit_list,cbits,op,t/slices) #qubit_list,cbits是整个外部的prog寄存器
            # prog.insert_circuit(simulate_one_term(qubit,cbit,qubit_list,cbits,op,t/slices)) #qubit,cbit都只是数字，不是寄存器
            ## 从这里
            qubit_list1 = QuantumRegister(qubit)  # transformer重新分配寄存器
            cbits1 = ClassicalRegister(cbit)
            transform = QuantumCircuit(qubit_list1, cbits1)
            actual_qlist = list()
            # print("hamiltonian_term: ", op[0])
            for single_term in op[0]:
                # print("single_term: ", single_term)
                if op[0][single_term] == 'X':
                    transform.add(H, qubit_list1[single_term])
                    actual_qlist.append(qubit_list1[single_term])
                elif op[0][single_term] == 'Y':
                    transform.add(RX, qubit_list1[single_term], paras=pi / 2)
                    actual_qlist.append(qubit_list1[single_term])
                elif op[0][single_term] == 'Z':
                    actual_qlist.append(qubit_list1[single_term])
            prog.insert_circuit(transform)

            if len(actual_qlist) > 1:
                for i in range(len(actual_qlist) - 1):
                    prog.add(CNOT, actual_qlist[i], actual_qlist[-1])
                prog.add(RZ, actual_qlist[-1], paras=op[1] * t)
                for i in range(len(actual_qlist) - 1):
                    prog.add(CNOT, actual_qlist[i], actual_qlist[-1])
            else:
                if len(actual_qlist) != 0:
                    prog.add(RZ, qubit_list[0], paras=op[1] * t)
            if len(transform.get_tempgates()[0]) != 0:
                prog.insert_circuit(transform.dagger())
        prog.draw()

    return prog

def expMat(config, mat, t):
    """
    计算给定矩阵的指数。

    参数:
    config (complex): 复数倍数，用于缩放矩阵。
    mat (np.matrix): 泡利算子矩阵。
    t (float): 演化时间。

    返回:
    np.matrix: 计算得到的酉矩阵。
    """
    # 计算矩阵指数
    exp_matrix = expm(config * mat * t)
    return exp_matrix

def average_gate_fidelity(matrix1, matrix2):
    """
    计算平均门保真度
    """
    # 确保两个矩阵都是numpy数组
    matrix1 = np.asarray(matrix1)
    matrix2 = np.asarray(matrix2)

    # 计算两个矩阵的乘积的迹
    product = np.dot(matrix1, matrix2.conj().T)
    trace = np.trace(product)

    # 计算矩阵的维度
    d = matrix1.shape[0]

    # 计算平均门保真度
    fidelity = (trace.real + d) / (2 * d)

    return fidelity

class PauliOperator:
    def __init__(self, terms=None):
        self.terms = terms if terms is not None else {}

    def __add__(self, other):
        result_terms = self.terms.copy()
        for key, value in other.terms.items():
            if key in result_terms:
                result_terms[key] += value
            else:
                result_terms[key] = value
        return PauliOperator(result_terms)

    def __sub__(self, other):
        # Subtract two Pauli operators
        result_terms = self.terms.copy()
        for key, value in other.terms.items():
            if key in result_terms:
                result_terms[key] -= value
            else:
                result_terms[key] = -value
        return PauliOperator(result_terms)

    def __mul__(self, other):
        result_terms = {}
        for key1, value1 in self.terms.items():
            for key2, value2 in other.terms.items():
                new_key = key1 + key2  # Simplified multiplication rule
                result_terms[new_key] = result_terms.get(new_key, 0) + value1 * value2
        return PauliOperator(result_terms)

    def toHamiltonian(self):
        """
        将 Pauli 算符转换为哈密顿量。

        Returns:
        List[Tuple[Dict[int, str], float]]: 哈密顿量数据列表，每个元组包含表示和复数值。
        """
        hamiltonian_terms = []
        for term_str, coeff in self.terms.items():
            # 将泡利算符的字符串表示转换为字典形式，其中键是量子比特的索引，值是对应的泡利算符
            term_dict = {}
            # 拆分每个项，例如 "X0" 会被拆分为 ["X", "0"]
            pauli, qubit_index = term_str[0], int(term_str[1:])
            term_dict[qubit_index] = pauli
            hamiltonian_terms.append((term_dict, coeff))
        return hamiltonian_terms

    def __str__(self):
        return str(self.terms)

    def getMaxIndex(self):
        indices = [int(key) for term in self.terms.keys() for key in term if key.isdigit()]
        return max(indices) if indices else 0

    def remapQubitIndex(self, index_map):
        new_terms = {}
        for term, value in self.terms.items():
            new_term = ''.join(
                [pauli + str(index_map[int(qubit)]) if qubit.isdigit() else qubit for pauli, qubit in term])
            new_terms[new_term] = value
        return PauliOperator(new_terms)

# 量子态编码（振幅编码）
def amplitude_encoder(x, n_qubits):

    # _check_input_type('amplitude_encoder', (np.ndarray, list), x) # 校验输入格式
    # _check_input_type('n_qubits', (int), n_qubits)
    if not isinstance(x, (np.ndarray, list)):
        raise TypeError("data must be a list or a numpy array.")
    if not isinstance(n_qubits, int):
        raise TypeError("n_qubits must be an integer.")

    if isinstance(x, np.ndarray):
        x = x.tolist()
    if len(x) > 2**n_qubits: #如果 x 的长度大于 2**n_qubits，则截取前 2**n_qubits 个元素。
        x = x[: (2**n_qubits)]
    while 2**n_qubits != len(x): #如果 x 的长度小于 2**n_qubits，则用 0 填充至 2**n_qubits
        x.append(0)

    vec = normalize(x) #对 x 进行归一化处理。
    eta = [[]]
    for i in range(len(vec)):
        eta[0].append(abs(vec[i]))

    for v in range(1, n_qubits+1):
        eta.append([])
        for i in range(int(2**(n_qubits-v))):
            eta[v].append(np.sqrt(eta[v-1][2*i]**2 + eta[v-1][2*i+1]**2))

    omega_0 = []
    for i in range(len(vec)):
        omega_0.append(np.angle(vec[i]))

    omega = [[]]
    for i in range(len(vec)):
        omega[0].append(2*np.angle(vec[i]))

    for v in range(1, n_qubits+1):
        omega.append([])
        for i in range(2**(n_qubits-v)):
            omega[v].append(0.)
            for j in range(2**v):
                omega[v][i] += omega_0[i*2**v+j]/2**(v-1)

    alphas = {}
    for v in range(n_qubits, 0, -1):
        for i in range(2**(n_qubits-v)):
            if eta[v][i] < 1e-6:
                alphas[f'alpha_{v}{i}'] = 0
            else:
                alphas[f'alpha_{v}{i}'] = 2*np.arcsin(eta[v-1][2*i+1]/eta[v][i])

    lambs = {}
    for v in range(n_qubits, 0, -1):
        for i in range(2**(n_qubits-v)):
            lambs[f'lambda_{v}{i}'] = omega[v-1][2*i+1] - omega[v][i]

    ## 第二个字典dic2为了解决parameters()的问题,直接调用dic2的key即可。
    dic1 = {key: (Parameters(key),{**alphas, **lambs}[key]) for key in {**alphas, **lambs}.keys()}
    ## 第三个字典为了解决bind_parameters()的问题
    # key是第二个字典的value，value是原字典的value？？？
    dic2 = {value[0]: value[1]for value in dic1.values()}
    # print("dic2", dic2)

    ### 1214 ###
    paras_circuit = amp_circuit(n_qubits,dic1)
    encoder_circuit = paras_circuit.bind_parameters(dic2,inplace=True)
    # return amp_circuit(n_qubits), {**alphas, **lambs}
    # return amp_circuit(n_qubits,dic1), dic2
    return encoder_circuit

def amp_circuit(n_qubits,dic1):
    qubits = QuantumRegister(n_qubits)  # transformer重新分配寄存器
    cbits = ClassicalRegister(n_qubits)
    circ = QuantumCircuit(qubits, cbits)
    circ.add(RY,qubits[n_qubits-1],paras=dic1.get(f'alpha_{n_qubits}0')[0]) #直接调用第二个字典的key即可
    circ.add(RZ,qubits[n_qubits-1],paras=dic1.get(f'lambda_{n_qubits}0')[0])

    for i in range(1, n_qubits):
        for j in range(int(2**i)):
            string = bin(j)[2:].zfill(i)
            for tem_qubit, bit in enumerate(string):
                qubit = int(n_qubits - tem_qubit)
                if bit == '0':
                    # circ += X.on(qubit-1) # .add
                    circ.add(X, qubits[qubit-1])

            # circ += RY(f'alpha_{int(n_qubits-i)}{j}').on(int(n_qubits-1-i), list(range(n_qubits-i, n_qubits))) #.add
            # circ += RZ(f'lambda_{int(n_qubits-i)}{j}').on(int(n_qubits-1-i), list(range(n_qubits-i, n_qubits))) # .add
            circ.add(RY, qubits[int(n_qubits-1-i)],qubits[range(n_qubits-i, n_qubits)], paras=dic1.get(f'alpha_{int(n_qubits-i)}{j}')[0]) #控制位是list嘛
            circ.add(RZ, qubits[int(n_qubits-1-i)], qubits[range(n_qubits-i, n_qubits)],paras=dic1.get(f'lambda_{int(n_qubits-i)}{j}')[0])
            string = bin(j)[2:].zfill(i)

            for tem_qubit, bit in enumerate(string):
                qubit = int(n_qubits - tem_qubit)
                if bit == '0':
                    # circ += X.on(qubit-1) #.add
                    circ.add(X, qubits[qubit-1])
    return circ

def _check_num_array(vec, name):
    if not isinstance(vec, (np.ndarray, list)):
        raise TypeError(f"{name} requires a numpy.ndarray or a list of number, but get {type(vec)}.")
def mod(vec_in, axis=0):
    _check_num_array(vec_in, 'vec_in')
    vec_in = np.array(vec_in)
    return np.sqrt(np.sum(np.conj(vec_in) * vec_in, axis=axis, keepdims=True))
def normalize(vec_in, axis=0):
    _check_num_array(vec_in, 'vec_in')
    vec_in = np.array(vec_in)
    return vec_in / mod(vec_in, axis=axis)
##

## 量子相位估计 ##
from scipy.linalg import fractional_matrix_power
def qpe(N_sup,gate=T(1),eigenstate=1):
    def power(matrix, t):
        matrix = fractional_matrix_power(matrix, t)
        return matrix
    qbit = QuantumRegister(1 + N_sup)
    cbit = ClassicalRegister(N_sup)
    qp = QuantumProg(qbit, cbit)
    for q in range(N_sup):
        qp.add(H, qbit[q])  # 构建均匀叠加态
    if eigenstate == 1:
        qp.add(X, qbit[N_sup])  # 设置辅助线路态为|1>
    for q in reversed(range(N_sup)):
        matrix1 = power(gate.matrix,2**(N_sup-q-1))
        gate1 = usergate(f"power{2**(N_sup-q-1)}",matrix1)
        qp.add(gate1, qbit[N_sup],qbit[q])
    qp.insert_circuit(qft(N_sup).dagger(), pos=qbit[0])  # 执行傅里叶逆变换
    qp.mul_add(MEASURE, qbit[range(N_sup)], cbit[range(N_sup)])  # 添加测量门
    qp.draw()
    # Circuit_draw(qp)                                            #绘制线路图
    # print(qp.depth())
    sim = Backend.get_device(device_name="Full amplitude")
    sim.apply(qp)
    # result = sim.run(100)  # 进行测量
    # print(result)
    result = sim.run(1)  # 进行测量
    for i, j in result.items():
        if j == 1:
            result = i
            break
    result = result[::-1]
    result = int(result, 2)  # 将结果从二进制转化为十进制
    print(result)
    eigenphase = float(result / 2 ** N_sup)
    return eigenphase
