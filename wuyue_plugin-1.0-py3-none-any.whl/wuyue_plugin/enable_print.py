class _PrintController:
    def __init__(self):
        self._enabled = False

    def enable_print(self, flag: bool):
        self._enabled = flag

    def custom_print(self, *args, **kwargs):
        if self._enabled:
            print(*args, **kwargs)

# 模块级单例（所有导入共享同一实例）
print_controller = _PrintController()
