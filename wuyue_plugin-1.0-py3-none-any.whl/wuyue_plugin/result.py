class Result:
    def __init__(self, device_id, task_id, success, status, counts, prob, amps, raw_result=None):
        self._device_id = device_id
        self._task_id = task_id
        self._success = success
        self._status = status
        self._counts = counts
        self._prob = prob
        self._amps = amps
        self._raw_result = raw_result

    def __str__(self):
        return f"Result(device_id={self._device_id}, task_id={self._task_id}, " \
               f"success={self._success}, status={self._status}, " \
               f"counts={self._counts}, prob={self._prob}, amps={self._amps}, raw_result={self._raw_result})"

    def __repr__(self):
        return self.__str__()

    def get_device_id(self):
        return self._device_id

    def get_task_id(self):
        return self._task_id

    def get_success(self):
        return self._success

    def get_status(self):
        return self._status

    def get_counts(self):
        return self._counts

    def get_prob(self):
        return self._prob

    def get_amps(self):
        return self._amps

    def get_raw_result(self):
        return self._raw_result