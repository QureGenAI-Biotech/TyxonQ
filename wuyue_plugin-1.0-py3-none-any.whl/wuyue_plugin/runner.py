import ast
import math
from typing import Union
import re
import cirq
from qiskit import QuantumCircuit, qasm2
from wuyue.circuit.circuit import QuantumCircuit as WuyueQuantumCircuit

from wuyue_plugin.model import SubmitTaskBody
from wuyue_plugin.result import Result
import time

from wuyue_plugin.enable_print import print_controller
from wuyue_plugin.wuyue_plugin_client import WuyueClient
import pennylane as qml
from cirq.circuits import Circuit as CirqCircuit

def re_cirq_qasm(qasm_str: str) -> str:
    """
        将 Cirq 导出的 QASM 格式化为 Qiskit 风格：
          - 去掉注释
          - 自动识别量子比特数量并声明 creg c[n];
          - 将 measure q[i] -> xxx 替换为 measure q[i] -> c[i];
          - 保证 include 在前，寄存器声明顺序正确 (qreg 在 creg 前)
        """
    lines = []
    qreg_size = 0
    measure_lines = []

    for raw_line in qasm_str.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("//"):
            continue  # 跳过注释或空行

        # 识别量子寄存器
        if line.startswith("qreg q["):
            match = re.search(r"qreg q\[(\d+)\];", line)
            if match:
                qreg_size = int(match.group(1))
            continue  # 不立即加入，稍后按正确顺序插入

        # 删除 Cirq 的 creg 声明
        if line.startswith("creg "):
            continue

        # 处理测量语句
        if line.startswith("measure"):
            match = re.search(r"measure q\[(\d+)\]", line)
            if match:
                q_index = int(match.group(1))
                measure_lines.append(f"measure q[{q_index}] -> c[{q_index}];")
            continue

        # 其他行直接保留
        lines.append(line)

    # 构建输出结构
    output = []

    # 第一部分：头部（OPENQASM + include）
    for line in lines:
        if line.startswith("OPENQASM") or line.startswith("include"):
            output.append(line)

    # 第二部分：寄存器声明
    if qreg_size > 0:
        output.append(f"qreg q[{qreg_size}];")
        output.append(f"creg c[{qreg_size}];")

    # 第三部分：量子门指令（非 measure）
    for line in lines:
        if not (line.startswith("OPENQASM") or line.startswith("include")):
            output.append(line)

    # 第四部分：测量指令
    output.extend(measure_lines)

    return "\n".join(output)

def replace_pi_expressions(qasm_str: str) -> str:
    """
    将 Cirq QASM 中的 pi*系数 表达式转为浮点数。
    例如 rz(pi*0.5) -> rz(1.570796)
    """
    def repl(match):
        coeff = float(match.group(1))
        value = coeff * math.pi
        return f"{value:.6f}"  # 保留6位小数，符合QASM精度

    # 匹配所有 pi*xxx 的表达式
    qasm_str = re.sub(r"pi\*([0-9.\-eE]+)", repl, qasm_str)
    return qasm_str


def convert_qasm(qc):
    # 判断线路类型
    global qasm
    if isinstance(qc, QuantumCircuit):
        qasm = qasm2.dumps(qc)
    elif isinstance(qc, WuyueQuantumCircuit):
        qasm = qc.QASM().replace("cnot","cx")
    elif isinstance(qc, CirqCircuit):
        qasm_str = cirq.qasm(qc)
        qasm = replace_pi_expressions(re_cirq_qasm(qasm_str))
    elif isinstance(qc, qml.QNode):
        try:
            qasm = qml.to_openqasm(qc,measure_all=False)().strip()
        except Exception as e:
            raise ValueError(f"无法将PennyLane QNode转换为QASM: {e}")
    return qasm



class Runner:
    def __init__(self, access_key: str, secret_key: str, auto_retry=False):


        self.access_key = access_key
        self.secret_key = secret_key
        self.wuyue_client = WuyueClient(access_key, secret_key, auto_retry)
        self.submit_kwargs = {}

        # key是用户输入参数名称，value是submit_task参数名称
        self.param_map ={
            "mapping_flag": "mapping_flag",
            "quan_state_decs": "quan_state_decs",
            "double_noise_probability": "double_noise_probability",
            "source": "source",
            "bit_info": "bit_info",
            "circuit_id": "circuit_id",
            "calculate_type": "calculat_type",
            "single_noise_probability": "single_noise_probability",
            "provider": "provider",
            "quan_state_dec": "quan_state_dec",
            "is_amend": "is_amend",
            "noise_type": "noise_type",
            "qmachine_type": "qmachine_type",
            "circuit_optimization": "circuit_optimization",
            'qubit_mapping': 'qubit_mapping',
            'gate_decomposition': 'gate_decomposition',
            'dry_run': 'dry_run',
            'initial_mapping': 'initial_mapping',
            "wait": "wait"
        }


    '''
        任务执行方法：分为同步和异步，异步返回task_id,可以通过控制台查询结果
        qc: 接收qiskit或者wuyueSDK的门线路类
        shots：实验次数
        qubits：量子比特
        task_name: 任务名称
        device_id: 执行任务的设备号
        qboson_in_data：相关光量子的输入数据
        timeout: 任务最大等待时间
        *kwargs: 模拟器、真机任务提交的参数，参考五岳云平台控制台帮助中心
    '''
    def run(
            self,
            qc: Union[QuantumCircuit, WuyueQuantumCircuit, qml.QNode, CirqCircuit] = None,
            shots: int = 1024,
            qubits: int = None,
            task_name: str = None,
            device_id: str = None,
            qboson_in_data: str = None,
            timeout: int = 0,
            **kwargs
    ):
        if timeout > 3600:
            raise ValueError("timeout参数不能超过3600秒")
        if timeout < 0:
            raise ValueError("timeout参数必须为正整数")

        if qc is not None and qboson_in_data is not None:
            raise ValueError("qc 和 qboson_in_data 不能同时有值")

        self._check_and_build_params(device_id, qc, qubits, shots, task_name, qboson_in_data, timeout, **kwargs)

        # 提交任务
        result = self.wuyue_client.submit_task(SubmitTaskBody(**self.submit_kwargs))
        if result.code != 1:
            raise RuntimeError(f"任务执行失败：{result.error_code}{result.msg}")
        task_id = result.data.task_id

        # 异步任务提交
        if timeout == 0:
            return Result(
                device_id=device_id,
                task_id=task_id,
                success=True,
                status='排队中',
                counts={},
                prob={},
                amps={},
                raw_result=None
            )

        return self._sync_get_task_result(task_id,timeout,device_id)


    def _check_and_build_params(self, device_id, qc, qubits, shots, task_name, qboson_in_data, timeout, **kwargs):

        timestamp = int(time.time())
        if task_name is None:
            task_name = "Task" + f'{timestamp}'

        self.submit_kwargs["name"] = task_name
        self.submit_kwargs["device_id"] = device_id

        if timeout > 0:
            self.submit_kwargs["wait"] = True
        else:
            self.submit_kwargs["wait"] = False

        if qc is not None:
            qasm = convert_qasm(qc)
            print(qasm)
            # 只有**kwargs中传了的参数且不为None，才去和param_map中的参数做映射，映射成submit_kwargs
            mapped_kwargs =  {
                submit_key: kwargs[source_key]
                for source_key, submit_key in self.param_map.items()
                if source_key in kwargs and kwargs[source_key] is not None
            }
            self.submit_kwargs.update(mapped_kwargs)
            # 将submit_kwargs字段补全
            self.submit_kwargs["in_data"] = qasm
            self.submit_kwargs["exam_num"] = shots
            self.submit_kwargs["quan_num"] = qubits

        elif qboson_in_data is not None:
            self.submit_kwargs["in_data"] = qboson_in_data

    def _sync_get_task_result(self, task_id, timeout, device_id):
        """

        """
        start_time = time.time()
        attempt = 0
        wait_times = [1,1,2,2,5,5,10,10,30,30,60,60,120,180,300]
        while True:
            elapsed = time.time() - start_time
            if elapsed >= timeout:
                raise TimeoutError(f"任务在 {timeout} 秒内未完成")
            print_controller.custom_print(f"第 {attempt} 次尝试，已耗时 {int(elapsed)} 秒...")
            # print(f"第 {attempt} 次尝试，已耗时 {int(elapsed)} 秒...")

            info_res = self.get_task_result(task_id)

            if info_res.code != 1:
                raise RuntimeError(f"任务执行失败：{info_res.error_code}{info_res.msg}")
            data = info_res.data
            status = data.task_status
            if status == 5:
                return Result(
                    device_id=device_id,
                    task_id=task_id,
                    success=True,
                    status='计算成功',
                    counts=ast.literal_eval(data.out_counts or '{}'),
                    prob=ast.literal_eval(data.out_probs or '{}'),
                    amps=ast.literal_eval(data.out_amps or '{}'),
                    raw_result=data.out_data
                )
            elif status == 6:
                return Result(
                    device_id=device_id,
                    task_id=task_id,
                    success=False,
                    status='计算失败',
                    counts={},
                    prob={},
                    amps={},
                    raw_result=data.out_data
                )

            if attempt < len(wait_times):
                sleep_time = wait_times[attempt]
            else:
                sleep_time = wait_times[-1]  # 超过数组则使用最后一个等待时间

            next_elapsed = elapsed + sleep_time
            if next_elapsed >= timeout:
                print_controller.custom_print(f"任务: {task_id} 已经达到最大等待时间")
                break
            print_controller.custom_print(f"未获取到结果，等待 {sleep_time:.2f} 秒后重试")
            time.sleep(sleep_time)
            attempt += 1

        raise TimeoutError(f"任务未在 {timeout} 秒内完成")


    def get_task_result(self, task_id):
        return self.wuyue_client.query_task_info(task_id)

    '''
        获取设备名称和设备号（device_id）
        返回一个字典{'单振幅模拟器': 'singleAmplitude01',
                    全振幅模拟器': 'quanGate01'
                    ...}
    '''
    def get_eng_list(self,client_type: int=None, eng_type: int=None, ins_label: int=None, status: int=None):
        return self.wuyue_client.query_engine_list(client_type, eng_type, ins_label, status)